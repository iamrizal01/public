<?php
// Path ke config utama
require_once '../../includes/config.php';

$style = "
    <style>
        body { font-family: 'Inter', sans-serif; background: #f8f9fa; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .card { background: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); text-align: center; max-width: 400px; width: 100%; }
        .icon { font-size: 50px; margin-bottom: 20px; }
        .success { color: #198754; } .error { color: #dc3545; } .warning { color: #ffc107; }
        .btn { display: inline-block; margin-top: 20px; padding: 10px 20px; background: #0d6efd; color: #fff; text-decoration: none; border-radius: 8px; font-weight: 600; }
    </style>
";

if (!isset($_GET['token']) || empty($_GET['token'])) {
    die("$style<div class='card'><div class='icon error'>❌</div><h2>Token Tidak Valid</h2><p>Tautan verifikasi ini tidak valid atau formatnya salah.</p></div>");
}

$token = preg_replace('/[^a-zA-Z0-9]/', '', $_GET['token']);
$redis_key = "postaja_token_" . $token;

$redis = new Redis();
try {
    if (!$redis->connect('/home/silorizz/redis/redis.sock')) {
        die("$style<div class='card'><div class='icon error'>⚠️</div><h2>Server Sibuk</h2><p>Gagal terhubung ke layanan Redis.</p></div>");
    }
} catch (Exception $e) {
    die("$style<div class='card'><div class='icon error'>⚠️</div><h2>Server Sibuk</h2><p>Gagal terhubung ke layanan Redis.</p></div>");
}

$payload = $redis->get($redis_key);

if ($payload) {
    $data = json_decode($payload, true);
    $user_data = $data['user_data'] ?? [];
    $email = $data['email'] ?? '';
    $type = $data['type'] ?? '';

    // Jika tipenya Register
    if ($type === 'register') {
        if (!empty($user_data) && isset($user_data['username'], $user_data['password'])) {
            
            // Cek apakah udah ada di DB
            $stmt = $db->prepare('SELECT id FROM users WHERE email = :e OR username = :u');
            $stmt->bindValue(':e', $email);
            $stmt->bindValue(':u', $user_data['username']);
            $exists = $stmt->execute()->fetchArray(SQLITE3_ASSOC);

            if (!$exists) {
                // CREATE ACCOUNT
                $insert = $db->prepare('INSERT INTO users (username, email, password, role, is_verified, is_active) VALUES (:u, :e, :p, "user", 1, 1)');
                $insert->bindValue(':u', $user_data['username']);
                $insert->bindValue(':e', $email);
                $insert->bindValue(':p', $user_data['password']);
                $insert->execute();

                // Clean up Redis
                $redis->del($redis_key);
                $redis->del("postaja_otp_{$email}_{$type}");

                echo "$style
                <div class='card'>
                    <div class='icon success'>✅</div>
                    <h2>Pendaftaran Berhasil!</h2>
                    <p>Selamat! Akun <b>@{$user_data['username']}</b> telah aktif.</p>
                    <a href='../../index.php' class='btn'>Lanjut ke Beranda</a>
                </div>";
            } else {
                echo "$style<div class='card'><div class='icon warning'>⚠️</div><h2>Akun Sudah Ada</h2><p>Email atau Username tersebut sudah terdaftar sebelumnya.</p><a href='../../index.php' class='btn'>Kembali</a></div>";
            }
        } else {
            // INI PENYEBABNYA KALAU PARAMETER KE-3 LUPA DIKIRIM
            echo "$style<div class='card'><div class='icon error'>❌</div><h2>Data Tidak Lengkap</h2><p>Sistem gagal membuat akun karena data form (Username/Password) tidak tersimpan dengan sempurna di Redis.</p><a href='../../index.php' class='btn'>Coba Daftar Ulang</a></div>";
        }
    } else {
        // Tipe Login / Reset Password
        $redis->del($redis_key);
        $redis->del("postaja_otp_{$email}_{$type}");
        
        echo "$style
        <div class='card'>
            <div class='icon success'>✅</div>
            <h2>Akses Diverifikasi</h2>
            <p>Tautan ini valid. Silakan kembali ke halaman browser sebelumnya untuk melanjutkan.</p>
            <a href='../../index.php' class='btn'>Ke Beranda</a>
        </div>";
    }
} else {
    echo "$style
    <div class='card'>
        <div class='icon error'>⏳</div>
        <h2>Tautan Kadaluwarsa</h2>
        <p>Tautan verifikasi ini sudah tidak berlaku (lebih dari 3 jam) atau sudah digunakan sebelumnya.</p>
        <a href='../../index.php' class='btn'>Kembali ke Beranda</a>
    </div>";
}
?>
