<?php
http_response_code(403);
$root_path = ''; 
$api_path = 'api/'; 
$home_url = 'index.php';
$current_page = '403'; 
$page_title = '403 Forbidden';

require 'includes/config.php';
require 'includes/functions.php';
require 'includes/auth_handler.php';

$attempted_url = isset($_SERVER['REQUEST_URI']) ? htmlspecialchars($_SERVER['REQUEST_URI'], ENT_QUOTES, 'UTF-8') : 'this directory';

$message = "You don't have permission to access <strong>" . $attempted_url . "</strong> on this server.";

require 'includes/header.php';
?>

<div class="container py-5 text-center d-flex flex-column justify-content-center align-items-center" style="min-height: 65vh;">
    <div class="mb-4">
        <div class="ad-icon mx-auto mb-3" style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#dc3545 0%,#8b0000 100%);display:flex;align-items:center;justify-content:center;">
            <i class="bi bi-shield-lock text-white" style="font-size: 2.5rem;"></i>
        </div>
        <h1 class="display-3 fw-bold text-dark">403 Forbidden</h1>
    </div>
    <div class="post-card p-4 border-0 shadow-sm" style="max-width: 600px; width: 100%; border-radius: 12px; background: #fff;">
        <p class="lead text-muted mb-0 fw-medium"><?= $message ?></p>
    </div>
    <a href="<?= $home_url ?>" class="btn btn-primary rounded-pill px-5 py-2 mt-4 fw-bold shadow-sm">
        <i class="bi bi-house-door me-2"></i>Back to Home
    </a>
</div>

<?php require 'includes/footer.php'; ?>
