<?php
$request_uri = $_SERVER['REQUEST_URI'];
$path = trim(parse_url($request_uri, PHP_URL_PATH), '/');

if (!empty($path) && is_dir($path)) {
    return;
}
http_response_code(404);
$root_path = ''; 
$api_path = 'api/'; 
$home_url = 'index.php';
$current_page = '404'; 
$page_title = '404 Not Found';

require 'includes/config.php';
require 'includes/functions.php';
require 'includes/auth_handler.php';

$request_uri = $_SERVER['REQUEST_URI'];
$parsed_url = parse_url($request_uri);
$path = trim($parsed_url['path'] ?? '', '/');
$name = basename($path);

if (isset($_GET['notfound']) && isset($_GET['type'])) {
    $type = htmlspecialchars($_GET['type']);
    $name_display = htmlspecialchars($_GET['notfound']);
    $message = "Sorry, but a query of {$type} as {$name_display} does not exist";
} elseif (empty($path) || stripos($request_uri, '404.php') !== false) {
    $message = "This Is A 404, Leave This Page Immediately If You Are Not Looking For The Wrong URL Address";
} else {
    $type = (strpos($name, '.') === false) ? 'folder' : 'file';
    $message = "Sorry, but a query of {$type} as " . htmlspecialchars($name) . " does not exist";
}

require 'includes/header.php';
?>

<div class="container py-5 text-center d-flex flex-column justify-content-center align-items-center" style="min-height: 65vh;">
    <div class="mb-4">
        <div class="ad-icon mx-auto mb-3" style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#dc3545 0%,#8b0000 100%);display:flex;align-items:center;justify-content:center;">
            <i class="bi bi-exclamation-triangle text-white" style="font-size: 2.5rem;"></i>
        </div>
        <h1 class="display-3 fw-bold text-dark">404 Not Found</h1>
    </div>
    <div class="post-card p-4 border-0 shadow-sm" style="max-width: 600px; width: 100%; border-radius: 12px; background: #fff;">
        <p class="lead text-muted mb-0 fw-medium"><?= $message ?></p>
    </div>
    <a href="<?= $home_url ?>" class="btn btn-primary rounded-pill px-5 py-2 mt-4 fw-bold shadow-sm">
        <i class="bi bi-house-door me-2"></i>Back to Home
    </a>
</div>

<?php require 'includes/footer.php'; ?>
