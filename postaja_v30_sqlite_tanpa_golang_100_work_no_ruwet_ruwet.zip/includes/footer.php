</div><div class="sidebar-right d-none d-lg-block">
        <?php if (isset($error_msg)) echo "<div class='alert alert-danger border-0 rounded-4 mt-3 small'>" . htmlspecialchars($error_msg) . "</div>"; ?>
        <?php if (isset($warning_msg)) echo "<div class='alert alert-warning border-0 rounded-4 mt-3 small'>" . htmlspecialchars($warning_msg) . "</div>"; ?>
        <?php if (isset($success_msg)) echo "<div class='alert alert-success border-0 rounded-4 mt-3 small'>" . htmlspecialchars($success_msg) . "</div>"; ?>

        <?php if (isset($_SESSION['user_id'])):
            $uid = (int)$_SESSION['user_id'];
            $sug = $db->query("
                SELECT u.id, u.username, u.avatar_url, u.role, u.is_premium,
                       (SELECT COUNT(*) FROM follows WHERE following_id=u.id) as fc
                FROM users u
                WHERE u.id != $uid
                AND u.is_active = 1
                AND u.id NOT IN (SELECT following_id FROM follows WHERE follower_id=$uid)
                ORDER BY fc DESC LIMIT 4
            ");
        ?>
        <div class="bg-light rounded-4 p-3 mt-3 border">
            <h6 class="fw-bold mb-2">Who to follow</h6>
            <?php while ($s = $sug->fetchArray(SQLITE3_ASSOC)): ?>
            <div class="suggested-user">
                <a href="<?= $root_path ?>profile/?u=<?= urlencode($s['username']) ?>">
                    <?= getAvatarHtml($s['username'], $s['avatar_url'] ?? '', 38) ?>
                </a>
                <div class="flex-grow-1 min-width-0">
                    <a href="<?= $root_path ?>profile/?u=<?= urlencode($s['username']) ?>" class="fw-bold text-dark text-decoration-none d-block" style="font-size:.88rem;">
                        @<?= htmlspecialchars($s['username']) ?>
                    </a>
                    <span class="text-muted" style="font-size:.75rem;"><?= $s['fc'] ?> followers</span>
                </div>
                <button onclick="toggleFollow(<?= $s['id'] ?>)" id="follow-btn-<?= $s['id'] ?>" class="btn-follow unfollow" style="font-size:.78rem;padding:5px 12px;">
                    Follow</button>
            </div>
            <?php endwhile; ?>
        </div>
        <?php endif; ?>

        <?php
        $trendPosts = $db->query("SELECT content FROM posts WHERE created_at >= datetime('now','-7 days') AND content LIKE '%#%'");
        $tagCounts  = [];
        while ($tp = $trendPosts->fetchArray(SQLITE3_ASSOC)) {
            preg_match_all('/#(\w+)/u', $tp['content'], $matches);
            foreach ($matches[1] as $tag) {
                $t = strtolower($tag);
                $tagCounts[$t] = ($tagCounts[$t] ?? 0) + 1;
            }
        }
        arsort($tagCounts);
        $topTags = array_slice($tagCounts, 0, 6, true);
        if (!empty($topTags)): ?>
        <div class="bg-light rounded-4 p-3 mt-3 border">
            <h6 class="fw-bold mb-2">Trending this week</h6>
            <?php foreach ($topTags as $tag => $cnt): ?>
            <a href="<?= $root_path ?>search/?q=<?= urlencode('#' . $tag) ?>&type=posts" class="explore-hashtag" style="border-radius:8px;text-decoration:none;">
                <span class="fw-bold" style="font-size:.88rem;">#<?= htmlspecialchars($tag) ?></span>
                <span class="text-muted small"><?= $cnt ?> posts</span>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="text-muted small px-1 mt-4">&copy; 2026 PostAja �� <a href="<?= $root_path ?>explore/" class="text-muted">Explore</a></div>
    </div>
</div><div class="bottom-nav">
    <a href="<?= $root_path ?>index.php" class="bottom-nav-item <?= ($current_page === 'home') ? 'active' : '' ?>"><i class="bi bi-house-door-fill"></i></a>
    <a href="<?= $root_path ?>explore/" class="bottom-nav-item <?= ($current_page === 'explore') ? 'active' : '' ?>"><i class="bi bi-compass"></i></a>
    <a href="#" class="bottom-nav-item nav-center-btn" onclick="<?= isset($_SESSION['user_id']) ? "new bootstrap.Modal(document.getElementById('postModal')).show()" : "showAuthModal()" ?>"><i class="bi bi-plus-lg"></i></a>
    <?php if (isset($_SESSION['user_id'])): ?>
    <a href="<?= $root_path ?>notifications/" class="bottom-nav-item <?= ($current_page === 'notifications') ? 'active' : '' ?>" style="position:relative;">
        <i class="bi bi-bell-fill"></i>
        <span class="nav-badge nav-badge-notif" style="<?= $notif_count > 0 ? '' : 'display:none' ?>"><?= $notif_count > 9 ? '9+' : $notif_count ?></span>
    </a>
    <a href="<?= $root_path ?>dm/" class="bottom-nav-item <?= ($current_page === 'dm') ? 'active' : '' ?>" style="position:relative;">
        <i class="bi bi-envelope-fill"></i>
        <span class="nav-badge nav-badge-dm" style="<?= $dm_count > 0 ? '' : 'display:none' ?>"><?= $dm_count > 9 ? '9+' : $dm_count ?></span>
    </a>
    <?php else: ?>
    <a href="#" class="bottom-nav-item" data-bs-toggle="modal" data-bs-target="#searchModal"><i class="bi bi-search"></i></a>
    <a href="#" class="bottom-nav-item" data-bs-toggle="modal" data-bs-target="#authModal"><i class="bi bi-person-fill"></i></a>
    <?php endif; ?>
</div>

<div class="modal fade" id="warnModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-5 border-0 shadow-lg text-center p-4">
            <div class="mb-3"><i class="bi bi-exclamation-triangle-fill text-dark display-1"></i></div>
            <h4 class="fw-bold">Moderation Warning!</h4>
            <p class="text-muted">Your message contains inappropriate words and has been automatically censored.</p>
            <button type="button" class="btn btn-primary rounded-pill w-100 py-2 fw-bold" data-bs-dismiss="modal">I Understand</button>
        </div>
    </div>
</div>

<div class="modal fade" id="suspendedModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-5 border-0 shadow-lg text-center p-4" style="background:linear-gradient(135deg,#fff,#f8f9fa);">
            <div class="mb-3"><i class="bi bi-slash-circle-fill text-danger display-1"></i></div>
            <h4 class="fw-bold text-dark">Suspended Account</h4>
            <p class="text-muted mb-4">Your account has been suspended by the administrator.<br>Please contact support for more information.</p>
            <form method="POST">
                <button name="logout" class="btn btn-danger rounded-pill w-100 py-2 fw-bold">Log Out</button>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="maintenanceModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-5 border-0 shadow-lg text-center p-5" style="background:linear-gradient(135deg,#1a1a2e,#16213e);">
            <div class="mb-4"><i class="bi bi-exclamation-triangle-fill display-1" style="color:#ffc107;"></i></div>
            <h3 class="fw-bold text-white mb-2">Oops! We're Under Maintenance</h3>
            <p class="text-white-50 mb-0">We're currently performing some maintenance.<br>We'll be back soon!</p>
        </div>
    </div>
</div>

<div class="modal fade" id="authModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-5 p-4 border-0 shadow-lg">
            <?php if (isset($error_msg)): ?>
                <div class="alert alert-danger border-0 rounded-4 small mb-3"><?= htmlspecialchars($error_msg) ?></div>
            <?php endif; ?>
            <?php if (isset($success_msg)): ?>
                <div class="alert alert-success border-0 rounded-4 small mb-3"><?= htmlspecialchars($success_msg) ?></div>
            <?php endif; ?>
            <div class="text-center mb-4">
                <i class="bi bi-rocket-takeoff-fill display-4 text-dark"></i>
                <h3 class="fw-bold mt-2">Join PostAja</h3>
            </div>
            <ul class="nav nav-pills nav-fill mb-4 bg-light p-1 rounded-pill">
                <?php if (isset($_SESSION['otp_stage']) && $_SESSION['otp_stage'] === 'captcha'): ?>
                <li class="nav-item"><button class="nav-link active rounded-pill fw-bold" data-bs-toggle="pill" data-bs-target="#captcha-verify">Verify Captcha</button></li>
                <?php elseif (isset($_SESSION['otp_stage'])): ?>
                <li class="nav-item"><button class="nav-link active rounded-pill fw-bold" data-bs-toggle="pill" data-bs-target="#otp-verify">Verify OTP</button></li>
                <?php else: ?>
                <li class="nav-item"><button class="nav-link active rounded-pill fw-bold" data-bs-toggle="pill" data-bs-target="#lgn">Login</button></li>
                <li class="nav-item"><button class="nav-link rounded-pill fw-bold" data-bs-toggle="pill" data-bs-target="#reg">Sign Up</button></li>
                <?php endif; ?>
            </ul>
            <div class="tab-content">
                <?php if (isset($_SESSION['otp_stage']) && $_SESSION['otp_stage'] === 'captcha'): 
                    if (empty($_SESSION['custom_captcha'])) generateCustomCaptcha();
                ?>
                <div class="tab-pane fade show active" id="captcha-verify">
                    <div class="text-center mb-3">
                        <p class="small text-muted">Masukkan 6 digit kode captcha di bawah ini:</p>
                        <div class="bg-dark text-white p-4 rounded-4 mb-3 d-inline-block w-100">
                            <h1 class="fw-bold m-0" style="letter-spacing: 12px; font-family: monospace;"><?= $_SESSION['custom_captcha'] ?></h1>
                        </div>
                    </div>
                    <form method="POST">
                        <?= csrfField() ?>
                        <div class="mb-4">
                            <input type="text" name="captcha_code" class="form-control py-3 border-1 bg-light text-center fw-bold" placeholder="Masukkan 6 digit" maxlength="6" pattern="\d{6}" required>
                        </div>
                        <button name="verify_captcha" class="btn btn-primary w-100 py-3 rounded-pill fw-bold">Verify Captcha</button>
                    </form>
                    <div class="mt-3 text-center">
                        <form method="POST"><button name="logout" class="btn btn-link btn-sm text-decoration-none text-muted">Cancel</button></form>
                    </div>
                </div>
                <?php elseif (isset($_SESSION['otp_stage'])): ?>
                <div class="tab-pane fade show active" id="otp-verify">
                    <div class="text-center mb-3">
                        <p class="small text-muted">Masukkan 6 digit kode yang dikirim ke <b><?= htmlspecialchars($_SESSION['otp_email'] ?? '') ?></b></p>
                    </div>
                    <form method="POST">
                        <?= csrfField() ?>
                        <div class="mb-4">
                            <input type="text" name="otp_code" class="form-control py-3 border-1 bg-light text-center fw-bold" placeholder="000000" maxlength="6" pattern="\d{6}" required>
                        </div>
                        <button name="verify_otp" class="btn btn-primary w-100 py-3 rounded-pill fw-bold">Verify & Continue</button>
                    </form>
                    <div class="mt-3 text-center">
                        <form method="POST"><button name="logout" class="btn btn-link btn-sm text-decoration-none text-muted">Cancel / Change Account</button></form>
                    </div>
                </div>
                <?php else: ?>
                <div class="tab-pane fade show active" id="lgn">
                    <a href="https://accounts.google.com/o/oauth2/v2/auth?client_id=<?= GOOGLE_CLIENT_ID ?>&redirect_uri=<?= urlencode(GOOGLE_REDIRECT_URI) ?>&response_type=code&scope=email%20profile&prompt=select_account" class="btn btn-outline-dark w-100 py-3 rounded-pill fw-bold d-flex align-items-center justify-content-center gap-2 mb-3">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
                        Login with Google
                    </a>
                    <div class="text-center text-muted small mb-3">or</div>
                    <form method="POST">
                        <?= csrfField() ?>
                        <div class="mb-3"><input type="text" name="username" class="form-control py-3 border-1 bg-light" placeholder="Username" required></div>
                        <div class="mb-4"><input type="password" name="password" class="form-control py-3 border-1 bg-light" placeholder="Password" required></div>
                        <button name="login" class="btn btn-primary w-100 py-3 rounded-pill fw-bold">Sign In</button>
                    </form>
                </div>
                <div class="tab-pane fade" id="reg">
                    <form method="POST">
                        <?= csrfField() ?>
                        <div class="mb-2"><input type="text" name="username" class="form-control py-3 border-1 bg-light" placeholder="Username (max 10 characters)" maxlength="10" required></div>
                        <div class="mb-2"><input type="email" name="email" class="form-control py-3 border-1 bg-light" placeholder="Email" required></div>
                        <div class="mb-3"><input type="password" name="password" class="form-control py-3 border-1 bg-light" placeholder="Password" required></div>
                        <div class="mb-3">
                            <select name="date_of_birth" class="form-select py-3 border-1 bg-light" required>
                                <option value="" selected disabled>Select Year of Birth (1989-2026)</option>
                                <?php for($y = 2026; $y >= 1989; $y--): ?>
                                <option value="<?= $y ?>"><?= $y ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <button name="register" class="btn btn-primary w-100 py-3 rounded-pill fw-bold">Create Account</button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="searchModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-5 p-3">
            <form method="GET" action="<?= $root_path ?>search/">
                <input type="text" name="q" class="form-control bg-light border-0 rounded-pill py-2 mb-3" placeholder="Search posts or users..." required>
                <div class="d-flex gap-3 px-2 mb-3">
                    <div class="form-check"><input class="form-check-input" type="radio" name="type" value="posts" checked> Posts</div>
                    <div class="form-check"><input class="form-check-input" type="radio" name="type" value="users"> Users</div>
                </div>
                <button class="btn btn-primary w-100 rounded-pill py-2 fw-bold">Search Now</button>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="dobModal" data-bs-backdrop="static" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-5 p-4 border-0 shadow-lg bg-white">
            <div class="text-center mb-4">
                <i class="bi bi-calendar-event display-4 text-dark"></i>
                <h4 class="fw-bold mt-2 text-dark">Update Date of Birth</h4>
                <p class="text-muted small mb-0">Please provide your year of birth to continue</p>
            </div>
            <form id="dobForm">
                <div class="mb-3">
                    <select id="dobYear" class="form-select py-3 border-1 bg-light text-dark" required>
                        <option value="" selected disabled>Select Year (1989-2026)</option>
                        <?php for($y = 2026; $y >= 1989; $y--): ?>
                        <option value="<?= $y ?>"><?= $y ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary w-100 py-3 rounded-pill fw-bold">Save</button>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('dobForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const dob = document.getElementById('dobYear').value;
    if (!dob) return;
    fetch('api/update_dob.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'dob=' + encodeURIComponent(dob)
    }).then(() => {
        localStorage.setItem('dob_updated', '1');
        bootstrap.Modal.getInstance(document.getElementById('dobModal')).hide();
    });
});
</script>

<div class="modal fade" id="postModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-5 p-4">
            <h5 class="fw-bold mb-3">Create Post</h5>
            <form method="POST" action="/" enctype="multipart/form-data" id="postModalForm" onsubmit="return validatePost()">
                <?= csrfField() ?>
                <div class="position-relative">
                    <textarea name="content" id="post-textarea" class="form-control border-1 bg-light rounded-4 mb-3" rows="5" placeholder="What's happening? Use #hashtag or @mention"></textarea>
                    <button type="button" class="btn btn-sm btn-dark position-absolute rounded-pill px-3" style="bottom:25px;right:10px;z-index:5;" onclick="pasteToPost()">Paste</button>
                </div>
                <div class="mb-3">
                    <label class="form-label small text-muted">Image (max 10MB, GIF for premium only)</label>
                    <input type="file" name="post_image" id="postModalImage" class="form-control border-1 bg-light rounded-3" accept="image/jpeg,image/png,image/gif,image/webp" onchange="showPostImgPreview(this)">
                    <div id="postImgPreview" style="display:none;margin-top:8px;position:relative;display:none;">
                        <img id="postImgPreviewEl" src="" style="max-width:100%;max-height:180px;border-radius:10px;object-fit:contain;border:1px solid #eee;">
                        <button type="button" onclick="clearPostImg()" style="position:absolute;top:4px;right:4px;background:rgba(0,0,0,0.5);color:#fff;border:none;border-radius:50%;width:24px;height:24px;font-size:12px;cursor:pointer;line-height:1;">&times;</button>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small text-muted"><i class="bi bi-music-note-beamed"></i> Music URL (mp3 link)</label>
                    <input type="text" name="music_url" class="form-control border-1 bg-light rounded-3" placeholder="https://example.com/music.mp3">
                </div>
                <div class="mb-3">
                    <label class="form-label small text-muted">Music Title</label>
                    <input type="text" name="music_title" class="form-control border-1 bg-light rounded-3" placeholder="Song title">
                </div>
                <button name="create_post" class="btn btn-primary w-100 py-3 rounded-pill fw-bold">Post</button>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="vStory" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark border-0 rounded-5 overflow-hidden">
            <div class="position-absolute top-0 w-100 p-3 d-flex justify-content-between align-items-center z-3">
                <span class="text-white fw-bold" id="stUser"></span>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <img id="stImg" src="" class="w-100" style="max-height:80vh;object-fit:contain;">
        </div>
    </div>
</div>

<div class="modal fade" id="addStory" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-5 p-4">
            <h5 class="fw-bold mb-3">Share Story</h5>
            <form method="POST" action="/" enctype="multipart/form-data">
                <?= csrfField() ?>
                <div class="mb-3">
                    <label class="form-label small text-muted">Story Image (max 10MB, GIF for premium only)</label>
                    <input type="file" name="story_image" class="form-control border-1 bg-light rounded-3" accept="image/jpeg,image/png,image/gif,image/webp" required>
                </div>
                <button name="create_story" class="btn btn-primary w-100 py-3 rounded-pill fw-bold">Send Story</button>
            </form>
        </div>
    </div>
</div>

<?php if (isset($_SESSION['user_id'])): ?>
<div class="modal fade" id="onboardModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-5 p-4" style="background:linear-gradient(135deg,#ffffff,#f4f7ff);">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                    <h5 class="fw-bold mb-1">Welcome to PostAja �9�9</h5>
                    <p class="text-muted mb-0">Help us get to know you so we can make better recommendations.</p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="<?= $root_path ?>api/onboard.php">
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small text-muted mb-1">What's your favorite?</label>
                        <input type="text" name="favorite" class="form-control border-0 bg-light rounded-4 py-2 px-3" placeholder="Contoh: teknologi, musik, bola">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small text-muted mb-1">What's your hobby?</label>
                        <input type="text" name="hobby" class="form-control border-0 bg-light rounded-4 py-2 px-3" placeholder="Contoh: membaca, desain, ngoding">
                    </div>
                </div>

                <?php
                $sugOnb = null;
                if (isset($db, $_SESSION['user_id'])) {
                    $uidOnb = (int)$_SESSION['user_id'];
                    $sugOnb = $db->query("
                        SELECT u.id, u.username, u.avatar_url, u.role,
                               (SELECT COUNT(*) FROM follows WHERE following_id=u.id) as fc
                        FROM users u
                        WHERE u.id != $uidOnb
                        AND u.is_active = 1
                        AND u.id NOT IN (SELECT following_id FROM follows WHERE follower_id=$uidOnb)
                        ORDER BY fc DESC LIMIT 6
                    ");
                }
                ?>
                <?php if ($sugOnb): ?>
                <div class="mt-2">
                    <label class="form-label small text-muted mb-2 d-block">People you might like</label>
                    <div class="row g-2">
                        <?php while ($s = $sugOnb->fetchArray(SQLITE3_ASSOC)): ?>
                        <div class="col-12 col-md-6">
                            <label class="border rounded-4 p-2 d-flex align-items-center gap-2 bg-white shadow-sm-sm" style="cursor:pointer;">
                                <input type="checkbox" class="form-check-input me-2" name="follow_ids[]" value="<?= (int)$s['id'] ?>">
                                <?= getAvatarHtml($s['username'], $s['avatar_url'] ?? '', 32) ?>
                                <div class="flex-grow-1 ms-1">
                                    <div class="d-flex align-items-center gap-1">
                                        <span class="fw-semibold small">@<?= htmlspecialchars($s['username']) ?></span>
                                    </div>
                                    <span class="text-muted small"><?= (int)$s['fc'] ?> followers</span>
                                </div>
                            </label>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="mt-4 d-grid">
                    <button type="submit" class="btn btn-primary rounded-pill py-2 fw-bold">
                        Get Started
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
function showPostImgPreview(input) {
    const prev = document.getElementById('postImgPreview');
    const img = document.getElementById('postImgPreviewEl');
    if (input.files && input.files[0]) {
        const r = new FileReader();
        r.onload = e => { img.src = e.target.result; prev.style.display = 'block'; };
        r.readAsDataURL(input.files[0]);
    }
}
function clearPostImg() {
    document.getElementById('postModalImage').value = '';
    document.getElementById('postImgPreview').style.display = 'none';
    document.getElementById('postImgPreviewEl').src = '';
}
function validatePost() {
    const txt = document.getElementById('post-textarea')?.value?.trim();
    const img = document.getElementById('postModalImage')?.files?.length;
    const music = document.querySelector('#postModalForm [name="music_url"]')?.value?.trim();
    if (!txt && !img && !music) {
        alert('Tulis sesuatu, atau attach gambar/musik dulu!');
        return false;
    }
    return true;
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ���� Quick Nav Dropdown ������������������������������������������������������������������������������������
function toggleQuickNav(e) {
    e && e.stopPropagation();
    const d = document.getElementById('quickNavDropdown');
    if (!d) return;
    d.style.display = d.style.display === 'block' ? 'none' : 'block';
}
function closeQuickNav() {
    const d = document.getElementById('quickNavDropdown');
    if (d) d.style.display = 'none';
}
document.addEventListener('click', function(e) {
    const wrap = document.getElementById('quickNavWrap');
    if (wrap && !wrap.contains(e.target)) closeQuickNav();
});

// ���� Download Promo Popup (guest only, every refresh) ������������������������
function closeDlPromo() {
    const el = document.getElementById('dlPromo');
    if (el) { el.style.opacity = '0'; el.style.transition = 'opacity .2s'; setTimeout(() => el.style.display = 'none', 200); }
}
<?php if (!isset($_SESSION['user_id'])): ?>
(function() {
    const el = document.getElementById('dlPromo');
    if (!el) return;
    setTimeout(() => { el.style.display = 'flex'; }, 1200);
})();
<?php endif; ?>
</script>

<style>
/* CSS UNTUK CONTEXT MENU & TRANSLATE BOX DI KOMENTAR */
#customContextMenu {
    position: absolute;
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.15);
    padding: 8px 0;
    min-width: 180px;
    z-index: 999999;
    border: 1px solid #e9ecef;
    font-family: 'Inter', sans-serif;
    display: none;
}
.ctx-item {
    padding: 10px 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 0.88rem;
    color: #333;
    transition: all 0.15s;
}
.ctx-item:hover { background: #f8f9fa; color: #0d6efd; }
.ctx-item.text-danger:hover { color: #dc3545; }

.translate-box {
    background: #f0f7ff;
    border-left: 4px solid #0d6efd;
    padding: 12px;
    border-radius: 4px 8px 8px 4px;
    margin-top: 10px;
    font-size: 0.85rem;
    display: flex;
    gap: 10px;
    align-items: flex-start;
    animation: fadeIn 0.3s ease;
}
.translate-icon-wrap {
    background: #0d6efd;
    color: white;
    border-radius: 50%;
    width: 26px;
    height: 26px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}
@keyframes fadeIn { from { opacity: 0; transform: translateY(-5px); } to { opacity: 1; transform: translateY(0); } }
</style>

<div id="customContextMenu">
    <div class="ctx-item" id="ctx-copy"><i class="bi bi-clipboard"></i> Copy Text</div>
    <div class="ctx-item" id="ctx-translate"><i class="bi bi-translate text-primary"></i> Translate to ID</div>
    <div class="ctx-item" id="ctx-profile"><i class="bi bi-person"></i> View Profile</div>
    <div class="ctx-item" id="ctx-dm"><i class="bi bi-send"></i> Send DM</div>
    <div class="ctx-item text-danger" id="ctx-report"><i class="bi bi-flag"></i> Report</div>
</div>

<script>
const postModalEl = document.getElementById('postModal');
if (postModalEl) {
    postModalEl.addEventListener('shown.bs.modal', function () {
        document.querySelector('.nav-center-btn').classList.add('active');
    });
    postModalEl.addEventListener('hidden.bs.modal', function () {
        document.querySelector('.nav-center-btn').classList.remove('active');
    });
}

// Disable inspect element
document.onkeydown = function(e) {
    if (e.keyCode === 123 || (e.ctrlKey && e.shiftKey && e.keyCode === 73) || (e.ctrlKey && e.shiftKey && e.keyCode === 74) || (e.ctrlKey && e.keyCode === 85)) {
        e.preventDefault();
        return false;
    }
};
!function(){try{new Event('test'),Event.prototype.preventDefault()}catch(e){var n=Event.prototype.preventDefault;Event.prototype.preventDefault=function(){n.call(this),Object.defineProperty(this,'defaultPrevented',{get:function(){return!0},configurable:!0})}}}();

// ===============================================
// MODIFIKASI: CUSTOM RIGHT-CLICK (CONTEXT MENU KOMENTAR) 
// & IOS CONTEXT MENU (GABUNGAN)
// ===============================================
let contextMenuTarget = null;
let contextCommentNode = null;
const contextMenu = document.getElementById('iosContextMenu');
const commentDeleteItem = document.getElementById('commentDeleteItem');
const currentUserId = <?= isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 'null' ?>;

// Menu baru untuk komen (Translate, Profil, dll)
const ctxMenuComment = document.getElementById('customContextMenu');

document.addEventListener('contextmenu', function(e) {
    const target = e.target;
    const copyable = target.closest('.copyable-text');
    const isComment = target.closest('.comment-node');
    
    if (isComment) {
        e.preventDefault();
        contextMenuTarget = isComment.querySelector('.comment-bubble');
        contextCommentNode = isComment;
        
        ctxMenuComment.style.display = 'block';
        let x = e.clientX;
        let y = e.clientY;
        
        setTimeout(function() {
            var rect = ctxMenuComment.getBoundingClientRect();
            if (x + rect.width > window.innerWidth) x = window.innerWidth - rect.width - 10;
            if (y + rect.height > window.innerHeight) y = window.innerHeight - rect.height - 10;
            ctxMenuComment.style.left = x + 'px';
            ctxMenuComment.style.top = y + 'px';
        }, 10);
        
        if (contextMenu) contextMenu.style.display = 'none'; // Hide iOS menu if open
        return;
    }
    
    if (copyable && contextMenu) {
        e.preventDefault();
        contextMenuTarget = copyable;
        contextCommentNode = copyable.closest('.comment-node');
        
        let x = e.clientX;
        let y = e.clientY;
        
        if (commentDeleteItem) {
            if (contextCommentNode && currentUserId !== null) {
                const commentUserId = parseInt(contextCommentNode.dataset.userId);
                commentDeleteItem.style.display = commentUserId === currentUserId ? 'flex' : 'none';
            } else {
                commentDeleteItem.style.display = 'none';
            }
        }
        
        contextMenu.style.display = 'block';
        ctxMenuComment.style.display = 'none'; // Hide custom comment menu if open
        
        setTimeout(function() {
            var rect = contextMenu.getBoundingClientRect();
            if (x + rect.width > window.innerWidth) x = window.innerWidth - rect.width - 10;
            if (y + rect.height > window.innerHeight) y = window.innerHeight - rect.height - 10;
            contextMenu.style.left = x + 'px';
            contextMenu.style.top = y + 'px';
        }, 10);
    }
});

document.addEventListener('click', function(e) {
    if (contextMenu && !contextMenu.contains(e.target)) {
        contextMenu.style.display = 'none';
    }
    if (ctxMenuComment && !ctxMenuComment.contains(e.target)) {
        ctxMenuComment.style.display = 'none';
    }
});

document.addEventListener('scroll', function() {
    if (contextMenu) contextMenu.style.display = 'none';
    if (ctxMenuComment) ctxMenuComment.style.display = 'none';
});

// Aksi Klik Menu Komentar
document.getElementById('ctx-copy').onclick = () => {
    const text = contextCommentNode.querySelector('.comment-text').innerText;
    navigator.clipboard.writeText(text).then(() => {
        triggerNotif('Teks berhasil disalin!', 'info');
    });
    ctxMenuComment.style.display = 'none';
};

document.getElementById('ctx-profile').onclick = () => {
    const authorRaw = contextCommentNode.querySelector('.comment-author').innerText;
    const author = authorRaw.replace('@', '').trim();
    window.location.href = ROOT_PATH + 'profile/?u=' + encodeURIComponent(author);
};

document.getElementById('ctx-dm').onclick = () => {
    const authorRaw = contextCommentNode.querySelector('.comment-author').innerText;
    const author = authorRaw.replace('@', '').trim();
    window.location.href = ROOT_PATH + 'dm/?with=' + encodeURIComponent(author);
};

document.getElementById('ctx-report').onclick = () => {
    if(confirm('Yakin ingin melaporkan komentar ini?')) {
        // Nanti bisa ditembak pakai fetch ke report.php kamu (kalau ada API-nya buat komen)
        triggerNotif('Komentar dilaporkan.', 'info');
        ctxMenuComment.style.display = 'none';
    }
};

document.getElementById('ctx-translate').onclick = async () => {
    ctxMenuComment.style.display = 'none';
    
    if (contextCommentNode.querySelector('.translate-box')) return;

    const bubble = contextCommentNode.querySelector('.comment-bubble');
    const commentText = contextCommentNode.querySelector('.comment-text').innerText;
    
    const tBox = document.createElement('div');
    tBox.className = 'translate-box';
    tBox.innerHTML = `
        <div class="translate-icon-wrap"><i class="bi bi-translate" style="font-size:12px;"></i></div>
        <div style="color: #666; font-style: italic;">Menerjemahkan ke bahasa Indonesia...</div>
    `;
    bubble.after(tBox);

    try {
        const url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=id&dt=t&q=' + encodeURIComponent(commentText);
        const res = await fetch(url);
        const data = await res.json();
        const translated = data[0].map(item => item[0]).join('');
        
        tBox.innerHTML = `
            <div class="translate-icon-wrap"><i class="bi bi-translate" style="font-size:12px;"></i></div>
            <div style="color: #1a1a1a;">${translated}</div>
        `;
    } catch (err) {
        tBox.innerHTML = `
            <div class="translate-icon-wrap bg-danger"><i class="bi bi-exclamation-triangle" style="font-size:12px;"></i></div>
            <div class="text-danger">Gagal menerjemahkan. Cek koneksi.</div>
        `;
    }
};

// Aksi Klik Menu Bawaan (iOS Text)
function contextCopy() {
    if (contextMenuTarget) {
        const text = contextMenuTarget.textContent.trim();
        navigator.clipboard.writeText(text).then(function() {
            triggerNotif('Copied to clipboard', 'info');
        }).catch(function() {
            triggerNotif('Failed to copy', 'info');
        });
    }
    if (contextMenu) contextMenu.style.display = 'none';
}

function contextPaste() {
    if (contextMenu) contextMenu.style.display = 'none';
    navigator.clipboard.readText().then(function(text) {
        const activeEl = document.activeElement;
        if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
            var start = activeEl.selectionStart;
            var end = activeEl.selectionEnd;
            var val = activeEl.value;
            activeEl.value = val.substring(0, start) + text + val.substring(end);
            activeEl.selectionStart = activeEl.selectionEnd = start + text.length;
            activeEl.focus();
        }
    }).catch(function() {});
}

function contextDeleteComment() {
    if (contextMenu) contextMenu.style.display = 'none';
    if (!contextCommentNode || !isLoggedIn) return;
    
    const commentId = parseInt(contextCommentNode.dataset.commentId);
    if (!commentId) return;
    
    if (!confirm('Delete this comment?')) return;
    
    fetch(API_PATH + 'delete_comment.php?comment_id=' + commentId)
        .then(r => r.json())
        .then(data => {
            if (data.status === 'deleted') {
                contextCommentNode.style.opacity = '0';
                contextCommentNode.style.transition = 'opacity .3s';
                setTimeout(() => {
                    const children = contextCommentNode.querySelector('.comment-children');
                    if (children) {
                        children.remove();
                    }
                    contextCommentNode.remove();
                }, 300);
                triggerNotif('Comment deleted', 'info');
            } else if (data.message === 'login_required') {
                showAuthModal();
            }
        })
        .catch(() => {});
}

const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;
const isOtpStage = <?= isset($_SESSION['otp_stage']) ? 'true' : 'false' ?>;
const ROOT_PATH  = '<?= addslashes($root_path) ?>';
const API_PATH   = ROOT_PATH + 'api/';

document.addEventListener('DOMContentLoaded', function() {
    if (!isLoggedIn && isOtpStage) {
        showAuthModal();
    }
});

<?php if (isset($_GET['warned']) || isset($_GET['warn_comment'])): ?>
new bootstrap.Modal(document.getElementById('warnModal')).show();
<?php endif; ?>

<?php if (isset($_SESSION['needs_dob']) && $_SESSION['needs_dob']): ?>
<?php unset($_SESSION['needs_dob']); ?>
if (!localStorage.getItem('dob_updated')) {
    new bootstrap.Modal(document.getElementById('dobModal')).show();
}
<?php endif; ?>

function pasteToPost() {
    navigator.clipboard.readText().then(text => {
        const textarea = document.getElementById('post-textarea');
        if (textarea) {
            textarea.value += text;
            textarea.focus();
        }
    }).catch(err => {
        console.error('Failed to read clipboard contents: ', err);
    });
}

function translatePost(postId) {
    const post = document.getElementById('post-' + postId);
    if (!post) return;
    const contentElement = post.querySelector('.post-content');
    const content = contentElement.innerText;

    let translateDiv = post.querySelector('.post-translation');
    if (!translateDiv) {
        translateDiv = document.createElement('div');
        translateDiv.className = 'post-translation mt-2 p-2 bg-light rounded text-dark small border copyable-text';
        translateDiv.innerHTML = '<div class="spinner-border spinner-border-sm text-secondary"></div> Translating...';
        contentElement.parentNode.insertBefore(translateDiv, contentElement.nextSibling);
    } else {
        translateDiv.style.display = translateDiv.style.display === 'none' ? 'block' : 'none';
        return;
    }

    const tl = (navigator.language || '').startsWith('id') ? 'en' : 'id';
    const tlLabel = tl === 'id' ? 'Indonesia' : 'English';
    const url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=' + tl + '&dt=t&q=' + encodeURIComponent(content);

    fetch(url)
        .then(res => res.json())
        .then(data => {
            let translatedText = '';
            let detectedLang = '';
            if (data && data[0]) {
                data[0].forEach(item => { if (item[0]) translatedText += item[0]; });
            }
            if (data && data[2]) detectedLang = data[2];
            const langBadge = detectedLang ? ' <span class="badge bg-secondary" style="font-size:.7rem;">' + detectedLang.toUpperCase() + '\u2192' + tl.toUpperCase() + '</span>' : '';
            translateDiv.innerHTML = '<b><i class="bi bi-translate text-primary"></i> ' + tlLabel + '</b>' + langBadge + ':<br><span class="translated-text"></span>';
            translateDiv.querySelector('.translated-text').innerText = translatedText;
        })
        .catch(() => {
            translateDiv.innerHTML = '<i class="bi bi-exclamation-triangle text-danger"></i> Failed to translate.';
        });
}

// ... Sisanya tetap sama seperti sebelumnya (reportPost, getCsrfToken, dll) ...

function reportPost(postId) {
    if (!checkAuth()) return;
    const reason = prompt('Reason for reporting this post?');
    if (!reason) return;
    
    fetch(API_PATH + 'report.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'csrf_token=' + getCsrfToken() + '&post_id=' + postId + '&reason=' + encodeURIComponent(reason)
    }).then(r => r.json()).then(data => {
        if (data.status === 'success') {
            triggerNotif(data.message, 'info');
        } else {
            triggerNotif(data.message, 'info');
        }
    });
}

function getCsrfToken() {
    return document.querySelector('input[name="csrf_token"]')?.value || '';
}

function showAuthModal() { new bootstrap.Modal(document.getElementById('authModal')).show(); }
function checkAuth(e) {
    if (!isLoggedIn) { if(e) e.preventDefault(); showAuthModal(); return false; }
    return true;
}

// ===============================================
// MODIFIKASI: FUNGSI LIKE & REPOST (Mendukung K, M, B, T)
// ===============================================
function likePost(postId) {
    if (!checkAuth()) return;
    const btn = document.getElementById('like-btn-'+postId);
    if (btn.disabled) return; btn.disabled = true;
    fetch(API_PATH+'like.php?like_post='+postId).then(r=>r.json()).then(data=>{
        if (data.status==='liked'){btn.classList.add('active');btn.querySelector('i').classList.replace('bi-heart','bi-heart-fill')}
        else if(data.status==='unliked'){btn.classList.remove('active');btn.querySelector('i').classList.replace('bi-heart-fill','bi-heart')}
        else if(data.message==='login_required') showAuthModal();
        
        // Render angka format baru
        if(data.formatted_count !== undefined) {
            btn.querySelector('.count').innerText = data.formatted_count;
        } else if(data.count !== undefined) {
            btn.querySelector('.count').innerText = data.count;
        }
        btn.disabled=false;
    }).catch(()=>btn.disabled=false);
}

function repostPost(postId) {
    if (!checkAuth()) return;
    const btn = document.getElementById('repost-btn-'+postId);
    if (btn.disabled) return; btn.disabled = true;
    fetch(API_PATH+'repost.php?repost='+postId).then(r=>r.json()).then(data=>{
        if(data.status==='reposted') btn.classList.add('active');
        else if(data.status==='unreposted') btn.classList.remove('active');
        
        // Render angka format baru
        if(data.formatted_count !== undefined) {
            btn.querySelector('.count').innerText = data.formatted_count;
        } else if(data.count !== undefined) {
            btn.querySelector('.count').innerText = data.count;
        }
        btn.disabled=false;
    }).catch(()=>btn.disabled=false);
}

function bookmarkPost(postId) {
    if (!checkAuth()) return;
    const btn = document.getElementById('bookmark-btn-'+postId);
    if (btn.disabled) return; btn.disabled = true;
    fetch(API_PATH+'bookmark.php?bookmark_post='+postId).then(r=>r.json()).then(data=>{
        if(data.status==='bookmarked'){btn.classList.add('active');btn.querySelector('i').classList.replace('bi-bookmark','bi-bookmark-fill')}
        else if(data.status==='unbookmarked'){btn.classList.remove('active');btn.querySelector('i').classList.replace('bi-bookmark-fill','bi-bookmark')}
        btn.disabled=false;
    }).catch(()=>btn.disabled=false);
}

let currentMusic = null;
function toggleMusic(btn, url) {
    const player = btn.closest('.post-music-player');
    const audio = player.querySelector('.music-audio');
    const waveContainer = player.querySelector('.music-wave-container');
    const icon = btn.querySelector('i');
    
    if (currentMusic && currentMusic !== audio) {
        currentMusic.pause();
        currentMusic.currentTime = 0;
        const oldPlayer = currentMusic.closest('.post-music-player');
        if (oldPlayer) {
            oldPlayer.querySelector('.music-wave-container').classList.remove('active');
            oldPlayer.querySelector('.music-play-btn i').classList.replace('bi-pause-circle-fill', 'bi-play-circle-fill');
            const oldProgressBar = oldPlayer.querySelector('.music-progress-bar');
            if (oldProgressBar) oldProgressBar.style.width = '0%';
        }
    }
    
    if (audio.paused) {
        audio.play();
        icon.classList.replace('bi-play-circle-fill', 'bi-pause-circle-fill');
        waveContainer.classList.add('active');
        currentMusic = audio;
    } else {
        audio.pause();
        icon.classList.replace('bi-pause-circle-fill', 'bi-play-circle-fill');
        waveContainer.classList.remove('active');
    }
}

function updateMusicProgress(audio) {
    const player = audio.closest('.post-music-player');
    const progressBar = player.querySelector('.music-progress-bar');
    if (progressBar && audio.duration) {
        const percent = (audio.currentTime / audio.duration) * 100;
        progressBar.style.width = percent + '%';
    }
}

function seekMusic(container, event) {
    const audio = container.closest('.post-music-player').querySelector('.music-audio');
    if (!audio.duration) return;
    const rect = container.getBoundingClientRect();
    const percent = (event.clientX - rect.left) / rect.width;
    audio.currentTime = percent * audio.duration;
}

function resetMusicProgress(audio) {
    const player = audio.closest('.post-music-player');
    const progressBar = player.querySelector('.music-progress-bar');
    const icon = player.querySelector('.music-play-btn i');
    const waveContainer = player.querySelector('.music-wave-container');
    if (progressBar) progressBar.style.width = '0%';
    if (icon) icon.classList.replace('bi-pause-circle-fill', 'bi-play-circle-fill');
    if (waveContainer) waveContainer.classList.remove('active');
    currentMusic = null;
}

function deletePost(postId) {
    if (!confirm('Delete this post?')) return;
    fetch(API_PATH+'delete_post.php?post_id='+postId).then(r=>r.json()).then(data=>{
        if(data.status==='deleted'){
            const el=document.getElementById('post-'+postId);
            if(el){el.style.opacity='0';el.style.transition='opacity .3s';setTimeout(()=>el.remove(),300)}
        }
    });
}

function toggleFollow(userId) {
    if (!checkAuth()) return;
    const btn = document.getElementById('follow-btn') || document.getElementById('follow-btn-'+userId);
    if (!btn) return;
    fetch(API_PATH+'follow.php?follow_user='+userId).then(r=>r.json()).then(data=>{
        if(data.status==='followed'){btn.classList.remove('unfollow');btn.classList.add('following');btn.innerText='Following'}
        else if(data.status==='unfollowed'){btn.classList.remove('following');btn.classList.add('unfollow');btn.innerText='Follow'}
        else if(data.message==='login_required') showAuthModal();
    });
}

function focusRootComment(postId) {
    if (!checkAuth()) return;
    toggleComments(postId);
    const input=document.getElementById('comment-input-'+postId);
    if(input){input.focus();input.scrollIntoView({behavior:'smooth',block:'nearest'})}
}

function toggleComments(postId) {
    if (!checkAuth()) return;
    const section = document.getElementById('comments-post-' + postId);
    if (section) {
        const isHidden = section.style.display === 'none';
        section.style.display = isHidden ? 'block' : 'none';
        if (isHidden) {
            section.scrollIntoView({behavior:'smooth',block:'nearest'});
        }
    }
}

function toggleReplyForm(commentId, postId) {
    if (!checkAuth()) return;
    const form=document.getElementById('reply-form-'+commentId);
    if(!form) return;
    const isVisible=form.style.display!=='none';
    document.querySelectorAll('.inline-reply-form').forEach(f=>f.style.display='none');
    if(!isVisible){form.style.display='block';const i=form.querySelector('input[name="comment_content"]');if(i){i.focus();form.scrollIntoView({behavior:'smooth',block:'nearest'})}}
}

function toggleChildren(commentId) {
    const c=document.getElementById('children-'+commentId);
    const l=document.getElementById('toggle-label-'+commentId);
    if(!c) return;
    const isHidden=c.style.display==='none';
    c.style.display=isHidden?'block':'none';
    if(l){const cnt=c.querySelectorAll(':scope > .comment-node').length;l.textContent=isHidden?'Hide':cnt+' replies'}
}

function switchTab(tabName, element) {
    document.querySelectorAll('.profile-tab-item').forEach(el=>el.classList.remove('active'));
    element.classList.add('active');
    const showPosts=tabName==='posts';
    document.getElementById('tab-posts').style.display=showPosts?'block':'none';
    document.getElementById('tab-badges').style.display=showPosts?'none':'block';
}

function openStory(url,user){
    document.getElementById('stImg').src=url;
    document.getElementById('stUser').innerText='@'+user;
    new bootstrap.Modal(document.getElementById('vStory')).show();
}

function triggerNotif(message, type = 'info', link = '') {
    const el = document.getElementById('iosNotif');
    const iconBox = document.getElementById('iosIconBox');
    const iosMsg = document.getElementById('iosMsg');
    const iosType = document.getElementById('iosType');
    const iosTime = document.getElementById('iosTime');
    
    iconBox.className = 'ios-icon';
    iosMsg.innerText = message;
    
    const typeConfig = {
        'like': { icon: 'bi-heart-fill', label: 'Like', class: 'like-icon' },
        'comment': { icon: 'bi-chat-fill', label: 'Comment', class: 'comment-icon' },
        'follow': { icon: 'bi-person-plus-fill', label: 'Follow', class: 'follow-icon' },
        'post': { icon: 'bi-rocket-takeoff-fill', label: 'New Post', class: 'post-icon' },
        'dm': { icon: 'bi-envelope-fill', label: 'Message', class: 'dm-icon' },
        'info': { icon: 'bi-bell-fill', label: 'PostAja', class: '' }
    };
    
    const config = typeConfig[type] || typeConfig['info'];
    iconBox.innerHTML = '<i class="bi ' + config.icon + '"></i>';
    if (config.class) iconBox.classList.add(config.class);
    iosType.innerText = config.label;
    iosTime.innerText = 'baru';
    
    el.onclick = function() {
        if (link) window.location.href = link;
        dismissIosNotif();
    };
    
    el.classList.add('active');
    if(window.navigator.vibrate) window.navigator.vibrate([50, 100, 50]);
    clearTimeout(window.iosNotifTimeout);
    window.iosNotifTimeout = setTimeout(() => dismissIosNotif(), 5500);
}

function dismissIosNotif() {
    const el = document.getElementById('iosNotif');
    el.classList.remove('active');
    el.onclick = null;
}

let offset=10,loading=false,noMore=false;
window.onscroll=function(){
    if(document.getElementById('chatWindow')) return;
    if(noMore||loading) return;
    if((window.innerHeight+window.scrollY)>=document.body.offsetHeight-800){
        const t=document.getElementById('loading-trigger');
        if(!t) return;
        loading=true;
        fetch(API_PATH+'load_posts.php?offset='+offset).then(r=>r.json()).then(data=>{
            if(data.html&&data.html.trim().length>0){
                document.getElementById('feed-container').insertAdjacentHTML('beforeend',data.html);
                offset+=10;loading=false;
            } else {noMore=true;t.style.display='none';const e=document.createElement('div');e.className='py-4 text-muted small text-center';e.textContent='All posts have been displayed';t.parentNode.insertBefore(e,t.nextSibling);}
        }).catch(()=>loading=false);
    }
};

<?php if (isset($_SESSION['user_id'])): ?>
let lastNotifId = 0;
let lastDmId = 0;

function checkNotifications() {
    fetch(API_PATH+'notif.php').then(r=>r.json()).then(data=>{
        if(data && data.id && data.id > lastNotifId) {
            lastNotifId = data.id;
            const type = data.type || 'info';
            const link = data.link || '';
            triggerNotif(data.message, type, link);
        }
    });
}

function checkDMs() {
    fetch(API_PATH+'dm_api.php').then(r=>r.json()).then(data=>{
        if(data && data.id && data.id > lastDmId) {
            lastDmId = data.id;
            triggerNotif(data.message, 'dm', data.link);
        }
    });
}

setInterval(() => { checkNotifications(); checkDMs(); }, 5000);
checkNotifications();
checkDMs();

<?php if (!empty($_SESSION['show_onboarding'])): ?>
document.addEventListener('DOMContentLoaded', function () {
    var m = document.getElementById('onboardModal');
    if (m) { new bootstrap.Modal(m).show(); }
});
<?php $_SESSION['show_onboarding'] = null; unset($_SESSION['show_onboarding']); ?>
<?php endif; ?>

<?php if (!empty($_SESSION['suspended'])): ?>
document.addEventListener('DOMContentLoaded', function () {
    var sm = document.getElementById('suspendedModal');
    if (sm) { new bootstrap.Modal(sm).show(); }
});
<?php unset($_SESSION['suspended']); ?>
<?php endif; ?>
<?php endif; ?>

let maintenanceMode = false;
function checkMaintenanceMode() {
    fetch(API_PATH+'maintenance_check.php').then(r=>r.json()).then(data=>{
        if (data.maintenance && !maintenanceMode) {
            maintenanceMode = true;
            var mm = document.getElementById('maintenanceModal');
            if (mm) { new bootstrap.Modal(mm, {backdrop: 'static', keyboard: false}).show(); }
        } else if (!data.maintenance && maintenanceMode) {
            maintenanceMode = false;
            var mm = document.getElementById('maintenanceModal');
            if (mm) { bootstrap.Modal.getInstance(mm)?.hide(); }
        }
    }).catch(()=>{});
}
setInterval(checkMaintenanceMode, 3000);
checkMaintenanceMode();
</script>
<?php if (defined('HCAPTCHA_SITE_KEY') && HCAPTCHA_SITE_KEY): ?>
<?php endif; ?>
</body></html>
