<?php

define('STIKER_DB', ROOT . '/stiker.db');
define('STIKER_DIR', ROOT . '/stickers/');
define('STIKER_MAX_SIZE', 500 * 1024);
define('STIKER_ALLOWED', ['image/png', 'image/gif', 'image/webp', 'image/jpeg']);

if (!is_dir(STIKER_DIR)) {
    mkdir(STIKER_DIR, 0755, true);
}

$stiker_db = new SQLite3(STIKER_DB);
$stiker_db->exec('PRAGMA journal_mode=WAL');

$stiker_db->exec('CREATE TABLE IF NOT EXISTS stickers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    file_path TEXT,
    name TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)');

function addColumnIfMissingStiker(SQLite3 $db, string $table, string $col, string $def): void {
    $res = $db->query("PRAGMA table_info($table)");
    while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
        if ($row['name'] === $col) return;
    }
    $db->exec("ALTER TABLE $table ADD COLUMN $col $def");
}

function getUserStickers(SQLite3 $db, int $userId): array {
    $stmt = $db->prepare('SELECT * FROM stickers WHERE user_id = :uid ORDER BY created_at DESC');
    $stmt->bindValue(':uid', $userId, SQLITE3_INTEGER);
    $res = $stmt->execute();
    $stickers = [];
    while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
        $stickers[] = $row;
    }
    return $stickers;
}

function uploadSticker(SQLite3 $db, array $file, int $userId, string $name): array {
    $result = ['success' => false, 'path' => '', 'error' => ''];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $result['error'] = 'Upload failed';
        return $result;
    }
    
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    
    if (!in_array($mimeType, STIKER_ALLOWED)) {
        $result['error'] = 'Only PNG, GIF, WebP, JPEG allowed';
        return $result;
    }
    
    if ($file['size'] > STIKER_MAX_SIZE) {
        $result['error'] = 'Max file size 500KB';
        return $result;
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    if ($extension === 'gif') $extension = 'gif';
    
    $filename = $userId . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    $targetPath = STIKER_DIR . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        $stmt = $db->prepare('INSERT INTO stickers (user_id, file_path, name) VALUES (:uid, :path, :name)');
        $stmt->bindValue(':uid', $userId, SQLITE3_INTEGER);
        $stmt->bindValue(':path', 'stickers/' . $filename);
        $stmt->bindValue(':name', $name ?: 'Sticker');
        $stmt->execute();
        
        $result['success'] = true;
        $result['path'] = 'stickers/' . $filename;
    } else {
        $result['error'] = 'Failed to save file';
    }
    
    return $result;
}

function deleteSticker(SQLite3 $db, int $stickerId, int $userId): bool {
    $stmt = $db->prepare('SELECT file_path FROM stickers WHERE id = :id AND user_id = :uid');
    $stmt->bindValue(':id', $stickerId, SQLITE3_INTEGER);
    $stmt->bindValue(':uid', $userId, SQLITE3_INTEGER);
    $row = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    
    if ($row) {
        $filePath = ROOT . '/' . $row['file_path'];
        if (file_exists($filePath)) {
            @unlink($filePath);
        }
        $db->exec("DELETE FROM stickers WHERE id = $stickerId");
        return true;
    }
    return false;
}
