<?php

function isSuperAdmin(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'superadmin';
}
function isAdmin(): bool {
    return isset($_SESSION['role']) && in_array($_SESSION['role'], ['admin','superadmin']);
}
function isPremiumUser(SQLite3 $db, int $userId): bool {
    $stmt = $db->prepare('SELECT is_premium FROM users WHERE id = :id');
    $stmt->bindValue(':id', $userId, SQLITE3_INTEGER);
    $result = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    return $result && $result['is_premium'] == 1;
}

function censorMessage(string $text): array {
    $bad_words = ['anjing','goblok','ngentod','asu','kontol','bajingan','babi','bangsat','keparat','tai','tolol','idiot','brengsek','setan','sialan'];
    $has_bad_word = false;
    foreach ($bad_words as $word) {
        if (stripos($text, $word) !== false) {
            $text = preg_replace('/' . preg_quote($word, '/') . '/i', str_repeat('*', strlen($word)), $text);
            $has_bad_word = true;
        }
    }
    return ['text' => $text, 'violation' => $has_bad_word];
}

function hashtagify(string $text, string $root_path = ''): string {
    $safe = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    // Convert #hashtag to links
    $safe = preg_replace_callback('/#(\w+)/u', function($m) use ($root_path) {
        $tag = htmlspecialchars($m[1]);
        return '<a href="' . $root_path . 'search/?q=%23' . urlencode($m[1]) . '&type=posts" class="hashtag-link">#' . $tag . '</a>';
    }, $safe);
    // Convert @mention to links
    $safe = preg_replace_callback('/@(\w+)/u', function($m) use ($root_path) {
        $u = htmlspecialchars($m[1]);
        return '<a href="' . $root_path . 'profile/?u=' . urlencode($m[1]) . '" class="mention-link">@' . $u . '</a>';
    }, $safe);
    return $safe;
}

function getAvatarHtml(string $username, string $avatar_url, int $size = 36): string {
    $style = "width:{$size}px;height:{$size}px;border-radius:50%;";
    if (!empty($avatar_url)) {
        $rp = $GLOBALS['root_path'] ?? '';
        if (!preg_match('~^https?://|^//|^/~', $avatar_url)) {
            $avatar_url = $rp . ltrim($avatar_url, '/');
        }
        return '<img src="' . htmlspecialchars($avatar_url) . '" style="' . $style . 'object-fit:cover;" alt="' . htmlspecialchars($username) . '">';
    }
    $letter = strtoupper(substr($username, 0, 1));
    $fs = round($size * 0.4);
    return '<div style="' . $style . 'background:linear-gradient(135deg,#0d6efd,#0056b3);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:' . $fs . 'px;color:#fff;">' . $letter . '</div>';
}

function getUnreadNotifCount(SQLite3 $db, int $uid): int {
    return (int)$db->querySingle("SELECT COUNT(*) FROM notifications WHERE user_id=$uid AND is_read=0");
}

function getUnreadDmCount(SQLite3 $db, int $uid): int {
    return (int)$db->querySingle("SELECT COUNT(*) FROM messages WHERE receiver_id=$uid AND is_read=0");
}

function sendNotification(SQLite3 $db, int $to_uid, int $from_uid, string $type, string $message, string $link = ''): void {
    if ($to_uid === $from_uid) return;
    $stmt = $db->prepare('INSERT INTO notifications (user_id, from_user_id, type, message, link) VALUES (:u,:f,:t,:m,:l)');
    $stmt->bindValue(':u', $to_uid, SQLITE3_INTEGER);
    $stmt->bindValue(':f', $from_uid, SQLITE3_INTEGER);
    $stmt->bindValue(':t', $type);
    $stmt->bindValue(':m', $message);
    $stmt->bindValue(':l', $link);
    $stmt->execute();
}

function renderThreadedComments(array $cbp, int $parent_id, int $post_id, int $depth = 0): string {
    if (!isset($cbp[$parent_id]) || $depth > 4) return '';
    $html = '';
    foreach ($cbp[$parent_id] as $cm) {
        $has_children = isset($cbp[$cm['id']]);
        $child_count  = $has_children ? count($cbp[$cm['id']]) : 0;
        $indent_class = $depth > 0 ? 'comment-reply-node' : '';
        $av  = getAvatarHtml($cm['username'], $cm['avatar_url'] ?? '', $depth === 0 ? 32 : 26);
        $cid = (int)$cm['id'];
        $pid = (int)$post_id;

        $comment_user_id = (int)($cm['user_id'] ?? 0);
        $html .= '<div class="comment-node ' . $indent_class . '" data-comment-id="' . $cid . '" data-user-id="' . $comment_user_id . '">';
        if ($depth > 0) $html .= '<div class="thread-connector"><span class="thread-line"></span></div>';
        $html .= '<div class="comment-body-wrap">';
        $html .= '<div class="comment-avatar">' . $av . '</div>';
        $html .= '<div class="comment-content-area">';
        $html .= '<div class="comment-bubble copyable-text">';
        $html .= '<span class="comment-author">@' . htmlspecialchars($cm['username']) . '</span>';
        $html .= '<span class="comment-text">' . nl2br(htmlspecialchars($cm['content'])) . '</span>';
        $html .= '</div>';
        $html .= '<div class="comment-meta">';
        $html .= '<span class="comment-time">' . date('d M, H:i', strtotime($cm['created_at'])) . '</span>';
        $html .= ' · <button class="btn-reply-toggle" onclick="toggleReplyForm(' . $cid . ',' . $pid . ')"><i class="bi bi-reply"></i> Reply</button>';
        if ($child_count > 0) {
            $html .= ' · <button class="btn-toggle-children" onclick="toggleChildren(' . $cid . ')"><span id="toggle-label-' . $cid . '">' . $child_count . ' replies</span></button>';
        }
        $html .= '</div>';
        $html .= '<div id="reply-form-' . $cid . '" class="inline-reply-form" style="display:none;">';
        $html .= '<form method="POST" action="' . ($GLOBALS['root_path'] ?? '') . 'api/comment.php" class="d-flex gap-2 align-items-center mt-1">';
        $html .= csrfField();
        $html .= '<input type="hidden" name="post_id" value="' . $pid . '">';
        $html .= '<input type="hidden" name="parent_id" value="' . $cid . '">';
        $html .= '<input type="text" name="comment_content" class="reply-input" placeholder="Reply to @' . htmlspecialchars($cm['username']) . '..." required autocomplete="off">';
        $html .= '<button name="create_comment" class="btn-send-reply"><i class="bi bi-send-fill"></i></button>';
        $html .= '</form></div>';
        if ($has_children) {
            $html .= '<div id="children-' . $cid . '" class="comment-children">' . renderThreadedComments($cbp, $cid, $post_id, $depth + 1) . '</div>';
        }
        $html .= '</div></div></div>';
    }
    return $html;
}

function renderPostHtml(array $post, SQLite3 $db): string {
    global $root_path;
    $rp = $root_path ?? '';

    ob_start();
    $role = $post['role'] ?? 'user';
    $is_superadmin = $role === 'superadmin';
    $is_admin = $role === 'admin';
    $is_silo = in_array($post['username'], ['silo','rizal']);
    $show_username = true; // Always show username
    if ($is_silo)                      { $role_class = "silo-anim"; }
    elseif ($is_admin) { $role_class = "role-admin"; }
    else                               { $role_class = "role-user"; }
    
    $is_premium = isset($post['is_premium']) && $post['is_premium'] == 1;

    // Likes
    $like_count = (int)$db->querySingle("SELECT COUNT(*) FROM likes WHERE post_id=" . (int)$post['id']);
    $is_liked   = false;
    if (isset($_SESSION['user_id'])) {
        $is_liked = (bool)$db->querySingle("SELECT COUNT(*) FROM likes WHERE post_id=" . (int)$post['id'] . " AND user_id=" . (int)$_SESSION['user_id']);
    }

    // Reposts
    $repost_count = (int)$db->querySingle("SELECT COUNT(*) FROM reposts WHERE post_id=" . (int)$post['id']);
    $is_reposted  = false;
    if (isset($_SESSION['user_id'])) {
        $is_reposted = (bool)$db->querySingle("SELECT COUNT(*) FROM reposts WHERE post_id=" . (int)$post['id'] . " AND user_id=" . (int)$_SESSION['user_id']);
    }

    // Bookmarks
    $is_bookmarked = false;
    if (isset($_SESSION['user_id'])) {
        $is_bookmarked = (bool)$db->querySingle("SELECT COUNT(*) FROM bookmarks WHERE post_id=" . (int)$post['id'] . " AND user_id=" . (int)$_SESSION['user_id']);
    }

    // Comments
    $all_cmt_stmt = $db->prepare('SELECT comments.*, users.username, users.avatar_url FROM comments JOIN users ON comments.user_id = users.id WHERE post_id=:p ORDER BY comments.created_at ASC');
    $all_cmt_stmt->bindValue(':p', (int)$post['id'], SQLITE3_INTEGER);
    $all_cmt_res   = $all_cmt_stmt->execute();
    $cbp = []; $total_cmt = 0;
    while ($cm = $all_cmt_res->fetchArray(SQLITE3_ASSOC)) {
        $pid = is_null($cm['parent_id']) ? 0 : (int)$cm['parent_id'];
        $cbp[$pid][] = $cm;
        $total_cmt++;
    }

    $can_delete = isset($_SESSION['user_id']) && (
        $_SESSION['user_id'] == $post['user_id'] ||
        in_array($_SESSION['role'] ?? '', ['admin','superadmin'])
    );

    $role_class  = ($post['role'] === 'superadmin') ? 'silo-anim' : '';
    $badges_html = getRoleBadgeHtml($post['role'], (bool)($post['is_premium'] ?? 0), $post['username']);

    $avatar_html = getAvatarHtml($post['username'], $post['avatar_url'] ?? '', 48);
    ?>
    <div class="post-card mb-0 border-bottom p-3" id="post-<?= $post['id'] ?>">
        <div class="d-flex gap-3">
            <a href="<?= $rp ?>profile/?u=<?= urlencode($post['username']) ?>" class="flex-shrink-0">
                <div class="modern-avatar"><?= $avatar_html ?></div>
            </a>
            <div class="flex-grow-1">
                <div class="d-flex align-items-center gap-1 flex-wrap justify-content-between">
                    <div class="d-flex align-items-center gap-1 flex-wrap">
                        <?php if ($show_username): ?>
                        <div class="d-flex align-items-center gap-1">
                            <a href="<?= $rp ?>profile/?u=<?= urlencode($post['username']) ?>" class="fw-bold text-decoration-none text-dark <?= $role_class ?>">@<?= htmlspecialchars($post['username']) ?></a>
                            <?= $badges_html ?>
                        </div>
                        <?php endif; ?>
                        <span class="text-muted small"> • <?= date('d M', strtotime($post['created_at'])) ?></span>
                    </div>
                    <div class="d-flex gap-1">
                        <a href="<?= $rp ?>post/?id=<?= $post['id'] ?>" class="btn-action text-muted" style="font-size:0.75rem;" title="View post"><i class="bi bi-arrows-angle-expand"></i></a>
                        <?php if ($can_delete): ?>
                            <button onclick="deletePost(<?= $post['id'] ?>)" class="btn-action text-danger" style="font-size:0.8rem;" title="Delete"><i class="bi bi-trash3"></i></button>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="post-content mt-1 mb-2 text-dark copyable-text" style="white-space:pre-wrap;"><?= nl2br(hashtagify($post['content'], $rp)) ?></div>
                <?php
                $rawImg = $post['image_url'] ?? '';
                $imgUrl = '';
                if (!empty($rawImg)) {
                    if (preg_match('~^https?://|^//|^/~', $rawImg)) {
                        $imgUrl = $rawImg;
                    } else {
                        $imgUrl = $rp . ltrim($rawImg, '/');
                    }
                }
                if (!empty($imgUrl)): 
                    $fallback = $rp . 'assets/404-not-found.png';
                ?>
                    <div class="post-image-container mb-3 overflow-hidden rounded-4 border">
                        <img src="<?= htmlspecialchars($imgUrl) ?>" class="img-fluid w-100" loading="lazy" style="max-height:400px;object-fit:cover;" onerror="this.src='<?= $fallback ?>'; this.onerror=null;">
                    </div>
                <?php endif; ?>
                <?php 
                $musicUrl = $post['music_url'] ?? '';
                $musicTitle = $post['music_title'] ?? '';
                if (!empty($musicUrl)): ?>
                    <div class="post-music-player mb-3 p-3 rounded-4" style="background:linear-gradient(135deg,#1a1a2e,#16213e);border:1px solid #333;">
                        <div class="d-flex align-items-center gap-3">
                            <button class="music-play-btn btn btn-link text-white p-0" onclick="toggleMusic(this, '<?= htmlspecialchars($musicUrl) ?>')">
                                <i class="bi bi-play-circle-fill fs-4"></i>
                            </button>
                            <div class="flex-grow-1">
                                <div class="music-wave-container">
                                    <div class="music-wave">
                                        <span></span><span></span><span></span><span></span><span></span>
                                    </div>
                                </div>
                                <div class="music-info">
                                    <div class="text-white small fw-bold"><?= htmlspecialchars($musicTitle ?: 'Music') ?></div>
                                    <div class="text-secondary small"><?= htmlspecialchars($post['username']) ?></div>
                                </div>
                                <div class="music-progress-container" style="height:4px;background:rgba(255,255,255,0.2);border-radius:2px;margin-top:8px;overflow:hidden;cursor:pointer;" onclick="seekMusic(this, event)">
                                    <div class="music-progress-bar" style="height:100%;background:linear-gradient(90deg,#0d6efd,#00d4ff);width:0%;border-radius:2px;transition:width 0.1s;"></div>
                                </div>
                            </div>
                            <i class="bi bi-music-note-beamed text-white-50 fs-5"></i>
                        </div>
                        <audio class="music-audio" src="<?= htmlspecialchars($musicUrl) ?>" preload="none" onended="resetMusicProgress(this)" ontimeupdate="updateMusicProgress(this)"></audio>
                    </div>
                <?php endif; ?>

                <div class="d-flex align-items-center gap-2 mb-2 flex-wrap" style="max-width:450px;">
                    <button onclick="likePost(<?= $post['id'] ?>)" class="btn-action like-btn <?= $is_liked ? 'active' : '' ?>" id="like-btn-<?= $post['id'] ?>">
                        <i class="bi <?= $is_liked ? 'bi-heart-fill' : 'bi-heart' ?>"></i>
                        <span class="count"><?= $like_count ?></span>
                    </button>
                    <button class="btn-action comment-trigger" onclick="toggleComments(<?= $post['id'] ?>)">
                        <i class="bi bi-chat"></i>
                        <span class="count"><?= $total_cmt ?></span>
                    </button>
                    <button onclick="repostPost(<?= $post['id'] ?>)" class="btn-action repost-btn <?= $is_reposted ? 'active' : '' ?>" id="repost-btn-<?= $post['id'] ?>" title="Repost">
                        <i class="bi bi-repeat"></i>
                        <span class="count"><?= $repost_count ?></span>
                    </button>
                    <button onclick="bookmarkPost(<?= $post['id'] ?>)" class="btn-action bookmark-btn <?= $is_bookmarked ? 'active' : '' ?>" id="bookmark-btn-<?= $post['id'] ?>" title="Bookmark">
                        <i class="bi <?= $is_bookmarked ? 'bi-bookmark-fill' : 'bi-bookmark' ?>"></i>
                    </button>
                    <div class="dropdown">
                        <button class="btn-action" data-bs-toggle="dropdown" title="More">
                            <i class="bi bi-three-dots"></i>
                        </button>
                        <ul class="dropdown-menu border-0 shadow rounded-4">
                            <li><button class="dropdown-item" onclick="copyPostText(<?= $post['id'] ?>)"><i class="bi bi-clipboard me-2"></i> Copy Text</button></li>
                            <li><button class="dropdown-item" onclick="translatePost(<?= $post['id'] ?>)"><i class="bi bi-translate me-2"></i> Translate</button></li>
                            <li><button class="dropdown-item text-danger" onclick="reportPost(<?= $post['id'] ?>)"><i class="bi bi-flag me-2"></i> Report</button></li>
                        </ul>
                    </div>
                    <a href="<?= $rp ?>dm/?with=<?= urlencode($post['username']) ?>" class="btn-action" title="Send DM" onclick="return checkAuth(event)">
                        <i class="bi bi-send"></i>
                    </a>
                </div>

                <div class="comment-section" id="comments-post-<?= $post['id'] ?>" style="display:none;">
                    <div class="comment-thread"><?= renderThreadedComments($cbp, 0, (int)$post['id'], 0) ?></div>
                    <form method="POST" action="<?= $rp ?>api/comment.php" class="root-comment-form d-flex gap-2 align-items-center mt-3" onsubmit="return checkAuth(event)">
                        <?= csrfField() ?>
                        <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                        <input type="hidden" name="parent_id" value="">
                        <div class="root-avatar"><?= getAvatarHtml($_SESSION['username'] ?? '?', $_SESSION['avatar_url'] ?? '', 30) ?></div>
                        <input type="text" name="comment_content" id="comment-input-<?= $post['id'] ?>" class="root-comment-input" placeholder="Add a comment..." required autocomplete="off">
                        <button name="create_comment" class="btn-send-comment"><i class="bi bi-send-fill"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php return ob_get_clean();
}
function getRoleBadgeHtml(string $role, bool $isPremium = false, string $username = ''): string {
    $badges = '';
    if ($role === 'superadmin' && in_array($username, ['silo', 'rizal'])) {
        $badges .= '<span class="role-badge superadmin" title="Super Administrator"><i class="bi bi-star-fill"></i><span>Verified</span></span>';
    } elseif ($role === 'admin') {
        $badges .= '<span class="role-badge admin" title="Administrator"><i class="bi bi-shield-check-fill"></i><span>Admin</span></span>';
    }
    if ($isPremium) {
        $badges .= '<span class="role-badge premium" title="Premium User"><i class="bi bi-gem"></i><span>Premium</span></span>';
    }
    return $badges;
}

function getPremiumBadgeHtml(): string {
    return '<span class="role-badge premium" title="Premium User"><i class="bi bi-gem"></i><span>Premium</span></span>';
}

function checkContentModeration(SQLite3 $db, int $userId, string $content): array {
    $bad_words = ['anjing','goblok','ngentod','asu','kontol','bajingan','babi','bangsat','keparat','tai','tolol','idiot','brengsek','setan','sialan','memek','pepek','kotek','jablay','ngewe','ngentot','gembel','crot','syrng','colmek','jilbab','kontol','peler'];
    $has_bad_word = false;
    $found_words = [];
    $text_lower = strtolower($content);
    
    foreach ($bad_words as $word) {
        if (stripos($text_lower, $word) !== false) {
            $has_bad_word = true;
            $found_words[] = $word;
        }
    }
    
    if ($has_bad_word) {
        $stmt = $db->prepare('SELECT violation_count FROM users WHERE id = :id');
        $stmt->bindValue(':id', $userId, SQLITE3_INTEGER);
        $result = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
        $current_count = $result ? (int)$result['violation_count'] : 0;
        $new_count = $current_count + 1;
        
        $update = $db->prepare('UPDATE users SET violation_count = :c WHERE id = :id');
        $update->bindValue(':c', $new_count, SQLITE3_INTEGER);
        $update->bindValue(':id', $userId, SQLITE3_INTEGER);
        $update->execute();
        
        if ($new_count >= 3) {
            $ban_time = date('Y-m-d H:i:s');
            $ban_stmt = $db->prepare('UPDATE users SET is_active = 0, banned_at = :bt, ban_reason = :br WHERE id = :id');
            $ban_stmt->bindValue(':bt', $ban_time);
            $ban_stmt->bindValue(':br', 'Violated content policy ' . $new_count . ' times. Inappropriate words found: ' . implode(', ', $found_words));
            $ban_stmt->bindValue(':id', $userId, SQLITE3_INTEGER);
            $ban_stmt->execute();
            
            return [
                'allowed' => false,
                'banned' => true,
                'violation_count' => $new_count,
                'message' => 'Your account has been temporarily suspended due to violating our content policy. You have received ' . $new_count . ' violations. You may submit an appeal.'
            ];
        }
        
        return [
            'allowed' => true,
            'banned' => false,
            'violation_count' => $new_count,
            'message' => 'Warning: Your post contains inappropriate language. This is violation ' . $new_count . '/3. After 3 violations, your account will be suspended.',
            'censored' => true
        ];
    }
    
    return ['allowed' => true, 'banned' => false, 'violation_count' => 0, 'message' => ''];
}

function submitAppeal(SQLite3 $db, int $userId, string $reason): bool {
    $existing = $db->querySingle("SELECT id FROM appeals WHERE user_id = $userId AND status = 'pending'");
    if ($existing) {
        return false;
    }
    
    $stmt = $db->prepare('INSERT INTO appeals (user_id, reason) VALUES (:u, :r)');
    $stmt->bindValue(':u', $userId, SQLITE3_INTEGER);
    $stmt->bindValue(':r', $reason);
    $stmt->execute();
    
    if (stripos($reason, 'tolong') !== false) {
        $update = $db->prepare('UPDATE users SET is_active = 1, violation_count = 0 WHERE id = :id');
        $update->bindValue(':id', $userId, SQLITE3_INTEGER);
        $update->execute();
        
        $appeal_update = $db->prepare('UPDATE appeals SET status = :s, processed_at = :pa, admin_note = :an WHERE user_id = :u AND status = "pending"');
        $appeal_update->bindValue(':s', 'approved');
        $appeal_update->bindValue(':pa', date('Y-m-d H:i:s'));
        $appeal_update->bindValue(':an', 'Auto-approved: Appeal contains "tolong" - account restored');
        $appeal_update->bindValue(':u', $userId, SQLITE3_INTEGER);
        $appeal_update->execute();
        
        return true;
    }
    
    return true;
}

function generateCustomCaptcha(): string {
    $captcha = sprintf("%06d", mt_rand(0, 999999));
    $_SESSION['custom_captcha'] = $captcha;
    return $captcha;
}

function verifyCustomCaptcha(string $code): bool {
    if (empty($_SESSION['custom_captcha'])) return false;
    return ($_SESSION['custom_captcha'] === trim($code));
}

function handleDmImageUpload(array $file): array {
    $result = ['success' => false, 'path' => '', 'error' => ''];
    if ($file['error'] !== UPLOAD_ERR_OK) { $result['error'] = 'Upload failed: ' . $file['error']; return $result; }
    if ($file['size'] > 5 * 1024 * 1024) { $result['error'] = 'Max file size is 5MB'; return $result; }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    $allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (!in_array($mimeType, $allowed)) { $result['error'] = 'Only JPG, PNG, and WebP are allowed'; return $result; }
    $filename = bin2hex(random_bytes(16)) . '.webp';
    $targetDir = ROOT . '/dm/result/v1/';
    $targetPath = $targetDir . $filename;
    if (!is_dir($targetDir)) { mkdir($targetDir, 0755, true); }
    if ($mimeType === 'image/jpeg') { $src = imagecreatefromjpeg($file['tmp_name']); }
    elseif ($mimeType === 'image/png') { $src = imagecreatefrompng($file['tmp_name']); }
    else { $src = imagecreatefromwebp($file['tmp_name']); }
    if (!$src) { $result['error'] = 'Failed to process image'; return $result; }
    $ow = imagesx($src); $oh = imagesy($src); $maxDim = 1080;
    if ($ow > $maxDim || $oh > $maxDim) {
        $ratio = $ow > $oh ? $maxDim / $ow : $maxDim / $oh;
        $nw = (int)round($ow * $ratio); $nh = (int)round($oh * $ratio);
        $dst = imagecreatetruecolor($nw, $nh);
        imagealphablending($dst, false); imagesavealpha($dst, true);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $ow, $oh);
        imagedestroy($src); $src = $dst;
    }
    imagewebp($src, $targetPath, 82);
    imagedestroy($src);
    $result['success'] = true;
    $result['path'] = 'dm/result/v1/' . $filename;
    return $result;
}

function processAppeal(SQLite3 $db, int $appealId, string $action, string $adminNote = ''): bool {
    $stmt = $db->prepare('SELECT user_id FROM appeals WHERE id = :id');
    $stmt->bindValue(':id', $appealId, SQLITE3_INTEGER);
    $result = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    
    if (!$result) return false;
    
    $userId = (int)$result['user_id'];
    
    if ($action === 'approve') {
        $update = $db->prepare('UPDATE users SET is_active = 1, violation_count = 0 WHERE id = :id');
        $update->bindValue(':id', $userId, SQLITE3_INTEGER);
        $update->execute();
    } elseif ($action === 'permanent') {
        $update = $db->prepare('UPDATE users SET is_active = 0, is_permanent_ban = 1, ban_reason = :br WHERE id = :id');
        $update->bindValue(':br', $adminNote ?: 'Permanently banned by admin');
        $update->bindValue(':id', $userId, SQLITE3_INTEGER);
        $update->execute();
    }
    
    $appeal_update = $db->prepare('UPDATE appeals SET status = :s, admin_note = :an, processed_at = :pa WHERE id = :id');
    $appeal_update->bindValue(':s', $action === 'approve' ? 'approved' : 'rejected');
    $appeal_update->bindValue(':an', $adminNote);
    $appeal_update->bindValue(':pa', date('Y-m-d H:i:s'));
    $appeal_update->bindValue(':id', $appealId, SQLITE3_INTEGER);
    $appeal_update->execute();
    
    return true;
}
