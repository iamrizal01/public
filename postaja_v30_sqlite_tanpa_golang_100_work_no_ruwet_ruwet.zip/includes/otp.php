<?php
/**
 * PostAja OTP System
 * Handle OTP generation, Redis storage, and PHPMailer delivery via Gmail SMTP.
 * Redis Unix Socket: /home/silorizz/redis/redis.sock
 */

$vendor_path = '/home/silorizz/vendor/autoload.php';
if (file_exists($vendor_path)) {
    require_once $vendor_path;
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function secure_session_start() {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', 1);
        ini_set('session.cookie_samesite', 'Strict');
        session_start();
    }
}

function get_redis_connection() {
    try {
        $redis = new Redis();
        if (!$redis->connect('/home/silorizz/redis/redis.sock')) {
            throw new Exception("Could not connect to Redis socket.");
        }
        return $redis;
    } catch (Exception $e) {
        if (php_sapi_name() === 'cli') {
            throw $e;
        }
        http_response_code(500);
        $doc_root = rtrim($_SERVER['DOCUMENT_ROOT'], '/');
        if (file_exists($doc_root . '/500.php')) {
            include_once $doc_root . '/500.php';
        } else {
            echo "<h1>500 Internal Server Error</h1><p>Redis connection failed.</p>";
        }
        exit;
    }
}

function send_otp($email, $type = 'login', $user_data = []) {
    $clean_email = strtolower(trim($email));
    $clean_type = strtolower(trim($type));
    $otp_key = sprintf("%06d", mt_rand(0, 999999));
    
    // Generate Token 32 Digit
    $raw_string = random_bytes(16) . $clean_email . time();
    $token = substr(hash('sha256', md5($raw_string)), 0, 32);
    
    $redis = get_redis_connection();
    
    // Gabung OTP dan Data User jadi satu JSON Payload
    $payload = json_encode([
        'otp' => $otp_key,
        'email' => $clean_email,
        'type' => $clean_type,
        'user_data' => $user_data
    ]);
    
    // Set 3 Jam TTL
    $redis->setex("postaja_otp_{$clean_email}_{$clean_type}", 10800, $payload);
    $redis->setex("postaja_token_{$token}", 10800, $payload);

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'postajah@gmail.com'; 
        $mail->Password   = 'qwhh ylmt yhbf qeld'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('postajah@gmail.com', 'PostAja Security');
        $mail->addAddress($clean_email);
        $mail->isHTML(true);

        $subject = ($type === 'register') ? "Konfirmasi Pendaftaran PostAja" : "Kode Verifikasi Login PostAja";
        $mail->Subject = $subject;

        $magic_link = "https://postaja.web.id/verification/v1/?token=" . $token;

        $mail->Body = "
            <div style='font-family: \"Inter\", Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px; border: 1px solid #f0f0f0; border-radius: 12px; color: #333; line-height: 1.6;'>
                <div style='text-align: center; margin-bottom: 30px;'>
                    <h1 style='color: #0066ff; margin: 0; font-size: 28px; font-weight: 800;'>PostAja</h1>
                    <p style='color: #666; font-size: 14px; margin-top: 5px;'>Keamanan akun Anda adalah prioritas kami.</p>
                </div>
                <p style='font-size: 16px;'>Halo,</p>
                <p style='font-size: 16px;'>Kami menerima permintaan untuk verifikasi <b>" . ucfirst($type) . "</b> akun PostAja Anda. Silakan gunakan kode verifikasi di bawah ini untuk melanjutkan proses:</p>
                <div style='background-color: #f4f4f4; border-radius: 8px; padding: 25px; text-align: center; margin: 30px 0;'>
                    <span style='font-size: 32px; font-weight: 800; letter-spacing: 8px; color: #1a1a1a;'>{$otp_key}</span>
                </div>
                <p style='font-size: 16px; text-align: center;'>Atau klik tautan di bawah ini untuk memverifikasi secara otomatis (Magic Link):</p>
                <div style='text-align: center; margin: 20px 0;'>
                    <a href='{$magic_link}' style='background-color: #0066ff; color: #ffffff; padding: 12px 25px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px; display: inline-block;'>Verifikasi Akun Saya</a>
                </div>
                <p style='font-size: 14px; color: #ff3b30; font-weight: 600; text-align: center;'>Penting: Kode dan tautan ini akan kadaluwarsa dalam 3 Jam.</p>
                <hr style='border: 0; border-top: 1px solid #eee; margin: 30px 0;'>
                <div style='font-size: 12px; color: #999; text-align: center;'>
                    <p>&copy; " . date('Y') . " PostAja Development Team.</p>
                </div>
            </div>
        ";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("PHPMailer Error: " . $mail->ErrorInfo);
        return false;
    }
}

function verify_otp($email, $type, $user_otp) {
    $clean_email = strtolower(trim($email));
    $clean_type = strtolower(trim($type));
    $clean_user_otp = trim((string)$user_otp);
    
    $redis = get_redis_connection();
    $redis_key = "postaja_otp_{$clean_email}_{$clean_type}";
    
    $stored_data = $redis->get($redis_key);
    
    // --- SISTEM DEBUGGING ---
    $log_path = '/home/silorizz/postaja.web.id/otp_debug.log';
    $debug_msg = "[" . date('Y-m-d H:i:s') . "] TRY VERIFY | Email: $clean_email | Type: $clean_type | Input OTP: '$clean_user_otp' | Redis Data: " . ($stored_data ?: 'NULL') . "\n";
    file_put_contents($log_path, $debug_msg, FILE_APPEND);
    // ------------------------

    if (!$stored_data) return false;

    $decoded = json_decode($stored_data, true);
    $actual_otp = ($decoded && isset($decoded['otp'])) ? trim((string)$decoded['otp']) : trim((string)$stored_data);
    
    if ($actual_otp === $clean_user_otp) {
        $redis->del($redis_key);
        return true;
    }
    return false;
}
