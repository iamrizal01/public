<?php
// Secure Session Configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.gc_maxlifetime', 604800); // 7 days (Redis TTL peak)
session_set_cookie_params(604800);
session_start();
error_reporting(0); 
ini_set('display_errors', 0);
register_shutdown_function(function() {
    $error = error_get_last();
    
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
        
        while (ob_get_level()) {
            ob_end_clean();
        }
        
        
        $error_page = __DIR__ . '/../500.php'; 
        if (file_exists($error_page)) {
            include $error_page;
        } else {
            
            http_response_code(500);
            echo "<h1>500 Internal Server Error</h1><p>Sistem sedang bermasalah.</p>";
        }
        exit;
    }
});

$requested_root = '/home/silorizz/postaja.web.id';
// config.php is in includes/, so project root is dirname(__DIR__)
define('ROOT', is_dir($requested_root) ? $requested_root : dirname(__DIR__));
define('POSTS_PER_PAGE', 10);
define('UPLOAD_DIR', ROOT . '/uploads/');
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024);
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

define('GOOGLE_CLIENT_ID', '490037460905-7tfrltpehtjthn3h8uj3fme8ki5qsi0h.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'https://postaja.web.id/api/google_callback.php');

define('HCAPTCHA_SITE_KEY', 'a7366c1e-eafc-4426-b164-2cbe03ac0600');
define('HCAPTCHA_SECRET_KEY', 'ES_d4e21a050ad14c33b91557c1bf67e5d7');

function verifyHcaptcha(string $token): bool {
    if (empty($token) || empty(HCAPTCHA_SECRET_KEY)) {
        return false;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://hcaptcha.com/siteverify');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'response' => $token,
        'secret' => HCAPTCHA_SECRET_KEY,
        'sitekey' => HCAPTCHA_SITE_KEY,
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);
    if ($curl_error) {
        error_log('hCaptcha cURL error: ' . $curl_error);
        return false;
    }
    $result = json_decode($response, true);
    return isset($result['success']) && $result['success'] === true;
}

if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

function generateCsrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function getCsrfToken(): string {
    return $_SESSION['csrf_token'] ?? generateCsrfToken();
}

function verifyCsrfToken(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function csrfField(): string {
    return '<input type="hidden" name="csrf_token" value="' . getCsrfToken() . '">';
}

$db = new SQLite3(ROOT . '/data.db');
$db->exec('PRAGMA journal_mode=WAL');
$db->exec('PRAGMA encoding = "UTF-8"');

// Core tables
$db->exec('CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT "user",
    is_verified INTEGER DEFAULT 1,
    is_active INTEGER DEFAULT 1,
    bio TEXT DEFAULT "",
    avatar_url TEXT DEFAULT "",
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)');

$db->exec('CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    content TEXT,
    image_url TEXT DEFAULT "",
    music_url TEXT DEFAULT "",
    music_title TEXT DEFAULT "",
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)');

$db->exec('CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER,
    user_id INTEGER,
    parent_id INTEGER DEFAULT NULL,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)');

$db->exec('CREATE TABLE IF NOT EXISTS stories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    image_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)');

$db->exec('CREATE TABLE IF NOT EXISTS likes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER,
    user_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(post_id, user_id)
)');

$db->exec('CREATE TABLE IF NOT EXISTS follows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    follower_id INTEGER,
    following_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(follower_id, following_id)
)');

$db->exec('CREATE TABLE IF NOT EXISTS public_chat (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)');

$db->exec('CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    from_user_id INTEGER DEFAULT NULL,
    type TEXT DEFAULT "info",
    message TEXT,
    link TEXT DEFAULT "",
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)');

$db->exec('CREATE TABLE IF NOT EXISTS bookmarks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    post_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, post_id)
)');

$db->exec('CREATE TABLE IF NOT EXISTS reposts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    post_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, post_id)
)');

$db->exec('CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    receiver_id INTEGER,
    content TEXT,
    image_url TEXT DEFAULT "",
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)');

$db->exec('CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
)') or die($db->lastErrorMsg());

// Migrations
function addColumnIfMissing(SQLite3 $db, string $table, string $col, string $def): void {
    $res = $db->query("PRAGMA table_info($table)");
    while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
        if ($row['name'] === $col) return;
    }
    $db->exec("ALTER TABLE $table ADD COLUMN $col $def");
}

function handleImageUpload(array $file, bool $allowGif = false): array {
    $result = ['success' => false, 'path' => '', 'error' => ''];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $result['error'] = 'Upload failed with error code: ' . $file['error'];
        return $result;
    }
    
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    
    $isGif = $mimeType === 'image/gif';
    
    if ($isGif && !$allowGif) {
        $result['error'] = 'GIF upload is only available for premium users.';
        return $result;
    }
    
    if (!in_array($mimeType, ALLOWED_IMAGE_TYPES)) {
        $result['error'] = 'Only image files (JPEG, PNG, GIF, WebP) are allowed.';
        return $result;
    }
    
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        $result['error'] = 'File size must be less than 10MB.';
        return $result;
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    if ($extension === 'gif') $extension = 'gif';
    
    $filename = bin2hex(random_bytes(16)) . '.' . $extension;
    $targetPath = UPLOAD_DIR . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        $result['success'] = true;
        $result['path'] = 'uploads/' . $filename;
    } else {
        $result['error'] = 'Failed to save uploaded file.';
    }
    
    return $result;
}
addColumnIfMissing($db, 'users',         'avatar_url',    "TEXT DEFAULT ''");
addColumnIfMissing($db, 'users',         'is_active',     "INTEGER DEFAULT 1");
addColumnIfMissing($db, 'users',         'bio',           "TEXT DEFAULT ''");
addColumnIfMissing($db, 'users',         'favorite',      "TEXT DEFAULT ''");
addColumnIfMissing($db, 'users',         'hobby',         "TEXT DEFAULT ''");
addColumnIfMissing($db, 'users',         'onboarded',     "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'comments',      'parent_id',     "INTEGER DEFAULT NULL");
addColumnIfMissing($db, 'notifications', 'from_user_id',  "INTEGER DEFAULT NULL");
addColumnIfMissing($db, 'notifications', 'type',          "TEXT DEFAULT 'info'");
addColumnIfMissing($db, 'notifications', 'link',          "TEXT DEFAULT ''");
addColumnIfMissing($db, 'posts',         'image_url',     "TEXT DEFAULT ''");
addColumnIfMissing($db, 'users',         'is_premium',    "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'users',         'violation_count', "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'users',         'is_permanent_ban', "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'users',         'ban_reason',    "TEXT DEFAULT ''");
addColumnIfMissing($db, 'users',         'banned_at',     "TEXT DEFAULT ''");
addColumnIfMissing($db, 'users',         'date_of_birth', "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'users',         'multi_layer_security', "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'users',         'spam_filter',   "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'users',         'google_id',     "TEXT DEFAULT ''");
addColumnIfMissing($db, 'notifications', 'is_shown',     "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'messages',      'is_shown',     "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'posts',         'music_url',     "TEXT DEFAULT ''");
addColumnIfMissing($db, 'posts',         'music_title',   "TEXT DEFAULT ''");
addColumnIfMissing($db, 'messages',      'image_url',     "TEXT DEFAULT ''");
addColumnIfMissing($db, 'messages',      'is_liked',      "INTEGER DEFAULT 0");
addColumnIfMissing($db, 'messages',      'deleted_for',   "INTEGER DEFAULT 0");

$dm_upload_dir = '/home/silorizz/postaja.web.id/dm/result/v1/';
if (!is_dir($dm_upload_dir)) {
    mkdir($dm_upload_dir, 0755, true);
}

// Auto-delete DM photos older than 3 days
$files = glob($dm_upload_dir . "*");
$now = time();
foreach ($files as $file) {
    if (is_file($file)) {
        if ($now - filemtime($file) >= 3 * 24 * 60 * 60) {
            unlink($file);
        }
    }
}

$db->exec('CREATE TABLE IF NOT EXISTS appeals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    reason TEXT,
    status TEXT DEFAULT "pending",
    admin_note TEXT DEFAULT "",
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    processed_at TEXT DEFAULT ""
)') or die($db->lastErrorMsg());

$maintenance_mode = (int)$db->querySingle("SELECT value FROM settings WHERE key='maintenance_mode'") === 1;

function isMaintenanceMode(SQLite3 $db): bool {
    $result = $db->querySingle("SELECT value FROM settings WHERE key='maintenance_mode'");
    return $result === '1';
}

function shouldShowMaintenance(SQLite3 $db): bool {
    if (!isMaintenanceMode($db)) return false;
    if (!isset($_SESSION['user_id'])) return true;
    $user_id = (int)$_SESSION['user_id'];
    $role = $db->querySingle("SELECT role FROM users WHERE id=$user_id");
    if ($role === 'admin' || $role === 'superadmin') return false;
    return true;
}

function setMaintenanceMode(SQLite3 $db, bool $enabled): void {
    $value = $enabled ? '1' : '0';
    $stmt = $db->prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('maintenance_mode', :v)");
    $stmt->bindValue(':v', $value);
    $stmt->execute();
}

// ── Seed super admins ──────────────────────────────────────────────────────────
$superAdmins = [
    ['silo',  'silo@postaja.id',  'silo',    'superadmin'],
    ['rizal', 'rizal@postaja.id', 'rizalxd', 'superadmin'],
];
foreach ($superAdmins as [$uname, $email, $pw, $role]) {
    $stmt = $db->prepare("SELECT id FROM users WHERE username = :u");
    $stmt->bindValue(':u', $uname);
    $exists = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    if (!$exists) {
        $hash = password_hash($pw, PASSWORD_DEFAULT);
        $stmt = $db->prepare("INSERT INTO users (username, email, password, role, is_verified, is_active) VALUES (:u,:e,:p,:r,1,1)");
        $stmt->bindValue(':u', $uname);
        $stmt->bindValue(':e', $email);
        $stmt->bindValue(':p', $hash);
        $stmt->bindValue(':r', $role);
        $stmt->execute();
    } else {
        $stmt = $db->prepare("UPDATE users SET role=:r WHERE username=:u");
        $stmt->bindValue(':r', $role);
        $stmt->bindValue(':u', $uname);
        $stmt->execute();
    }
}
