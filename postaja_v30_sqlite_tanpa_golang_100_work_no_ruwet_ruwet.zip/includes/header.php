<?php
$root_path    = $root_path    ?? '';
$current_page = $current_page ?? 'home';
$page_title   = $page_title   ?? 'PostAja';
$api_path     = $api_path     ?? 'api/';

$notif_count = 0;
$dm_count    = 0;
if (isset($_SESSION['user_id'])) {
    $notif_count = getUnreadNotifCount($db, (int)$_SESSION['user_id']);
    $dm_count    = getUnreadDmCount($db, (int)$_SESSION['user_id']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>PostAja – <?= htmlspecialchars($page_title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script>
        const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;
        const isOtpStage = <?= (isset($_SESSION['otp_stage']) && in_array($_SESSION['otp_stage'], ['captcha','login','register'])) ? 'true' : 'false' ?>;
        window.addEventListener('load', function() {
            if (!isLoggedIn && isOtpStage) {
                const modalEl = document.getElementById('authModal');
                if (modalEl && typeof bootstrap !== 'undefined') {
                    const modal = new bootstrap.Modal(modalEl);
                    modal.show();
                }
            }
        });
    </script>
    <style>
        :root{--accent:#000;--accent-blue:#0d6efd;--bg:#fff;--border:#eee;--text-main:#000;--text-sub:#666;--light-bg:#f8f8f8;--thread-line:#e0e0e0;--bubble-bg:#f5f5f5;--reply-indent:20px}
        body{background:var(--bg);font-family:'Plus Jakarta Sans',sans-serif;color:var(--text-main);overflow-x:hidden;-webkit-user-select:none;-moz-user-select:none;user-select:none}
        .copyable-text,.copyable-text *{-webkit-user-select:text;-moz-user-select:text;user-select:text}
        img{-webkit-user-drag:none;user-drag:none;pointer-events:none}
        .main-container{max-width:1300px;margin:0 auto;display:flex}
        .sidebar-left{width:275px;height:100vh;position:sticky;top:0;padding:10px 20px;border-right:1px solid var(--border);overflow-y:auto}
        .feed-center{flex:1;max-width:600px;border-right:1px solid var(--border);min-height:100vh;margin:0 auto}
        .sidebar-right{flex:1;padding:10px 30px;position:sticky;top:0;height:100vh;overflow-y:auto}
        .ios-notification{position:fixed;top:-120px;left:50%;transform:translateX(-50%);width:90%;max-width:400px;background:#fff;backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border-radius:20px;padding:16px 18px;box-shadow:0 8px 32px rgba(0,0,0,.15),0 0 0 1px rgba(0,0,0,.05);z-index:9999;display:flex;align-items:center;gap:14px;transition:all .5s cubic-bezier(.23,1,.32,1);border:1px solid #e0e0e0}
        .ios-notification.active{top:20px}
        .ios-icon{width:44px;height:44px;background:linear-gradient(135deg,#0d6efd 0%,#0056b3 100%);color:#fff;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;box-shadow:0 2px 8px rgba(13,110,253,.25)}
        .ios-icon.dm-icon{background:linear-gradient(135deg,#0d6efd 0%,#0056b3 100%)}
        .ios-icon.like-icon{background:linear-gradient(135deg,#0d6efd 0%,#0056b3 100%)}
        .ios-icon.comment-icon{background:linear-gradient(135deg,#0d6efd 0%,#0056b3 100%)}
        .ios-icon.follow-icon{background:linear-gradient(135deg,#0d6efd 0%,#0056b3 100%)}
        .ios-icon.post-icon{background:linear-gradient(135deg,#0d6efd 0%,#0056b3 100%)}
        .ios-icon.info{background:linear-gradient(135deg,#0d6efd 0%,#0056b3 100%)}
        .ios-content{flex-grow:1;min-width:0}
        .ios-title{font-weight:700;font-size:.85rem;display:flex;justify-content:space-between;margin-bottom:3px;color:#000}
        .ios-title .notif-type{font-weight:800;letter-spacing:.3px}
        .ios-body{font-size:.9rem;color:#333;line-height:1.35;font-weight:500}
        .ios-time{font-weight:400;color:#888;font-size:.72rem;margin-left:auto}
        .ios-close{position:absolute;top:8px;right:10px;background:none;border:none;color:#999;font-size:1rem;cursor:pointer;padding:0;line-height:1}
        .ios-close:hover{color:#000}
        .ios-context-menu{position:fixed;background:#fff;border-radius:14px;box-shadow:0 6px 24px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.06);padding:6px 0;min-width:160px;z-index:10000;display:none;overflow:hidden;animation:contextMenuIn .15s ease-out}
        @keyframes contextMenuIn{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}
        .ios-context-item{display:flex;align-items:center;gap:12px;padding:10px 16px;font-size:.9rem;color:#000;cursor:pointer;transition:background .1s;border:none;background:none;width:100%;text-align:left}
        .ios-context-item:hover{background:#f5f5f5}
        .ios-context-item i{font-size:1rem;width:20px;text-align:center}
        .ios-context-divider{height:1px;background:#e0e0e0;margin:4px 8px}
        .copyable-text{-webkit-user-select:text;-moz-user-select:text;user-select:text;cursor:text}
        .no-copy{-webkit-user-select:none;-moz-user-select:none;user-select:none}
        .nav-link-item{display:flex;align-items:center;gap:16px;padding:10px 16px;font-size:1.1rem;font-weight:500;border-radius:99px;transition:.2s;color:var(--text-main);text-decoration:none;width:fit-content;margin-bottom:3px;position:relative}
        .nav-link-item:hover{background:var(--light-bg)}
        .nav-link-item.active-nav{font-weight:800}
        .nav-badge{position:absolute;top:4px;left:28px;background:#e00;color:#fff;border-radius:99px;font-size:.6rem;font-weight:800;padding:1px 5px;min-width:16px;text-align:center}
        .brand-logo{font-size:2rem;color:var(--accent);padding-left:15px;margin-bottom:10px;display:block;text-decoration:none}
        .post-card{transition:background .2s;border-bottom:1px solid var(--border)}
        .post-card:hover{background:rgba(0,0,0,.015)}
        .modern-avatar{width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,#0d6efd,#0056b3);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.2rem;color:#fff;overflow:hidden;flex-shrink:0}
        .btn-action{background:none;border:none;color:var(--text-sub);display:flex;align-items:center;gap:5px;transition:.2s;padding:6px 9px;border-radius:99px;font-size:.88rem;cursor:pointer;text-decoration:none}
        .btn-action:hover{background:rgba(0,0,0,.06);color:#000}
        .like-btn.active{color:#e00}
        .repost-btn.active{color:#0a0}
        .bookmark-btn.active{color:#00a}
        .compose-area{border-bottom:1px solid var(--border);padding:15px}
        .compose-input{font-size:1.2rem;border:none;outline:none;width:100%;resize:none;min-height:50px;background:transparent}
        .story-container{display:flex;gap:12px;overflow-x:auto;padding:15px;border-bottom:8px solid var(--light-bg);scrollbar-width:none}
        .story-circle{flex:0 0 auto;width:66px;text-align:center;cursor:pointer}
        .story-ring{width:60px;height:60px;border-radius:50%;border:2px solid #000;padding:2px}
        .story-ring img{width:100%;height:100%;border-radius:50%;object-fit:cover}
        .silo-anim{font-weight:800;background:linear-gradient(90deg,#000,#555);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
        .profile-banner{height:180px;background:linear-gradient(135deg,#0d6efd,#0056b3);margin-bottom:-60px;position:relative}
        .profile-avatar-wrapper{position:relative;display:flex;justify-content:space-between;align-items:flex-end;padding:0 20px;flex-wrap:wrap;gap:12px}
        .profile-avatar-main{width:110px;height:110px;border-radius:50%;border:4px solid #fff;background:linear-gradient(135deg,#0d6efd,#0056b3);display:flex;align-items:center;justify-content:center;font-size:2.5rem;color:#fff;font-weight:800;overflow:hidden}
        .profile-details{padding:65px 20px 20px}
        .profile-action-buttons{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:15px}
        .btn-follow,.btn-action-primary{border-radius:99px;font-weight:600;font-size:.95rem;padding:10px 24px;transition:all .25s ease;border:1.5px solid #000;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:6px;white-space:nowrap;background:#000;color:#fff;text-decoration:none}
        .btn-follow:hover,.btn-action-primary:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.15);background:#222;border-color:#222;color:#fff}
        .btn-follow:active,.btn-action-primary:active{transform:scale(.98)}
        .btn-follow.unfollow{background:#000;color:#fff;border:1.5px solid #000}
        .btn-follow.unfollow:hover{background:#222;border-color:#222;transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.15)}
        .btn-follow.unfollow:active{transform:scale(.98)}
        .btn-follow.following{background:#fff;color:#000;border:1.5px solid #000}
        .btn-follow.following:hover{background:#f5f5f5;border-color:#000;transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.15)}
        .btn-follow.following:active{transform:scale(.98)}
        .profile-tabs{display:flex;border-bottom:1px solid var(--border)}
        .profile-tab-item{flex:1;text-align:center;padding:15px 0;cursor:pointer;color:var(--text-sub);font-weight:600;position:relative;transition:.2s}
        .profile-tab-item:hover{background:rgba(0,0,0,.05)}
        .profile-tab-item.active{color:var(--text-main)}
        .profile-tab-item.active::after{content:"";position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:60px;height:4px;background:#000;border-radius:99px}
        .bottom-nav{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);width:90%;max-width:450px;background:rgba(255,255,255,.95);backdrop-filter:blur(25px);-webkit-backdrop-filter:blur(25px);border:1.5px solid rgba(0,0,0,.08);display:none;justify-content:space-around;align-items:center;padding:14px 12px;z-index:2000;border-radius:40px;box-shadow:0 15px 50px rgba(0,0,0,.12);animation:slideUp .3s ease-out}
        @keyframes slideUp{from{opacity:0;transform:translateX(-50%) translateY(30px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}
        .bottom-nav-item{color:var(--text-sub);text-decoration:none;display:flex;flex-direction:column;align-items:center;position:relative;padding:6px 10px;border-radius:12px;transition:all .2s ease;font-size:.7rem;font-weight:600}
        .bottom-nav-item:hover{background:rgba(0,0,0,.05);color:var(--text-main);transform:scale(1.05)}
        .bottom-nav-item i{font-size:1.5rem;margin-bottom:2px;display:block}
        .bottom-nav-item.active{color:#000;font-weight:700;background:rgba(0,0,0,.08);transform:scale(1.08)}
        .nav-center-btn{background:linear-gradient(135deg,#000,#222);color:#fff!important;width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin-top:-36px;border:5px solid var(--bg);z-index:2001;transition:all .2s ease;box-shadow:0 8px 20px rgba(0,0,0,.15)}
        .nav-center-btn:hover{transform:scale(1.1);box-shadow:0 12px 30px rgba(0,0,0,.25)}
        .nav-center-btn.active{background:linear-gradient(135deg,#0d6efd,#0056b3)!important;box-shadow:0 8px 25px rgba(13,110,253,.4)}
        .nav-center-btn i{font-size:1.5rem}
        .chat-bubble{max-width:80%;padding:10px 15px;border-radius:20px;margin-bottom:10px;border:1px solid #eee}
        .chat-me{background:#000;color:#fff;align-self:flex-end;border-bottom-right-radius:4px}
        .chat-other{background:#fff;color:#000;align-self:flex-start;border-bottom-left-radius:4px}
        .chat-container{height:calc(100vh - 210px);overflow-y:auto;display:flex;flex-direction:column;padding:15px;background:#fafafa;max-width:600px;margin:0 auto}
        .btn-primary{background-color:#0d6efd!important;border-color:#0d6efd!important}
        .btn-primary:hover{background-color:#0b5ed7!important}
        .comment-section{margin-top:8px}
        .comment-thread{display:flex;flex-direction:column;gap:0}
        .comment-node{display:flex;flex-direction:column;position:relative;padding:6px 0 0 0}
        .comment-reply-node{margin-left:var(--reply-indent);padding-left:0}
        .comment-body-wrap{display:flex;gap:10px;align-items:flex-start}
        .comment-avatar{flex-shrink:0}
        .comment-content-area{flex:1;min-width:0}
        .comment-bubble{background:var(--bubble-bg);border-radius:16px;padding:8px 14px;display:inline-block;max-width:100%;word-break:break-word}
        .comment-author{font-weight:700;font-size:.82rem;color:#000;margin-right:6px}
        .comment-text{font-size:.9rem;color:#111;line-height:1.45}
        .comment-meta{display:flex;align-items:center;gap:4px;margin-top:3px;padding-left:4px}
        .comment-time{font-size:.72rem;color:#999}
        .btn-reply-toggle,.btn-toggle-children{background:none;border:none;font-size:.75rem;font-weight:700;color:#666;cursor:pointer;padding:2px 6px;border-radius:8px;transition:background .15s;display:inline-flex;align-items:center;gap:3px}
        .btn-reply-toggle:hover,.btn-toggle-children:hover{background:rgba(0,0,0,.06);color:#000}
        .comment-children{margin-top:4px}
        .thread-connector{display:flex;align-items:stretch;width:20px;flex-shrink:0}
        .thread-line{width:2px;background:var(--thread-line);margin:0 auto;border-radius:2px;min-height:16px}
        .inline-reply-form{margin-top:8px}
        .reply-input,.root-comment-input{flex:1;border:1px solid #ddd;border-radius:20px;padding:7px 14px;font-size:.88rem;outline:none;background:var(--light-bg)}
        .reply-input:focus,.root-comment-input:focus{border-color:#000}
        .btn-send-reply,.btn-send-comment{background:#000;border:none;color:#fff;width:33px;height:33px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.8rem;flex-shrink:0;cursor:pointer;transition:.2s}
        .btn-send-reply:hover,.btn-send-comment:hover{background:#333;transform:scale(1.05)}
        .hashtag-link{color:#1d9bf0;text-decoration:none;font-weight:600}
        .hashtag-link:hover{text-decoration:underline}
        .mention-link{color:#8b5cf6;text-decoration:none;font-weight:600}
        .mention-link:hover{text-decoration:underline}
        .notif-item{padding:14px 16px;border-bottom:1px solid var(--border);display:flex;gap:12px;align-items:flex-start;transition:background .15s}
        .notif-item:hover{background:var(--light-bg)}
        .notif-item.unread{background:#e8f1ff}
        .notif-dot{width:8px;height:8px;background:var(--accent-blue);border-radius:50%;flex-shrink:0;margin-top:6px}
        .explore-hashtag{display:flex;justify-content:space-between;padding:10px 16px;border-bottom:1px solid var(--border);cursor:pointer;transition:background .15s;text-decoration:none;color:inherit}
        .explore-hashtag:hover{background:var(--light-bg)}
        .dm-item{display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid var(--border);cursor:pointer;text-decoration:none;color:inherit;transition:background .15s}
        .dm-item:hover{background:var(--light-bg)}
        .dm-item.unread-dm{background:#f0f8ff}
        .admin-stat-card{background:#000;color:#fff;border-radius:16px;padding:20px;text-align:center}
        .suggested-user{display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)}
        .role-badge{display:inline-flex;align-items:center;justify-content:center;gap:5px;padding:4px 10px;background:#000;color:#fff;border-radius:20px;font-size:.75rem;font-weight:700;letter-spacing:.5px;animation:badgeSlideIn .4s cubic-bezier(.23,1,.32,1);position:relative;overflow:hidden}
        .role-badge::before{content:'';position:absolute;top:0;left:-100%;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,255,255,.2),transparent);animation:badgeShimmer .8s ease-in-out 1s}
        @keyframes badgeSlideIn{from{opacity:0;transform:translateX(-8px);filter:blur(4px)}to{opacity:1;transform:translateX(0);filter:blur(0)}}
        @keyframes badgeShimmer{0%{left:-100%}100%{left:100%}}
        .role-badge i{font-size:.85em;display:flex;align-items:center}
        .role-badge span{display:flex;align-items:center;gap:3px}
        .role-badge.superadmin{background:linear-gradient(135deg,#000,var(--accent-blue));box-shadow:0 2px 8px rgba(0,0,0,.25),inset 0 1px 2px rgba(255,255,255,.1)}
        .role-badge.superadmin:hover{transform:scale(1.08);box-shadow:0 4px 12px rgba(0,0,0,.35),inset 0 1px 2px rgba(255,255,255,.1)}
        .role-badge.admin{background:linear-gradient(135deg,#1a1a1a,#2a2a2a);box-shadow:0 2px 6px rgba(0,0,0,.2)}
        .role-badge.admin:hover{transform:scale(1.05);box-shadow:0 3px 10px rgba(0,0,0,.3)}
        .role-badge.premium{background:linear-gradient(135deg,#6f42c1,#9d4edd);box-shadow:0 2px 8px rgba(111,66,193,.35)}
        .role-badge.premium:hover{transform:scale(1.08);box-shadow:0 4px 15px rgba(111,66,193,.5)}
        .role-badge.premium i{color:#ffd700}
        .post-music-player{position:relative}
        .post-music-player .music-wave-container{display:none;align-items:center;height:24px;gap:3px}
        .post-music-player .music-wave-container.active{display:flex}
        .post-music-player .music-wave{display:flex;align-items:flex-end;gap:2px;height:20px}
        .post-music-player .music-wave span{width:3px;background:#00d4ff;border-radius:2px;animation:musicWave 0.8s ease-in-out infinite}
        .post-music-player .music-wave span:nth-child(2){animation-delay:0.1s}
        .post-music-player .music-wave span:nth-child(3){animation-delay:0.2s}
        .post-music-player .music-wave span:nth-child(4){animation-delay:0.3s}
        .post-music-player .music-wave span:nth-child(5){animation-delay:0.4s}
        @keyframes musicWave{0%,100%{height:4px}50%{height:20px}}
        @media(max-width:992px){.sidebar-left{width:85px;padding:8px 10px}.nav-link-item{padding:8px 12px;gap:12px;margin-bottom:4px}.nav-link-item span{display:none}.nav-link-item i{font-size:1.3rem}.sidebar-right{display:none}.profile-action-buttons{gap:8px}.btn-follow,.btn-action-primary{padding:10px 20px;font-size:.9rem}.role-badge{font-size:.7rem;padding:3px 8px}.brand-logo{padding-left:12px;font-size:1.8rem}.nav-badge{left:20px;top:2px}}
        @media(max-width:768px){.profile-avatar-wrapper{gap:10px;padding:0 15px}.profile-action-buttons{gap:8px;width:100%}.btn-follow,.btn-action-primary{flex:1;min-width:120px;padding:12px 16px;font-size:.9rem;justify-content:center}.role-badge{font-size:.65rem;padding:2px 6px}}
        @media(max-width:576px){.sidebar-left{display:none!important}.bottom-nav{display:flex!important}.feed-center{border-right:none;width:100%}body{padding-bottom:120px}.profile-action-buttons{width:100%;flex-direction:row}.btn-follow,.btn-action-primary{flex:1;padding:12px 14px;font-size:.85rem;font-weight:600}.role-badge{font-size:.6rem;padding:2px 6px}.bottom-nav{bottom:16px}.compose-area{padding:12px}.story-container{padding:12px;gap:10px}.post-card{padding:12px!important}.ad-icon{width:36px!important;height:36px!important}.ad-icon i{font-size:1rem!important}}
        @keyframes qnavIn{from{opacity:0;transform:translateY(-8px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}
        @keyframes fadeInBg{from{opacity:0}to{opacity:1}}
        @keyframes slideUpPromo{from{transform:translateY(100%)}to{transform:translateY(0)}}
        .qnav-item{display:flex;align-items:center;gap:10px;padding:9px 16px;font-size:.88rem;font-weight:600;color:#111;text-decoration:none;transition:background .1s;cursor:pointer;}
        .qnav-item:hover{background:#f5f5f5;color:#000;}
        .qnav-item i{width:18px;text-align:center;font-size:.95rem;flex-shrink:0;}
        .qnav-item.text-danger{color:#dc3545!important;}
        .qnav-item.text-danger:hover{background:#fff5f5;}
    </style>
</head>
<body>

<div id="iosNotif" class="ios-notification" onclick="event.stopPropagation()">
    <div class="ios-icon" id="iosIconBox"><i class="bi bi-bell-fill"></i></div>
    <div class="ios-content">
        <div class="ios-title"><span class="notif-type" id="iosType">PostAja</span><span class="ios-time" id="iosTime">baru</span></div>
        <div id="iosMsg" class="ios-body">Notifikasi baru...</div>
    </div>
    <button class="ios-close" onclick="dismissIosNotif()">&times;</button>
</div>

<div id="iosContextMenu" class="ios-context-menu">
    <button class="ios-context-item" onclick="contextCopy()">
        <i class="bi bi-clipboard"></i> Copy
    </button>
    <button class="ios-context-item" onclick="contextPaste()">
        <i class="bi bi-clipboard-plus"></i> Paste
    </button>
    <button class="ios-context-item" onclick="contextTranslate()">
        <i class="bi bi-translate"></i> Translate
    </button>
    <button class="ios-context-item text-danger" onclick="contextReport()">
        <i class="bi bi-flag"></i> Report
    </button>
    <div class="ios-context-divider"></div>
    <button class="ios-context-item" onclick="contextProfile()">
        <i class="bi bi-person-circle"></i> View Profile
    </button>
    <button class="ios-context-item" onclick="contextDM()">
        <i class="bi bi-envelope"></i> Send DM
    </button>
    <div id="commentDeleteItem" class="ios-context-item text-danger" onclick="contextDeleteComment()" style="display:none;">
        <i class="bi bi-trash3"></i> Delete
    </div>
</div>

<?php 
$appeal_success = $_GET['success'] ?? '';
$appeal_error = $_GET['error'] ?? '';
if ($appeal_success || $appeal_error):
?>
<div class="alert alert-<?= $appeal_success ? 'success' : 'danger' ?> m-3 rounded-4" role="alert">
    <div class="d-flex align-items-center gap-2">
        <i class="bi bi-<?= $appeal_success ? 'check-circle-fill' : 'exclamation-triangle-fill' ?>"></i>
        <?php if ($appeal_success === 'appeal_auto_approved'): ?>
            <strong>Appeal Approved!</strong> Your account has been automatically restored. Welcome back!
        <?php elseif ($appeal_success === 'appeal_submitted'): ?>
            <strong>Appeal Submitted!</strong> Your appeal is pending review. We will get back to you soon.
        <?php elseif ($appeal_error === 'appeal_exists'): ?>
            <strong>Appeal Exists!</strong> You already have a pending appeal.
        <?php elseif ($appeal_error === 'empty_appeal'): ?>
            <strong>Error!</strong> Please provide a reason for your appeal.
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php if (isset($_SESSION['suspended']) && $_SESSION['suspended']): ?>
<div class="alert alert-danger m-3 rounded-4" role="alert">
    <div class="d-flex align-items-center gap-2">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <div>
            <strong>Your account has been suspended!</strong>
            <p class="mb-0 small">This is due to violating our content policy. You may submit an appeal to restore your account.</p>
        </div>
    </div>
    <button class="btn btn-danger btn-sm mt-2" data-bs-toggle="modal" data-bs-target="#appealModal">
        <i class="bi bi-gavel"></i> Submit Appeal
    </button>
</div>
<?php endif; ?>

<!-- Appeal Modal -->
<div class="modal fade" id="appealModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-gavel"></i> Submit Appeal</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="api/submit_appeal.php">
                <div class="modal-body">
                    <p class="text-muted">Your account has been suspended due to violating our content policy. Please explain why you should be allowed back.</p>
                    <div class="mb-3">
                        <label class="form-label">Appeal Reason</label>
                        <textarea name="appeal_reason" class="form-control" rows="4" placeholder="Please explain your situation... (Use 'tolong' for auto-approval)" required></textarea>
                        <small class="text-muted">Tip: Including "tolong" will result in automatic approval.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-send"></i> Submit Appeal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (isset($_SESSION['show_appeal'])): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var appealModal = new bootstrap.Modal(document.getElementById('appealModal'));
    appealModal.show();
});
</script>
<?php 
unset($_SESSION['show_appeal']); 
endif; ?>

<div class="main-container">
<div class="sidebar-left d-none d-sm-flex flex-column justify-content-between">
    <div>
        <a href="<?= $root_path ?>index.php" class="brand-logo"><i class="bi bi-rocket-takeoff-fill"></i></a>

        <a href="<?= $root_path ?>index.php" class="nav-link-item <?= $current_page === 'home' ? 'active-nav' : '' ?>">
            <i class="bi bi-house-door-fill"></i><span>Home</span></a>

        <a href="<?= $root_path ?>explore/" class="nav-link-item <?= $current_page === 'explore' ? 'active-nav' : '' ?>">
            <i class="bi bi-compass"></i><span>Explore</span></a>

        <a href="#" class="nav-link-item" data-bs-toggle="modal" data-bs-target="#searchModal">
            <i class="bi bi-search"></i><span>Search</span></a>

        <a href="<?= $root_path ?>chat/" class="nav-link-item <?= $current_page === 'chat' ? 'active-nav' : '' ?>">
            <i class="bi bi-chat-quote-fill"></i><span>Public Chat</span></a>

        <?php if (isset($_SESSION['user_id'])): ?>
        <a href="<?= $root_path ?>notifications/" class="nav-link-item <?= $current_page === 'notifications' ? 'active-nav' : '' ?>">
            <i class="bi bi-bell<?= $notif_count > 0 ? '-fill' : '' ?>"></i>
            <span>Notifications</span>
            <span class="nav-badge nav-badge-notif" style="<?= $notif_count > 0 ? '' : 'display:none' ?>"><?= $notif_count > 9 ? '9+' : $notif_count ?></span>
        </a>

        <a href="<?= $root_path ?>dm/" class="nav-link-item <?= $current_page === 'dm' ? 'active-nav' : '' ?>">
            <i class="bi bi-envelope<?= $dm_count > 0 ? '-fill' : '' ?>"></i>
            <span>Messages</span>
            <span class="nav-badge nav-badge-dm" style="<?= $dm_count > 0 ? '' : 'display:none' ?>"><?= $dm_count > 9 ? '9+' : $dm_count ?></span>
        </a>

        <a href="<?= $root_path ?>bookmarks/" class="nav-link-item <?= $current_page === 'bookmarks' ? 'active-nav' : '' ?>">
            <i class="bi bi-bookmark<?= $current_page === 'bookmarks' ? '-fill' : '' ?>"></i><span>Bookmarks</span></a>

        <a href="<?= $root_path ?>profile/?u=<?= urlencode($_SESSION['username']) ?>" class="nav-link-item <?= $current_page === 'profile' ? 'active-nav' : '' ?>">
            <i class="bi bi-person-circle"></i><span>Profile</span></a>

        <?php if (isSuperAdmin()): ?>
        <a href="<?= $root_path ?>admin/" class="nav-link-item <?= $current_page === 'admin' ? 'active-nav' : '' ?>" style="color:#c00">
            <i class="bi bi-shield-fill-exclamation"></i><span>Admin</span></a>
        <?php endif; ?>

        <button class="btn btn-primary w-100 rounded-pill py-2 fw-bold mt-3 d-none d-lg-block shadow-sm" data-bs-toggle="modal" data-bs-target="#postModal">
            New Post</button>

        <?php else: ?>
        <a href="#" class="nav-link-item" data-bs-toggle="modal" data-bs-target="#authModal">
            <i class="bi bi-person-circle"></i><span>Profile</span></a>
        <button class="btn btn-primary w-100 rounded-pill py-2 fw-bold mt-3 d-none d-lg-block shadow-sm" data-bs-toggle="modal" data-bs-target="#authModal">
            Join Now</button>
        <?php endif; ?>
    </div>

    <?php if (isset($_SESSION['user_id'])): ?>
    <div class="mb-4 dropdown">
        <div class="d-flex align-items-center gap-2 p-2" data-bs-toggle="dropdown" style="cursor:pointer;">
            <div class="modern-avatar" style="width:40px;height:40px;font-size:1rem;">
                <?= getAvatarHtml($_SESSION['username'], $_SESSION['avatar_url'] ?? '', 40) ?>
            </div>
            <div class="d-none d-lg-block">
                <div class="fw-bold" style="font-size:.9rem;">@<?= htmlspecialchars($_SESSION['username']) ?></div>
            </div>
        </div>
        <ul class="dropdown-menu border-0 shadow rounded-4">
            <li><a class="dropdown-item" href="<?= $root_path ?>profile/?u=<?= urlencode($_SESSION['username']) ?>">View Profile</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><form method="POST"><button name="logout" class="dropdown-item text-danger">Logout</button></form></li>
        </ul>
    </div>
    <?php else: ?>
    <div class="mb-4"><button class="btn btn-outline-dark w-100 rounded-pill" data-bs-toggle="modal" data-bs-target="#authModal">Login</button></div>
    <?php endif; ?>
</div>

<div class="feed-center">
<div class="p-3 border-bottom sticky-top bg-white bg-opacity-75" style="backdrop-filter:blur(10px);z-index:100;">
    <div class="d-flex align-items-center justify-content-between">
        <h5 class="fw-bold mb-0"><?= htmlspecialchars($page_title) ?></h5>
        <div class="position-relative" id="quickNavWrap">
            <button id="quickNavBtn" onclick="toggleQuickNav(event)" style="background:none;border:none;padding:6px 10px;border-radius:12px;cursor:pointer;display:flex;align-items:center;gap:6px;font-weight:700;font-size:.82rem;color:#000;transition:background .15s;" onmouseover="this.style.background='#f3f3f3'" onmouseout="this.style.background='none'">
                <span style="font-weight:800;letter-spacing:-.3px;">PostAja</span>
                <i class="bi bi-grid-3x3-gap-fill" style="font-size:1.05rem;"></i>
            </button>
            <div id="quickNavDropdown" style="display:none;position:absolute;top:calc(100% + 8px);right:0;width:240px;background:#fff;border-radius:18px;box-shadow:0 8px 32px rgba(0,0,0,.14),0 0 0 1px rgba(0,0,0,.06);z-index:999;overflow:hidden;animation:qnavIn .18s cubic-bezier(.23,1,.32,1);">
                <div style="padding:12px 14px 6px;font-size:.7rem;font-weight:800;color:#aaa;letter-spacing:.8px;text-transform:uppercase;">Profil</div>
                <?php if (isset($_SESSION['user_id'])): ?>
                <a href="<?= $root_path ?>profile/?u=<?= urlencode($_SESSION['username']) ?>" class="qnav-item"><i class="bi bi-person-circle"></i> Profil Saya</a>
                <a href="<?= $root_path ?>bookmarks/" class="qnav-item"><i class="bi bi-bookmark-fill"></i> Bookmarks</a>
                <div style="height:1px;background:#f0f0f0;margin:4px 0;"></div>
                <div style="padding:6px 14px 2px;font-size:.7rem;font-weight:800;color:#aaa;letter-spacing:.8px;text-transform:uppercase;">Pesan & Chat</div>
                <a href="<?= $root_path ?>dm/" class="qnav-item"><i class="bi bi-envelope-fill"></i> Direct Messages</a>
                <a href="<?= $root_path ?>chat/" class="qnav-item"><i class="bi bi-chat-quote-fill"></i> Public Chat</a>
                <?php else: ?>
                <a href="#" onclick="showAuthModal();closeQuickNav();" class="qnav-item"><i class="bi bi-person-circle"></i> Login / Daftar</a>
                <div style="height:1px;background:#f0f0f0;margin:4px 0;"></div>
                <div style="padding:6px 14px 2px;font-size:.7rem;font-weight:800;color:#aaa;letter-spacing:.8px;text-transform:uppercase;">Pesan & Chat</div>
                <a href="<?= $root_path ?>chat/" class="qnav-item"><i class="bi bi-chat-quote-fill"></i> Public Chat</a>
                <?php endif; ?>
                <div style="height:1px;background:#f0f0f0;margin:4px 0;"></div>
                <div style="padding:6px 14px 2px;font-size:.7rem;font-weight:800;color:#aaa;letter-spacing:.8px;text-transform:uppercase;">Aturan & Info</div>
                <a href="<?= $root_path ?>pp.html" class="qnav-item" target="_blank"><i class="bi bi-shield-check"></i> Kebijakan Privasi</a>
                <a href="<?= $root_path ?>tos.html" class="qnav-item" target="_blank"><i class="bi bi-file-text"></i> Syarat & Ketentuan</a>
                <a href="<?= $root_path ?>download.html" class="qnav-item"><i class="bi bi-download"></i> Download App</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                <div style="height:1px;background:#f0f0f0;margin:4px 0;"></div>
                <form method="POST" style="margin:0;"><button name="logout" class="qnav-item text-danger" style="width:100%;background:none;border:none;cursor:pointer;text-align:left;"><i class="bi bi-box-arrow-right"></i> Logout</button></form>
                <?php endif; ?>
                <div style="height:8px;"></div>
            </div>
        </div>
    </div>
</div>

<?php if (isset($error_msg)): ?>
    <div class="alert alert-danger border-0 rounded-4 m-3 small"><?= htmlspecialchars($error_msg) ?></div>
<?php endif; ?>
<?php if (isset($warning_msg)): ?>
    <div class="alert alert-warning border-0 rounded-4 m-3 small"><?= htmlspecialchars($warning_msg) ?></div>
<?php endif; ?>
<?php if (isset($success_msg)): ?>
    <div class="alert alert-success border-0 rounded-4 m-3 small"><?= htmlspecialchars($success_msg) ?></div>
<?php endif; ?>

<?php if (!isset($_SESSION['user_id'])): ?>
<!-- Download Promo Popup (guest only, setiap refresh) -->
<div id="dlPromo" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:8000;align-items:flex-end;justify-content:center;animation:fadeInBg .25s ease;">
    <div style="background:#fff;border-radius:24px 24px 0 0;width:100%;max-width:520px;padding:28px 24px 32px;box-shadow:0 -8px 40px rgba(0,0,0,.18);animation:slideUpPromo .3s cubic-bezier(.23,1,.32,1);">
        <div style="width:36px;height:4px;background:#e0e0e0;border-radius:4px;margin:0 auto 20px;"></div>
        <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px;">
            <div style="width:52px;height:52px;background:linear-gradient(135deg,#0d6efd,#0056b3);border-radius:14px;display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 4px 12px rgba(13,110,253,.3);">
                <i class="bi bi-rocket-takeoff-fill" style="color:#fff;font-size:1.5rem;"></i>
            </div>
            <div>
                <div style="font-weight:800;font-size:1.05rem;line-height:1.2;">Buka PostAja di mana saja</div>
                <div style="color:#666;font-size:.82rem;margin-top:2px;">Install app atau PWA, gratis selamanya!</div>
            </div>
        </div>
        <div style="background:#f4f8ff;border-radius:14px;padding:14px 16px;margin-bottom:18px;border:1px solid #dce8ff;">
            <div style="display:flex;gap:10px;align-items:flex-start;margin-bottom:10px;">
                <i class="bi bi-phone-fill" style="color:#0d6efd;margin-top:2px;flex-shrink:0;"></i>
                <div><span style="font-weight:700;font-size:.88rem;">Versi Aplikasi Android</span><br><span style="font-size:.78rem;color:#555;">APK native, install sekali, akses selamanya tanpa browser.</span></div>
            </div>
            <div style="display:flex;gap:10px;align-items:flex-start;">
                <i class="bi bi-browser-safari" style="color:#0d6efd;margin-top:2px;flex-shrink:0;"></i>
                <div><span style="font-weight:700;font-size:.88rem;">PWA (Progressive Web App)</span><br><span style="font-size:.78rem;color:#555;">Tambahkan ke layar utama dari browser, tanpa install APK.</span></div>
            </div>
        </div>
        <a href="<?= $root_path ?>download.html" style="display:block;background:linear-gradient(135deg,#0d6efd,#0056b3);color:#fff;text-align:center;border-radius:99px;padding:14px;font-weight:800;font-size:.95rem;text-decoration:none;margin-bottom:10px;box-shadow:0 4px 14px rgba(13,110,253,.35);" onclick="closeDlPromo()">
            <i class="bi bi-download"></i> &nbsp;Download / Install Sekarang
        </a>
        <button onclick="closeDlPromo()" style="display:block;width:100%;background:none;border:none;color:#888;font-size:.85rem;padding:8px;cursor:pointer;font-weight:600;">Tidak, Terimakasih</button>
    </div>
</div>
<?php endif; ?>
