<?php
require_once 'otp.php';

$otp_bypass_emails = ['silo@postaja.id', 'rizal@postaja.id'];

if (isset($_SESSION['user_id']) && isset($_SESSION['login_time']) && isset($_SESSION['mls_enabled'])) {
    if ($_SESSION['mls_enabled']) {
        if ((time() - (int)$_SESSION['login_time']) >= 3600) {
            session_destroy();
            header('Location: ' . $home_url . '?mls_expired=1');
            exit;
        }
        $_SESSION['login_time'] = time();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $error_msg = "Invalid CSRF token.";
    } elseif (isset($_POST['register'])) {
        $username = trim($_POST['username']);
        $email    = trim($_POST['email']);
        if (strlen($username) > 10) {
            $error_msg = "Username must be 10 characters or less.";
        } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
            $error_msg = "Username can only contain letters, numbers, and underscores.";
        } else {
            $stmt = $db->prepare('SELECT id FROM users WHERE username = :u OR email = :e');
            $stmt->bindValue(':u', $username);
            $stmt->bindValue(':e', $email);
            if ($stmt->execute()->fetchArray()) {
                $error_msg = "Username atau Email sudah terdaftar!";
            } else {
                $_SESSION['reg_user']   = $username;
                $_SESSION['reg_email']  = $email;
                $_SESSION['reg_pass']   = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $_SESSION['reg_dob']    = $_POST['date_of_birth'] ?? '';
                $_SESSION['otp_stage']  = 'captcha';
                $_SESSION['next_stage'] = 'register';
                generateCustomCaptcha();
                header('Location: ' . $home_url);
                exit;
            }
        }
    } elseif (isset($_POST['login'])) {
        $stmt = $db->prepare('SELECT * FROM users WHERE username = :u OR email = :u');
        $stmt->bindValue(':u', $_POST['username']);
        $user = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
        if ($user) {
            if (password_verify($_POST['password'], $user['password'])) {
                if ($user['is_permanent_ban']) {
                    $error_msg = "Akun Anda telah diblokir permanen.";
                } elseif (!$user['is_active']) {
                    $_SESSION['suspended']        = true;
                    $_SESSION['suspend_username'] = $user['username'];
                    $_SESSION['show_appeal']      = true;
                    header('Location: ' . $home_url);
                    exit;
                } else {
                    if (in_array($user['email'], $otp_bypass_emails)) {
                        $_SESSION['user_id']    = $user['id'];
                        $_SESSION['username']   = $user['username'];
                        $_SESSION['role']       = $user['role'];
                        $_SESSION['avatar_url'] = $user['avatar_url'] ?? '';
                        $_SESSION['login_time'] = time();
                        $_SESSION['mls_enabled'] = (int)($user['multi_layer_security'] ?? 0);
                        if (empty($user['onboarded']))     $_SESSION['show_onboarding'] = true;
                        if (empty($user['date_of_birth'])) $_SESSION['needs_dob']       = true;
                        header('Location: ' . $home_url);
                        exit;
                    }
                    $_SESSION['pending_login_user'] = $user;
                    $_SESSION['otp_stage']          = 'captcha';
                    $_SESSION['next_stage']         = 'login';
                    $_SESSION['otp_email']          = $user['email'];
                    generateCustomCaptcha();
                    header('Location: ' . $home_url);
                    exit;
                }
            } else {
                $error_msg = "Password salah!";
            }
        } else {
            $error_msg = "Username atau Email tidak ditemukan!";
        }
    } elseif (isset($_POST['verify_captcha'])) {
        $captcha_code = trim($_POST['captcha_code']);
        error_log("Captcha Attempt - Input: $captcha_code | Session: " . ($_SESSION['custom_captcha'] ?? 'NONE'));
        if (verifyCustomCaptcha($captcha_code)) {
            unset($_SESSION['custom_captcha']);
            $next  = $_SESSION['next_stage'] ?? '';
            $email = ($next === 'register') ? ($_SESSION['reg_email'] ?? '') : ($_SESSION['otp_email'] ?? '');
            
            // [FIX 1] Pastikan otp_email terekam global untuk form OTP selanjutnya!
            $_SESSION['otp_email'] = $email;
            
            // [FIX 2] Siapkan user_data untuk Magic Link di OTP
            $user_data = [];
            if ($next === 'register') {
                $user_data = [
                    'username' => $_SESSION['reg_user'] ?? '',
                    'password' => $_SESSION['reg_pass'] ?? '',
                    'dob'      => $_SESSION['reg_dob'] ?? ''
                ];
            }

            error_log("Captcha OK. Sending OTP to $email for $next");
            
            // MENGIRIM PARAMETER KE-3 SEKARANG
            if (send_otp($email, $next, $user_data)) {
                $_SESSION['otp_stage'] = $next;
                if ($next === 'register') {
                    try {
                        $redis    = get_redis_connection();
                        $reg_data = json_encode([
                            'user'  => $_SESSION['reg_user']  ?? '',
                            'email' => $_SESSION['reg_email'] ?? '',
                            'pass'  => $_SESSION['reg_pass']  ?? '',
                            'dob'   => $_SESSION['reg_dob']   ?? '',
                        ]);
                        $redis->setex("reg_data:{$email}", 10800, $reg_data);
                    } catch (Exception $e) {}
                }
                $success_msg = "Captcha berhasil. OTP dikirim ke email Anda.";
            } else {
                $error_msg = "Captcha berhasil, namun gagal mengirim OTP. Coba lagi.";
                $_SESSION['otp_stage'] = 'captcha';
                generateCustomCaptcha();
            }
        } else {
            $error_msg = "Kode Captcha tidak valid!";
            generateCustomCaptcha();
        }
    } elseif (isset($_POST['verify_otp'])) {
        $otp_code = trim($_POST['otp_code']);
        $stage    = $_SESSION['otp_stage'] ?? '';
        $email    = $_SESSION['otp_email'] ?? ''; // Sekarang ini GAK AKAN KOSONG lagi
        
        if (verify_otp($email, $stage, $otp_code)) {
            if ($stage === 'register') {
                $reg_user  = $_SESSION['reg_user']  ?? '';
                $reg_email = $_SESSION['reg_email'] ?? '';
                $reg_pass  = $_SESSION['reg_pass']  ?? '';
                $reg_dob   = $_SESSION['reg_dob']   ?? '';
                if (empty($reg_user)) {
                    try {
                        $redis  = get_redis_connection();
                        $backup = $redis->get("reg_data:{$email}");
                        if ($backup) {
                            $b        = json_decode($backup, true);
                            $reg_user  = $b['user']  ?? '';
                            $reg_email = $b['email'] ?? '';
                            $reg_pass  = $b['pass']  ?? '';
                            $reg_dob   = $b['dob']   ?? '';
                        }
                    } catch (Exception $e) {}
                }
                if (empty($reg_user)) {
                    $error_msg = "Data pendaftaran hilang. Silakan daftar ulang.";
                } else {
                    try {
                        $stmt = $db->prepare('INSERT INTO users (username, email, password, date_of_birth, is_verified) VALUES (:u,:e,:p,:d,1)');
                        $stmt->bindValue(':u', $reg_user);
                        $stmt->bindValue(':e', $reg_email);
                        $stmt->bindValue(':p', $reg_pass);
                        $stmt->bindValue(':d', $reg_dob);
                        if ($stmt->execute()) {
                            $new_id = $db->lastInsertRowID();
                            $_SESSION['user_id']         = $new_id;
                            $_SESSION['username']        = $reg_user;
                            $_SESSION['role']            = 'user';
                            $_SESSION['show_onboarding'] = true;
                            try { $r = get_redis_connection(); $r->del("reg_data:{$email}"); } catch(Exception $e) {}
                            unset($_SESSION['reg_user'], $_SESSION['reg_email'], $_SESSION['reg_pass'], $_SESSION['reg_dob'], $_SESSION['otp_stage'], $_SESSION['otp_email']);
                            header('Location: ' . $home_url);
                            exit;
                        } else {
                            $error_msg = "Gagal membuat akun.";
                        }
                    } catch (Exception $e) {
                        $error_msg = "Error: " . $e->getMessage();
                    }
                }
            } elseif ($stage === 'login') {
                $user = $_SESSION['pending_login_user'] ?? null;
                if (!$user) {
                    $error_msg = "Sesi login hilang. Silakan login kembali.";
                } else {
                    $_SESSION['user_id']    = $user['id'];
                    $_SESSION['username']   = $user['username'];
                    $_SESSION['role']       = $user['role'];
                    $_SESSION['avatar_url'] = $user['avatar_url'] ?? '';
                    $_SESSION['login_time'] = time();
                    $_SESSION['mls_enabled'] = (int)($user['multi_layer_security'] ?? 0);
                    if (empty($user['onboarded']))     $_SESSION['show_onboarding'] = true;
                    if (empty($user['date_of_birth'])) $_SESSION['needs_dob']       = true;
                    unset($_SESSION['pending_login_user'], $_SESSION['otp_stage'], $_SESSION['otp_email']);
                    header('Location: ' . $home_url);
                    exit;
                }
            }
        } else {
            $error_msg = "Kode OTP tidak valid!";
        }
    }

    if (isset($_POST['logout'])) {
        session_destroy();
        header('Location: ' . $home_url);
        exit;
    }
}
?>
