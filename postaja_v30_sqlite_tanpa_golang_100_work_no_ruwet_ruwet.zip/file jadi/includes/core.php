<?php
// Core backend: DB, helpers, handlers
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

const POSTS_PER_PAGE = 10;

$db = new SQLite3(__DIR__ . '/../data.db');
// Create tables
$db->exec('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, email TEXT UNIQUE, password TEXT, role TEXT DEFAULT "user", is_verified INTEGER DEFAULT 1, bio TEXT DEFAULT "", avatar_url TEXT DEFAULT "", notifications_enabled INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$db->exec('CREATE TABLE IF NOT EXISTS posts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, content TEXT, image_url TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$db->exec('CREATE TABLE IF NOT EXISTS comments (id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER, user_id INTEGER, parent_id INTEGER DEFAULT NULL, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$db->exec('CREATE TABLE IF NOT EXISTS stories (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, image_url TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$db->exec('CREATE TABLE IF NOT EXISTS likes (id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER, user_id INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(post_id, user_id))');
$db->exec('CREATE TABLE IF NOT EXISTS follows (id INTEGER PRIMARY KEY AUTOINCREMENT, follower_id INTEGER, following_id INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(follower_id, following_id))');
$db->exec('CREATE TABLE IF NOT EXISTS public_chat (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, message TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$db->exec('CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, message TEXT, is_read INTEGER DEFAULT 0, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');

// ensure columns exist
$cols = $db->query("PRAGMA table_info(users)");
$has_avatar=false; $has_notif=false;
while($col=$cols->fetchArray(SQLITE3_ASSOC)){
    if($col['name']==='avatar_url') $has_avatar=true;
    if($col['name']==='notifications_enabled') $has_notif=true;
}
if(!$has_avatar) $db->exec("ALTER TABLE users ADD COLUMN avatar_url TEXT DEFAULT ''");
if(!$has_notif) $db->exec("ALTER TABLE users ADD COLUMN notifications_enabled INTEGER DEFAULT 1");
$cols2 = $db->query("PRAGMA table_info(comments)");
$has_parent=false; while($c=$cols2->fetchArray(SQLITE3_ASSOC)){ if($c['name']==='parent_id'){$has_parent=true;break;} }
if(!$has_parent) $db->exec("ALTER TABLE comments ADD COLUMN parent_id INTEGER DEFAULT NULL");

// handlers: ajax notif/like/follow/load_posts handled here or in pages via GET/POST
if (isset($_GET['check_notif']) && isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    $stmt = $db->prepare('SELECT * FROM notifications WHERE user_id = :u AND is_read = 0 ORDER BY created_at DESC LIMIT 1');
    $stmt->bindValue(':u', $uid);
    $notif = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    if ($notif) { $db->exec("UPDATE notifications SET is_read = 1 WHERE id = " . $notif['id']); echo json_encode($notif); }
    else echo json_encode(null);
    exit;
}

if (isset($_GET['like_post']) && isset($_SESSION['user_id'])) {
    $p_id = (int)$_GET['like_post']; $u_id = $_SESSION['user_id'];
    $check = $db->prepare('SELECT id FROM likes WHERE post_id = :p AND user_id = :u'); $check->bindValue(':p',$p_id); $check->bindValue(':u',$u_id);
    $exists = $check->execute()->fetchArray();
    if ($exists) { $del = $db->prepare('DELETE FROM likes WHERE post_id = :p AND user_id = :u'); $del->bindValue(':p',$p_id); $del->bindValue(':u',$u_id); $del->execute(); $status='unliked'; }
    else { $ins=$db->prepare('INSERT INTO likes (post_id,user_id) VALUES (:p,:u)'); $ins->bindValue(':p',$p_id); $ins->bindValue(':u',$u_id); $ins->execute(); $status='liked'; }
    $count = $db->querySingle("SELECT COUNT(*) FROM likes WHERE post_id = $p_id"); echo json_encode(['status'=>$status,'count'=>$count]); exit;
} elseif (isset($_GET['like_post'])) { echo json_encode(['status'=>'error','message'=>'login_required']); exit; }

if (isset($_GET['follow_user']) && isset($_SESSION['user_id'])) {
    $following_id=(int)$_GET['follow_user']; $follower_id=$_SESSION['user_id'];
    if($following_id !== $follower_id){
        $check = $db->prepare('SELECT id FROM follows WHERE follower_id = :fer AND following_id = :fing'); $check->bindValue(':fer',$follower_id); $check->bindValue(':fing',$following_id);
        $exists = $check->execute()->fetchArray();
        if($exists){ $del=$db->prepare('DELETE FROM follows WHERE follower_id=:fer AND following_id=:fing'); $del->bindValue(':fer',$follower_id); $del->bindValue(':fing',$following_id); $del->execute(); $status='unfollowed'; }
        else{ $ins=$db->prepare('INSERT INTO follows (follower_id,following_id) VALUES (:fer,:fing)'); $ins->bindValue(':fer',$follower_id); $ins->bindValue(':fing',$following_id); $ins->execute(); $msg="@".$_SESSION['username']." mulai mengikuti Anda!"; $notif=$db->prepare('INSERT INTO notifications (user_id,message) VALUES (:uid,:msg)'); $notif->bindValue(':uid',$following_id); $notif->bindValue(':msg',$msg); $notif->execute(); $status='followed'; }
        echo json_encode(['status'=>$status]);
    }
    exit;
} elseif (isset($_GET['follow_user'])) { echo json_encode(['status'=>'error','message'=>'login_required']); exit; }

// helper functions
function censorMessage($text){
    $bad_words = ['anjing','goblok','ngentod','asu','kontol','bajingan','memek','jembut','bangsat','pepek','tolol','anj','bgst','perek','babi','bacot','kampret','geblek','gblk','tai','goblog','jancok','kntl','kntol','puki','sange','sialan','brengsek','idiot'];
    $has=false; foreach($bad_words as $w){ if(stripos($text,$w)!==false){ $text = preg_replace('/'.preg_quote($w,'/').'/i','####',$text); $has=true; } }
    return ['text'=>$text,'violation'=>$has];
}

function getAvatarHtml($username,$avatar_url,$size=36){ $style="width:{$size}px;height:{$size}px;border-radius:50%;"; if(!empty($avatar_url)) return '<img src="'.htmlspecialchars($avatar_url).'" style="'.$style.'object-fit:cover;" alt="'.htmlspecialchars($username).'">'; $letter=strtoupper(substr($username,0,1)); $fs=round($size*0.4); return '<div style="'.$style.'background:#000;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:'.$fs.'px;color:#fff;">'.$letter.'</div>'; }

function renderThreadedComments($comments_by_parent,$parent_id,$post_id,$depth=0){ if(!isset($comments_by_parent[$parent_id])||$depth>4) return ''; $html=''; foreach($comments_by_parent[$parent_id] as $cm){ $has_children = isset($comments_by_parent[$cm['id']]); $child_count = $has_children?count($comments_by_parent[$cm['id']]):0; $indent_class = $depth>0?'comment-reply-node':''; $av = getAvatarHtml($cm['username'],$cm['avatar_url']??'',$depth===0?32:26); $cid=$cm['id']; $pid=(int)$post_id; $html .= '<div class="comment-node '.$indent_class.'" data-comment-id="'.$cid.'">'; if($depth>0) $html .= '<div class="thread-connector"><div class="thread-line"></div></div>'; $html .= '<div class="comment-body-wrap">'; $html .= '<div class="comment-avatar">'.$av.'</div>'; $html .= '<div class="comment-content-area">'; $html .= '<div class="comment-bubble">'; $html .= '<span class="comment-author">@'.htmlspecialchars($cm['username']).'</span>'; $html .= '<span class="comment-text">'.nl2br(htmlspecialchars($cm['content'])).'</span>'; $html .= '</div>'; $html .= '<div class="comment-meta">'; $html .= '<span class="comment-time">'.date('d M, H:i',strtotime($cm['created_at'])).'</span>'; $html .= ' · <button class="btn-reply-toggle" onclick="toggleReplyForm('.$cid.','.$pid.')"><i class="bi bi-reply"></i> Balas</button>'; if($child_count>0) $html .= ' · <button id="toggle-label-'.$cid.'" class="btn-toggle-children" onclick="toggleChildren('.$cid.')">'.$child_count.' balasan</button>'; $html .= '</div>'; $html .= '<div id="reply-form-'.$cid.'" class="inline-reply-form" style="display:none;">'; $html .= '<form method="POST" onsubmit="return checkAuth(event)" class="d-flex gap-2 align-items-center mt-1">'; $html .= '<input type="hidden" name="post_id" value="'.$pid.'">'; $html .= '<input type="hidden" name="parent_id" value="'.$cid.'">'; $html .= '<input type="text" name="comment_content" class="reply-input" placeholder="Balas @'.htmlspecialchars($cm['username']).'..." required autocomplete="off">'; $html .= '<button name="create_comment" class="btn-send-reply"><i class="bi bi-send-fill"></i></button>'; $html .= '</form></div>'; if($has_children) $html .= '<div id="children-'.$cid.'" class="comment-children" style="display:block;">'.renderThreadedComments($comments_by_parent,$cm['id'],$post_id,$depth+1).'</div>'; $html .= '</div></div></div>'; } return $html; }

function renderPostHtml($post,$db){ ob_start(); $roles = explode(',',$post['role']); $is_silo = ($post['username']==='silo'); if($is_silo) $role_class='silo-anim'; elseif(in_array('admin',$roles)) $role_class='role-admin'; else $role_class='role-user'; $stmt_like = $db->prepare('SELECT COUNT(*) as count FROM likes WHERE post_id = :p'); $stmt_like->bindValue(':p',$post['id'],SQLITE3_INTEGER); $like_count = $stmt_like->execute()->fetchArray(SQLITE3_ASSOC)['count']; $is_liked=false; if(isset($_SESSION['user_id'])){ $stmt_check=$db->prepare('SELECT COUNT(*) as count FROM likes WHERE post_id = :p AND user_id = :u'); $stmt_check->bindValue(':p',$post['id'],SQLITE3_INTEGER); $stmt_check->bindValue(':u',$_SESSION['user_id'],SQLITE3_INTEGER); $is_liked = $stmt_check->execute()->fetchArray(SQLITE3_ASSOC)['count']>0; } $all_comments_stmt=$db->prepare('SELECT comments.*, users.username, users.avatar_url FROM comments JOIN users ON comments.user_id = users.id WHERE post_id = :p ORDER BY comments.created_at ASC'); $all_comments_stmt->bindValue(':p',$post['id'],SQLITE3_INTEGER); $all_comments_res=$all_comments_stmt->execute(); $comments_by_parent=[]; $total_comment_count=0; while($cm=$all_comments_res->fetchArray(SQLITE3_ASSOC)){ $pid = is_null($cm['parent_id'])?0:(int)$cm['parent_id']; $comments_by_parent[$pid][]=$cm; $total_comment_count++; } $avatar_html = getAvatarHtml($post['username'],$post['avatar_url']??'',48); ?>
    <div class="post-card mb-0 border-bottom p-3" id="post-<?= $post['id'] ?>">
        <div class="d-flex gap-3">
            <div class="modern-avatar flex-shrink-0"><?= $avatar_html ?></div>
            <div class="flex-grow-1">
                <div class="d-flex align-items-center gap-1 flex-wrap">
                    <a href="?profile=<?= urlencode($post['username']) ?>" class="fw-bold text-decoration-none text-dark <?= $role_class ?>">@<?= htmlspecialchars($post['username']) ?></a>
                    <?php if($is_silo): ?><span class="badge bg-dark text-white border-0" style="font-size:0.65rem;padding:2px 6px;">admin</span><?php endif; ?>
                    <span class="text-muted small">· <?= date('d M', strtotime($post['created_at'])) ?></span>
                </div>
                <div class="post-content mt-1 mb-2 text-dark" style="white-space: pre-wrap;"><?= nl2br(htmlspecialchars($post['content'])) ?></div>
                <?php if($post['image_url']): ?><div class="post-image-container mb-3 overflow-hidden rounded-4 border"><img src="<?= htmlspecialchars($post['image_url']) ?>" class="img-fluid w-100 hover-zoom" loading="lazy"></div><?php endif; ?>
                <div class="d-flex justify-content-between align-items-center" style="max-width:400px;">
                    <button onclick="likePost(<?= $post['id'] ?>)" class="btn-action like-btn <?= $is_liked ? 'active' : '' ?>" id="like-btn-<?= $post['id'] ?>"><i class="bi <?= $is_liked ? 'bi-heart-fill' : 'bi-heart' ?>"></i> <span class="count"><?= $like_count ?></span></button>
                    <button class="btn-action comment-trigger" onclick="focusRootComment(<?= $post['id'] ?>)"><i class="bi bi-chat"></i> <span class="count"><?= $total_comment_count ?></span></button>
                    <button class="btn-action share-btn"><i class="bi bi-share"></i></button>
                </div>
                <div class="comment-section mt-3">
                    <div class="comment-thread"><?= renderThreadedComments($comments_by_parent,0,$post['id']) ?></div>
                    <form method="POST" class="mt-2 d-flex gap-2 align-items-center root-comment-form" onsubmit="return checkAuth(event)">
                        <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                        <input type="hidden" name="parent_id" value="0">
                        <div class="root-avatar"><?= getAvatarHtml($_SESSION['username'] ?? 'Anon', $_SESSION['avatar_url'] ?? '', 40) ?></div>
                        <input type="text" name="comment_content" id="comment-input-<?= $post['id'] ?>" class="root-comment-input form-control form-control-sm border-0 bg-light rounded-pill px-3" placeholder="Tulis komentar..." required>
                        <button name="create_comment" class="btn-send-comment btn btn-dark btn-sm rounded-pill px-3">Kirim</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php return ob_get_clean(); }
