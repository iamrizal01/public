// Frontend JS extracted from monolithic file.
// Expects global variables set in pages: window.IS_LOGGED_IN (boolean), window.POSTS_PER_PAGE (number)

function showAuthModal(){ if(document.getElementById('authModal')) new bootstrap.Modal(document.getElementById('authModal')).show(); }
function checkAuth(e){ if(!window.IS_LOGGED_IN){ if(e) e.preventDefault(); showAuthModal(); return false; } return true; }
function likePost(postId){ if(!checkAuth()) return; const btn = document.getElementById('like-btn-'+postId); if(!btn || btn.disabled) return; btn.disabled=true; fetch('?like_post='+postId).then(r=>r.json()).then(data=>{ if(data.status){ const countEl = btn.querySelector('.count'); if(countEl) countEl.textContent = data.count; if(data.status==='liked') btn.classList.add('active'); else btn.classList.remove('active'); } btn.disabled=false; }).catch(()=>btn.disabled=false); }
function focusRootComment(postId){ if(!checkAuth()) return; const input = document.getElementById('comment-input-'+postId); if(input){ input.focus(); input.scrollIntoView({behavior:'smooth', block:'nearest'}); } }
function toggleReplyForm(commentId, postId){ if(!checkAuth()) return; const form = document.getElementById('reply-form-'+commentId); if(!form) return; const isVisible = form.style.display !== 'none'; document.querySelectorAll('.inline-reply-form').forEach(f=>f.style.display='none'); if(!isVisible){ form.style.display='block'; const input = form.querySelector('input[name="comment_content"]'); if(input) input.focus(); } }
function toggleChildren(commentId){ const container = document.getElementById('children-'+commentId); const label = document.getElementById('toggle-label-'+commentId); if(!container) return; const isHidden = container.style.display === 'none'; container.style.display = isHidden ? 'block' : 'none'; if(label){ const count = container.querySelectorAll(':scope > .comment-node').length; label.textContent = isHidden ? 'Sembunyikan' : count + ' balasan'; } }

// infinite scroll loader
let offset = (window.POSTS_PER_PAGE || 10); let loading=false; let noMoreContent=false;
window.addEventListener('scroll', ()=>{ if(noMoreContent||loading) return; if((window.innerHeight+window.scrollY) >= document.body.offsetHeight-800){ loading=true; fetch('?load_posts=1&offset='+offset).then(r=>r.json()).then(data=>{ if(data.html && data.html.trim()!==''){ document.getElementById('feed-container').insertAdjacentHTML('beforeend', data.html); offset += (window.POSTS_PER_PAGE || 10); } else { noMoreContent=true; const t = document.getElementById('loading-trigger'); if(t) t.innerText='Tidak ada lagi konten.'; } loading=false; }).catch(()=>{ loading=false; }); } });

// periodic notification check (requires server endpoint ?check_notif=1)
if (window.IS_LOGGED_IN) {
    setInterval(()=>{ fetch('?check_notif=1').then(r=>r.json()).then(data=>{ if(data){ const el = document.getElementById('iosMsg'); if(el) el.innerText = data.message; const notif = document.getElementById('iosNotif'); if(notif){ notif.classList.add('active'); setTimeout(()=>notif.classList.remove('active'),5000); } } }); }, 5000);
}

// Offline detection popup
function createOfflineModal() {
    const modalHtml = `
    <div id="offlineModal" class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body text-center p-4">
                    <div class="mb-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="currentColor" class="text-secondary" viewBox="0 0 16 16">
                            <path d="M10.706 3.294A12.545 12.545 0 0 0 8 3 12.44 12.44 0 0 0 .293.466l-.238.264-.238-.264A12.512 12.512 0 0 0 8 3c.597 0 1.172.085 1.706.294m.707-.707a12.48 12.48 0 0 1 0 1.414 12.48 12.48 0 0 1 0-1.414m-1.5 1.5a9.98 9.98 0 0 0-1.41-1.41 9.994 9.994 0 0 0-1.41 1.41 9.994 9.994 0 0 0 1.41 1.41 9.994 9.994 0 0 0 1.41-1.41M8 6.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5A.5.5 0 0 1 8 6.5m0 2a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5"/>
                        </svg>
                    </div>
                    <h5 class="mb-2">You are offline</h5>
                    <p class="text-muted mb-0 small">Check your connection or clear cache apps</p>
                </div>
            </div>
        </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    return new bootstrap.Modal(document.getElementById('offlineModal'));
}

let offlineModal = null;

window.addEventListener('offline', () => {
    if (!offlineModal) offlineModal = createOfflineModal();
    offlineModal.show();
});

window.addEventListener('online', () => {
    if (offlineModal) {
        offlineModal.hide();
        document.getElementById('offlineModal')?.remove();
        offlineModal = null;
    }
});
