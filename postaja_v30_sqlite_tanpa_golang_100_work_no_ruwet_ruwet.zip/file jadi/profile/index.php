<?php
require __DIR__ . '/../includes/core.php';
// profile page: expects ?profile=username
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>PostAja - Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body>
<?php if (!$view_profile) { echo '<div class="p-4">Profil tidak ditemukan.</div>'; exit; } ?>
<div class="container py-4">
    <div class="profile-banner"></div>
    <div class="profile-avatar-wrapper">
        <div class="profile-avatar-main"><?= getAvatarHtml($view_profile['username'], $view_profile['avatar_url'] ?? '', 120) ?></div>
        <div class="ms-3">
            <h3>@<?= htmlspecialchars($view_profile['username']) ?></h3>
            <p class="small text-muted"><?= htmlspecialchars($view_profile['bio'] ?? '') ?></p>
            <?php if(isset($_SESSION['user_id']) && $_SESSION['user_id']!=$view_profile['id']): ?>
                <button id="follow-btn" class="btn btn-sm btn-outline-dark" onclick="fetch('?follow_user='+<?= $view_profile['id'] ?>).then(r=>r.json()).then(()=>location.reload())">Follow</button>
            <?php endif; ?>
        </div>
    </div>
    <div class="profile-details mt-4">
        <h5>Postingan</h5>
        <?php
        $pst = $db->prepare('SELECT posts.*, users.username, users.role, users.avatar_url FROM posts JOIN users ON posts.user_id = users.id WHERE user_id = :u ORDER BY created_at DESC');
        $pst->bindValue(':u', $view_profile['id'], SQLITE3_INTEGER);
        $r = $pst->execute(); while($p=$r->fetchArray(SQLITE3_ASSOC)) echo renderPostHtml($p,$db);
        ?>
    </div>
</div>
<script>window.IS_LOGGED_IN = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>; window.POSTS_PER_PAGE = <?= POSTS_PER_PAGE ?>;</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/script.js"></script>
</body>
</html>
