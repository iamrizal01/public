<?php
$root_path = '../'; $api_path = '../api/'; $home_url = '../index.php';
$current_page = 'explore'; $page_title = 'Explore';
require '../includes/config.php';
require '../includes/functions.php';
require '../includes/auth_handler.php';

// Trending hashtags (all time)
$allPosts = $db->query("SELECT content FROM posts WHERE content LIKE '%#%'");
$tagCounts = [];
while ($p = $allPosts->fetchArray(SQLITE3_ASSOC)) {
    preg_match_all('/#(\w+)/u', $p['content'], $matches);
    foreach ($matches[1] as $tag) { $t = strtolower($tag); $tagCounts[$t] = ($tagCounts[$t] ?? 0) + 1; }
}
arsort($tagCounts);
$topTags = array_slice($tagCounts, 0, 20, true);

// Most liked posts (last 30 days)
$hotPosts = $db->query("
    SELECT posts.*, users.username, users.role, users.avatar_url,
           COUNT(likes.id) as like_count
    FROM posts
    JOIN users ON posts.user_id = users.id
    LEFT JOIN likes ON posts.id = likes.post_id
    WHERE posts.created_at >= datetime('now','-30 days')
    GROUP BY posts.id
    ORDER BY like_count DESC LIMIT 5
");

// Suggested users
$uid = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
$sugQuery = $uid
    ? "SELECT u.*, (SELECT COUNT(*) FROM follows WHERE following_id=u.id) as fc FROM users u WHERE u.is_active=1 AND u.id!=$uid AND u.id NOT IN (SELECT following_id FROM follows WHERE follower_id=$uid) ORDER BY fc DESC LIMIT 8"
    : "SELECT u.*, (SELECT COUNT(*) FROM follows WHERE following_id=u.id) as fc FROM users u WHERE u.is_active=1 ORDER BY fc DESC LIMIT 8";
$suggested = $db->query($sugQuery);

require '../includes/header.php';
?>

<!-- Section: Trending Hashtags -->
<div class="p-3 border-bottom">
    <h6 class="fw-bold mb-3"><i class="bi bi-fire text-danger"></i> Trending Hashtags</h6>
    <?php if (empty($topTags)): ?>
    <p class="text-muted small">No trending hashtags yet.</p>
    <?php else: $rank = 1; foreach ($topTags as $tag => $cnt): ?>
    <a href="../search/?q=<?= urlencode('#' . $tag) ?>&type=posts" class="explore-hashtag" style="border-radius:8px;margin-bottom:2px;display:flex;justify-content:space-between;padding:10px 12px;text-decoration:none;color:inherit;transition:background .15s;" onmouseover="this.style.background='#f8f8f8'" onmouseout="this.style.background=''">
        <div>
            <span class="text-muted small"><?= $rank ?>.</span>
            <span class="fw-bold ms-2 hashtag-link">#<?= htmlspecialchars($tag) ?></span>
        </div>
        <span class="text-muted small"><?= $cnt ?> posts</span>
    </a>
    <?php $rank++; endforeach; endif; ?>
</div>

<!-- Section: Hot Posts -->
<div class="p-3 border-bottom">
    <h6 class="fw-bold mb-3"><i class="bi bi-lightning-charge-fill text-warning"></i> Popular Posts This Month</h6>
</div>
<?php
$any = false;
while ($p = $hotPosts->fetchArray(SQLITE3_ASSOC)) {
    echo renderPostHtml($p, $db);
    $any = true;
}
if (!$any) echo '<div class="p-3 text-muted small text-center">No popular posts yet.</div>';
?>

<!-- Section: People to Follow -->
<div class="p-3 border-bottom mt-2">
    <h6 class="fw-bold mb-3"><i class="bi bi-people-fill"></i> People to Follow</h6>
    <?php while ($u = $suggested->fetchArray(SQLITE3_ASSOC)): ?>
    <div class="d-flex align-items-center gap-3 py-2 border-bottom">
        <a href="../profile/?u=<?= urlencode($u['username']) ?>">
            <?= getAvatarHtml($u['username'], $u['avatar_url'] ?? '', 46) ?>
        </a>
        <div class="flex-grow-1">
            <a href="../profile/?u=<?= urlencode($u['username']) ?>" class="fw-bold text-dark text-decoration-none d-block" style="font-size:.9rem;">
                @<?= htmlspecialchars($u['username']) ?>
            </a>
            <span class="text-muted" style="font-size:.78rem;"><?= $u['fc'] ?> followers</span>
        </div>
        <button onclick="toggleFollow(<?= $u['id'] ?>)" id="follow-btn-<?= $u['id'] ?>" class="btn-follow unfollow" style="font-size:.8rem;padding:6px 14px;">Follow</button>
    </div>
    <?php endwhile; ?>
</div>

<?php require '../includes/footer.php'; ?>
