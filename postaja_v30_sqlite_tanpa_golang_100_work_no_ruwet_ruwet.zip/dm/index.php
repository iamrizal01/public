<?php
$root_path = '../'; $api_path = '../api/'; $home_url = '../index.php';
$current_page = 'dm'; $page_title = 'Messages';
require '../includes/config.php';
require '../includes/functions.php';
require '../includes/auth_handler.php';
require '../includes/stiker_config.php';

if (!isset($_SESSION['user_id'])) { header('Location: /'); exit; }
$uid = (int)$_SESSION['user_id'];

// Check if user is premium
$is_premium = isPremiumUser($db, $uid);

// ==========================================
// INISIALISASI REDIS (UNIX SOCKET)
// ==========================================
$redis = new Redis();
$use_redis = false;
try {
    if ($redis->connect('/home/silorizz/redis/redis.sock')) {
        $use_redis = true;
    }
} catch (Exception $e) {
    $use_redis = false;
}

// Upload sticker
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_sticker']) && $is_premium) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        die('Invalid CSRF token');
    }
    $name = trim($_POST['sticker_name'] ?? 'My Sticker');
    $uploadResult = uploadSticker($stiker_db, $_FILES['sticker_file'], $uid, $name);
    if (!$uploadResult['success']) {
        $error_msg = $uploadResult['error'];
    }
    $redirect_url = isset($_GET['with']) ? '/dm/' . urlencode($_GET['with']) : '/dm/';
    header('Location: ' . $redirect_url); exit;
}

// Delete sticker
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_sticker']) && $is_premium) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        die('Invalid CSRF token');
    }
    $sticker_id = (int)$_POST['sticker_id'];
    deleteSticker($stiker_db, $sticker_id, $uid);
    $redirect_url = isset($_GET['with']) ? '/dm/' . urlencode($_GET['with']) : '/dm/';
    header('Location: ' . $redirect_url); exit;
}

// Send message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_dm'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        die('Invalid CSRF token');
    }
    $receiver_id = (int)$_POST['receiver_id'];
    $content = trim($_POST['content']);
    $sticker_path = $_POST['sticker_path'] ?? '';
    $image_url = '';

    // ==========================================
    // CUSTOM UPLOAD & AUTO CONVERT TO WEBP
    // ==========================================
    if (!empty($_FILES['dm_image']['name']) && $_FILES['dm_image']['error'] === UPLOAD_ERR_OK) {
        // Absolute path PRIMARY DOMAIN
        $upload_dir = '/home/silorizz/public_html/dm/result/v1/';
        
        // Auto buat folder
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $file_tmp = $_FILES['dm_image']['tmp_name'];
        $file_type = mime_content_type($file_tmp);
        $file_hash = md5(uniqid(rand(), true)); 
        $file_name = $file_hash . '.webp';
        $target_file = $upload_dir . $file_name;
        
        $img = null;
        if (in_array($file_type, ['image/jpeg', 'image/jpg'])) {
            $img = @imagecreatefromjpeg($file_tmp);
        } elseif ($file_type === 'image/png') {
            $img = @imagecreatefrompng($file_tmp);
            if ($img) {
                imagepalettetotruecolor($img);
                imagealphablending($img, true);
                imagesavealpha($img, true);
            }
        } elseif ($file_type === 'image/webp') {
            $img = @imagecreatefromwebp($file_tmp);
        }

        if ($img) {
            // Kompres WebP
            if (imagewebp($img, $target_file, 80)) {
                // Yang masuk DB cuma nama filenya aja
                $image_url = $file_name; 
                
                // Absolute URL untuk diakses via public
                $absolute_url = 'https://silorizz.web.id/dm/result/v1/' . $file_name;

                // Set Redis 3 Hari (259200 detik)
                if ($use_redis) {
                    $redis->setex('postaja_img_' . $file_name, 259200, $absolute_url);
                }
            } else {
                $error_msg = 'Gagal menyimpan file WebP.';
            }
            imagedestroy($img);
        } else {
            $error_msg = 'Format gambar tidak didukung.';
        }
    }
    
    if ($receiver_id > 0 && $receiver_id !== $uid && (!empty($content) || !empty($sticker_path) || !empty($image_url))) {
        // Strip script tags and dangerous HTML
        $content = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $content);
        $content = preg_replace('/<iframe\b[^>]*>(.*?)<\/iframe>/is', '', $content);
        $content = preg_replace('/on\w+\s*=\s*["\'].*?["\']/is', '', $content);
        
        // If sending sticker
        if (!empty($sticker_path)) {
            if (!$is_premium) {
                die('Only premium users can send stickers');
            }
            $content = '[STICKER:' . htmlspecialchars($sticker_path, ENT_QUOTES, 'UTF-8') . ']';
        } else {
            $content = htmlspecialchars($content, ENT_QUOTES, 'UTF-8');
        }
        
        $stmt = $db->prepare('INSERT INTO messages (sender_id, receiver_id, content, image_url) VALUES (:s,:r,:c,:i)');
        $stmt->bindValue(':s', $uid, SQLITE3_INTEGER);
        $stmt->bindValue(':r', $receiver_id, SQLITE3_INTEGER);
        $stmt->bindValue(':c', $content);
        $stmt->bindValue(':i', $image_url);
        $stmt->execute();
        
        // Notify receiver
        $stmt2 = $db->prepare('SELECT username FROM users WHERE id=:id');
        $stmt2->bindValue(':id', $uid, SQLITE3_INTEGER);
        $ru = $stmt2->execute()->fetchArray(SQLITE3_ASSOC);
        sendNotification($db, $receiver_id, $uid, 'dm', "@{$ru['username']} sent you a message.", "/dm/{$ru['username']}");
        
        $redirect_url = isset($_GET['with']) ? '/dm/' . urlencode($_GET['with']) : '/dm/';
        header('Location: ' . $redirect_url); exit;
    }
}

// Handle Actions (Like/Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dm_action'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        die('Invalid CSRF token');
    }
    $msg_id = (int)$_POST['message_id'];
    $action = $_POST['dm_action'];
    
    if ($action === 'like') {
        $db->exec("UPDATE messages SET is_liked = CASE WHEN is_liked = 1 THEN 0 ELSE 1 END WHERE id = $msg_id");
    } elseif ($action === 'delete') {
        $db->exec("UPDATE messages SET deleted_for = $uid WHERE id = $msg_id");
    }
    
    $redirect_url = isset($_GET['with']) ? '/dm/' . urlencode($_GET['with']) : '/dm/';
    header('Location: ' . $redirect_url); exit;
}

// Get user stickers
$user_stickers = $is_premium ? getUserStickers($stiker_db, $uid) : [];

// Mark messages as read
$with_user = null;
if (isset($_GET['with'])) {
    $stmt = $db->prepare('SELECT * FROM users WHERE username=:u');
    $stmt->bindValue(':u', $_GET['with']);
    $with_user = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    if ($with_user) {
        $wid = (int)$with_user['id'];
        $db->exec("UPDATE messages SET is_read=1 WHERE sender_id=$wid AND receiver_id=$uid");
    }
}

// Get conversation list
$convos = $db->query("
    SELECT DISTINCT
        CASE WHEN sender_id=$uid THEN receiver_id ELSE sender_id END as partner_id
    FROM messages
    WHERE sender_id=$uid OR receiver_id=$uid
    ORDER BY (SELECT created_at FROM messages m2 WHERE (m2.sender_id=$uid AND m2.receiver_id=partner_id) OR (m2.sender_id=partner_id AND m2.receiver_id=$uid) ORDER BY created_at DESC LIMIT 1) DESC
");

require '../includes/header.php';
?>

<style>
:root{--dm-bg:#FBFCFD;--dm-panel:#ffffff;--dm-border:#e6e9ed;--accent:#1f2937;--muted:#6b7280;--me-bg:#0d6efd;--other-bg:#f1f5f9}
.dm-container { height: calc(100vh - 60px); min-height: calc(100vh - 60px); display:flex; gap:0; background:var(--dm-bg); max-width:600px; margin:0 auto; }
.dm-container .convo-list { width:280px; min-width:200px; height:100%; overflow-y:auto; border-right: 1px solid var(--dm-border); background:linear-gradient(180deg, rgba(255,255,255,0.6), rgba(255,255,255,0.9)); }
.dm-container .dm-item { display:flex; gap:10px; align-items:center; padding:12px 14px; text-decoration:none; color:inherit; border-bottom:1px solid rgba(0,0,0,0.03); transition:background .12s ease; }
.dm-container .dm-item:hover{background:#f8fafc}
.dm-container .dm-item .flex-grow-1 { min-width:0; }
.dm-container .chat-area { display:flex; flex-direction:column; flex:1 1 auto; height:100%; min-width:0; background:var(--dm-bg); }

#chatWindow { flex:1 1 auto; overflow-y:auto; padding:18px; background:transparent; gap:8px; display:flex; flex-direction:column; }

.chat-bubble{max-width:76%; padding:10px 12px; border-radius:14px; box-shadow:0 1px 0 rgba(16,24,40,0.02);}
.chat-me{background:linear-gradient(180deg,var(--me-bg),#1152d4); color:#fff; border-bottom-right-radius:6px;}
.chat-other{background:var(--other-bg); color:var(--accent); border-bottom-left-radius:6px;}
.chat-bubble .meta{font-size:.68rem;font-weight:700;opacity:.8;margin-bottom:4px}
.chat-bubble .time{font-size:.65rem;opacity:.6;text-align:right;margin-top:6px}

.convo-list .badge{min-width:24px}

form.d-flex .form-control{border-radius:999px; padding:10px 14px; box-shadow:none}
.send-btn{border-radius:999px;padding:8px 14px}
.emoji-picker-toggle{cursor:pointer;font-size:1.2rem;color:#666}
.emoji-picker-toggle:hover{color:#0d6efd}
.emoji-grid{display:grid;grid-template-columns:repeat(8,1fr);gap:4px;max-height:200px;overflow-y:auto;padding:8px;background:#fff;border-radius:8px;}
.emoji-item{font-size:1.4rem;cursor:pointer;padding:4px;border-radius:6px;transition:all .15s;text-align:center;user-select:none;}
.emoji-item:hover{background:#f0f0f0;transform:scale(1.15)}

#emojiPanel { display: none; position: absolute; bottom: 80px; left: 10px; z-index: 9999; box-shadow: 0 4px 20px rgba(0,0,0,0.2); border-radius: 12px; width: 300px; background: #fff; border: 1px solid var(--dm-border); }
#emojiSearch{width:100%;border:none;border-bottom:1px solid #eee;padding:8px 12px;border-radius:12px 12px 0 0;outline:none;font-size:.85rem;}
.emoji-cats{display:flex;gap:2px;padding:4px 8px;border-bottom:1px solid #eee;overflow-x:auto;}
.emoji-cat-btn{background:none;border:none;font-size:1.1rem;padding:3px 5px;border-radius:6px;cursor:pointer;flex-shrink:0;}
.emoji-cat-btn.active,.emoji-cat-btn:hover{background:#f0f0f0;}
.sticker-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;max-height:200px;overflow-y:auto}
.sticker-item{width:60px;height:60px;object-fit:contain;border-radius:8px;cursor:pointer;border:2px solid transparent;transition:all .2s}
.sticker-item:hover{border-color:#0d6efd;transform:scale(1.05)}
.sticker-item.selected{border-color:#0d6efd;background:#e8f4ff}
.sticker-bubble{padding:5px!important}
.sticker-bubble img{max-width:150px;max-height:150px}

/* CSS GAMBAR DM & 404 */
.dm-photo { 
    display: block; 
    width: 250px; 
    max-width: 100%; 
    height: auto !important; 
    aspect-ratio: auto; 
    border-radius: 12px; 
    margin-top: 5px; 
    object-fit: contain; 
    background: transparent; 
}

img.dm-photo[src*="404-not-found"] {
    width: 150px !important;
    background: transparent !important;
    border: none;
}

.dm-photo-actions { display: flex; gap: 12px; margin-top: 6px; font-size: 0.85rem; padding: 0 4px; }
.dm-photo-actions button, .dm-photo-actions a { background: none; border: none; padding: 0; color: inherit; opacity: 0.6; transition: all 0.2s; text-decoration: none; }
.dm-photo-actions button:hover, .dm-photo-actions a:hover { opacity: 1; transform: scale(1.1); }
.dm-photo-actions .liked { color: #ff4757; opacity: 1; }
.dm-photo-preview { position: relative; display: inline-block; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.12); background: #fff; border: 1px solid #eee; max-width: 200px; }
.dm-photo-preview img { width: 100%; max-width: 200px; height: auto; max-height: 150px; object-fit: contain; display: block; }

@media (max-width: 767.98px) {
    .dm-container { flex-direction: column; height: calc(100vh - 56px); min-height: calc(100vh - 56px); }
    .dm-container .convo-list { width:100%; border-right:0; max-height:40vh; overflow-y:auto; }
    .dm-container .chat-area { display:none; width:100%; }
    .dm-container.show-chat .convo-list { display:none; }
    .dm-container.show-chat .chat-area { display:flex; }
    .dm-container.show-chat #chatWindow { flex:1 1 auto; max-height: calc(100vh - 56px - 120px); }
}
</style>

<div class="d-flex dm-container <?= $with_user ? 'show-chat' : '' ?>" style="height:calc(100vh - 60px);">

    <div class="convo-list border-right">
        <div class="p-3 border-bottom d-flex justify-content-between align-items-center">
            <span class="fw-bold">Conversations</span>
        </div>
        <?php
        $any_convos = false;
        while ($c = $convos->fetchArray(SQLITE3_ASSOC)):
            $pid = (int)$c['partner_id'];
            $stmt = $db->prepare('SELECT * FROM users WHERE id=:id');
            $stmt->bindValue(':id', $pid, SQLITE3_INTEGER);
            $partner = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
            if (!$partner) continue;
            $any_convos = true;
            $unread = (int)$db->querySingle("SELECT COUNT(*) FROM messages WHERE sender_id=$pid AND receiver_id=$uid AND is_read=0");
            $lastMsg = $db->querySingle("SELECT content FROM messages WHERE (sender_id=$uid AND receiver_id=$pid) OR (sender_id=$pid AND receiver_id=$uid) ORDER BY created_at DESC LIMIT 1");
            $isActive = $with_user && $with_user['id'] == $pid;
        ?>
        <a href="/dm/<?= urlencode($partner['username']) ?>" class="dm-item <?= $unread > 0 ? 'unread-dm' : '' ?>" style="<?= $isActive ? 'background:var(--light-bg);' : '' ?>">
            <?= getAvatarHtml($partner['username'], $partner['avatar_url'] ?? '', 42) ?>
            <div class="flex-grow-1 min-width-0">
                <div class="fw-bold" style="font-size:.88rem;">@<?= htmlspecialchars($partner['username']) ?></div>
                <div class="text-muted text-truncate" style="font-size:.75rem;"><?= htmlspecialchars(substr($lastMsg ?? '', 0, 40)) ?></div>
            </div>
            <?php if ($unread > 0): ?><span class="badge bg-dark rounded-pill"><?= $unread ?></span><?php endif; ?>
        </a>
        <?php endwhile;
        if (!$any_convos): ?>
        <div class="p-4 text-center text-muted small">No conversations yet.</div>
        <?php endif; ?>
    </div>

    <?php if ($with_user):
        $wid = (int)$with_user['id'];
        $messages = $db->query("SELECT m.*, u.username as sender_name FROM messages m JOIN users u ON m.sender_id=u.id WHERE ((sender_id=$uid AND receiver_id=$wid) OR (sender_id=$wid AND receiver_id=$uid)) AND m.deleted_for != $uid ORDER BY m.created_at ASC LIMIT 100");
    ?>
    <div class="chat-area flex-grow-1 d-flex flex-column">
        <div class="p-3 border-bottom d-flex align-items-center gap-2">
            <a href="/dm/" class="btn btn-light d-md-none me-2"><i class="bi bi-arrow-left"></i></a>
            <?= getAvatarHtml($with_user['username'], $with_user['avatar_url'] ?? '', 36) ?>
            <div>
                <a href="/profile/<?= urlencode($with_user['username']) ?>" class="fw-bold text-dark text-decoration-none" style="font-size:.9rem;">@<?= htmlspecialchars($with_user['username']) ?></a>
            </div>
        </div>
        <div id="chatWindow" class="flex-grow-1 overflow-y-auto d-flex flex-column" style="padding:16px;background:#fafafa;gap:4px;">
            <?php while ($msg = $messages->fetchArray(SQLITE3_ASSOC)):
                if ((int)$msg['deleted_for'] === $uid) continue;
                $is_mine = ($msg['sender_id'] == $uid);
                $is_sticker = preg_match('/^\[STICKER:(.+)\]$/', $msg['content'], $match);
            ?>
            <div class="d-flex <?= $is_mine ? 'justify-content-end' : 'justify-content-start' ?> mb-1">
                <div class="chat-bubble <?= $is_mine ? 'chat-me' : 'chat-other' ?> <?= $is_sticker ? 'sticker-bubble' : '' ?>">
                    <?php if (!$is_mine): ?><div style="font-size:.68rem;font-weight:700;opacity:.7;">@<?= htmlspecialchars($msg['sender_name']) ?></div><?php endif; ?>
                    <?php if ($is_sticker): ?>
                        <?php
                        $stickerUrl = $match[1];
                        if (!preg_match('~^https?://|^//|^/~', $stickerUrl)) {
                            $stickerUrl = '/' . ltrim($stickerUrl, '/');
                        }
                        ?>
                        <img src="<?= htmlspecialchars($stickerUrl) ?>" alt="sticker">
                    <?php else: ?>
                        <div style="font-size:.9rem;"><?= htmlspecialchars($msg['content']) ?></div>
                    <?php endif; ?>

                    <?php if (!empty($msg['image_url'])): 
                        // ==========================================
                        // RENDER LOGIC: REDIS -> 3 DAY TTL
                        // ==========================================
                        $file_name = basename($msg['image_url']);
                        $fallback = '/assets/404-not-found.png';
                        $imgUrl = $fallback;
                        $redis_key = 'postaja_img_' . $file_name;

                        if ($use_redis && $redis->exists($redis_key)) {
                            $imgUrl = $redis->get($redis_key);
                        } else {
                            // Cek File Fisik di server
                            $absolute_path = '/home/silorizz/public_html/dm/result/v1/' . $file_name;
                            if (file_exists($absolute_path)) {
                                // Hitung umur file (kalau belum 3 hari, simpan ulang ke Redis biar aman dari restart server)
                                $file_age = time() - filemtime($absolute_path);
                                if ($file_age < 259200) { 
                                    $imgUrl = 'https://silorizz.web.id/dm/result/v1/' . $file_name;
                                    if ($use_redis) {
                                        $redis->setex($redis_key, (259200 - $file_age), $imgUrl);
                                    }
                                }
                            }
                        }
                    ?>
                        <img src="<?= htmlspecialchars($imgUrl) ?>" class="dm-photo" onclick="openLightbox('<?= htmlspecialchars($imgUrl) ?>')" alt="" onerror="this.src='<?= $fallback ?>'; this.onerror=null;">
                        <div class="dm-photo-actions">
                            <form method="POST" style="display:inline;">
                                <?= csrfField() ?>
                                <input type="hidden" name="message_id" value="<?= $msg['id'] ?>">
                                <button type="submit" name="dm_action" value="like" class="<?= $msg['is_liked'] ? 'liked' : '' ?>" title="Like">
                                    <i class="bi <?= $msg['is_liked'] ? 'bi-heart-fill' : 'bi-heart' ?>"></i>
                                </button>
                            </form>
                            <a href="<?= htmlspecialchars($imgUrl) ?>" download class="text-inherit opacity-75" title="Save">
                                <i class="bi bi-download"></i>
                            </a>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Hapus untuk Anda?')">
                                <?= csrfField() ?>
                                <input type="hidden" name="message_id" value="<?= $msg['id'] ?>">
                                <button type="submit" name="dm_action" value="delete" title="Delete for me">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>

                    <div style="font-size:.65rem;opacity:.6;text-align:right;"><?= date('H:i', strtotime($msg['created_at'])) ?></div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        
        <?php if ($is_premium): ?>
        <div class="p-3 border-bottom bg-light">
            <div class="d-flex justify-content-between align-items-center">
                <span class="fw-bold"><i class="bi bi-gem text-warning me-1"></i> Stiker Saya</span>
                <button class="btn btn-primary btn-sm rounded-pill" onclick="document.getElementById('stickerUploadModal').style.display='flex'">
                    <i class="bi bi-plus-lg me-1"></i> Upload Stiker
                </button>
            </div>
            <?php if (!empty($user_stickers)): ?>
            <div class="sticker-grid mt-2">
                <?php foreach ($user_stickers as $sticker): ?>
                    <?php
                    $rawStickerPath = $sticker['file_path'];
                    $stickerSrc = $rawStickerPath;
                    if (!preg_match('~^https?://|^//|^/~', $stickerSrc)) {
                        $stickerSrc = '/' . ltrim($stickerSrc, '/');
                    }
                    ?>
                    <img src="<?= htmlspecialchars($stickerSrc) ?>" class="sticker-item" onclick="selectStickerFromList('<?= htmlspecialchars($rawStickerPath) ?>')" title="<?= htmlspecialchars($sticker['name']) ?>">
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p class="text-muted small mt-2 mb-0">Belum ada stiker. Upload stiker pertama kamu!</p>
            <?php endif; ?>
        </div>
        
        <div id="stickerUploadModal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:9999;align-items:center;justify-content:center;">
            <div class="bg-white rounded-4 p-4" style="width:90%;max-width:400px;box-shadow:0 10px 40px rgba(0,0,0,0.2);">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="fw-bold mb-0"><i class="bi bi-gem text-warning me-1"></i> Upload Stiker</h6>
                    <button type="button" class="btn-close" onclick="document.getElementById('stickerUploadModal').style.display='none'"></button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <?= csrfField() ?>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Pilih Gambar</label>
                        <input type="file" name="sticker_file" class="form-control" accept="image/png,image/gif,image/webp,image/jpeg" required>
                        <div class="form-text small">Max 500KB. PNG, GIF, WebP, JPEG</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">Nama Stiker</label>
                        <input type="text" name="sticker_name" class="form-control" placeholder="Stiker Keren Saya">
                    </div>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-light rounded-pill flex-grow-1" onclick="document.getElementById('stickerUploadModal').style.display='none'">Batal</button>
                        <button type="submit" name="upload_sticker" class="btn btn-primary rounded-pill flex-grow-1"><i class="bi bi-upload me-1"></i> Upload</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($is_premium && !empty($user_stickers)): ?>
        <div id="stickerPanel" class="border-top bg-white p-3" style="display:none;box-shadow:0 -4px 12px rgba(0,0,0,0.08);">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <span class="fw-bold"><i class="bi bi-gem text-warning me-1"></i> Your Stickers</span>
                <button type="button" class="btn-close" onclick="toggleStickerPanel()"></button>
            </div>
            <div class="sticker-grid">
                <?php foreach ($user_stickers as $sticker): ?>
                    <?php
                    $rawStickerPath = $sticker['file_path'];
                    $stickerSrc = $rawStickerPath;
                    if (!preg_match('~^https?://|^//|^/~', $stickerSrc)) {
                        $stickerSrc = '/' . ltrim($stickerSrc, '/');
                    }
                    ?>
                    <img src="<?= htmlspecialchars($stickerSrc) ?>" class="sticker-item" onclick="selectSticker('<?= htmlspecialchars($rawStickerPath) ?>')" title="<?= htmlspecialchars($sticker['name']) ?>">
                <?php endforeach; ?>
            </div>
            <div class="mt-3 pt-3 border-top">
                <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="document.getElementById('stickerUploadModal').style.display='flex'">
                    <i class="bi bi-plus-lg me-1"></i> Upload New Sticker
                </button>
            </div>
        </div>
        <?php elseif ($is_premium): ?>
        <div id="stickerPanel" class="border-top bg-white p-3" style="display:none;box-shadow:0 -4px 12px rgba(0,0,0,0.08);">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <span class="fw-bold"><i class="bi bi-gem text-warning me-1"></i> Your Stickers</span>
                <button type="button" class="btn-close" onclick="toggleStickerPanel()"></button>
            </div>
            <div class="text-center py-4">
                <i class="bi bi-emoji-smile display-4 text-muted opacity-50"></i>
                <p class="text-muted mb-3">No stickers yet. Create your first sticker!</p>
                <button class="btn btn-primary rounded-pill px-4" onclick="document.getElementById('stickerUploadModal').style.display='flex'">
                    <i class="bi bi-plus-lg me-1"></i> Upload Sticker
                </button>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="p-3 border-top bg-white" style="position:relative;">
            <div id="emojiPanel" class="border bg-white">
                <input type="text" id="emojiSearch" placeholder="🔍 Cari emoji..." oninput="renderEmoji()" autocomplete="off">
                <div class="emoji-cats" id="emojiCats"></div>
                <div class="emoji-grid" id="emojiGrid"></div>
            </div>
            <div id="imagePreview" style="display:none; padding:10px; border-top:1px solid #eee; background:#fff;">
                <div class="dm-photo-preview">
                    <img id="previewImg" src="">
                    <button type="button" class="btn-close position-absolute top-0 end-0 bg-white" onclick="clearImage()"></button>
                </div>
            </div>
            <form method="POST" class="d-flex gap-2" enctype="multipart/form-data">
                <?= csrfField() ?>
                <input type="hidden" name="receiver_id" value="<?= $with_user['id'] ?>">
                <input type="hidden" name="sticker_path" id="selectedSticker" value="">
                <label class="emoji-picker-toggle m-0 align-self-center" style="cursor:pointer;" title="Photo">
                    <i class="bi bi-camera"></i>
                    <input type="file" name="dm_image" id="dmImage" accept="image/jpeg,image/png,image/webp" style="display:none;" onchange="previewImage(this)">
                </label>
                <span id="emojiBtnToggle" class="emoji-picker-toggle ms-2" onclick="toggleEmojiPanel()" title="Emoji"><i class="bi bi-emoji-smile"></i></span>
                <?php if ($is_premium): ?>
                    <span class="sticker-picker-toggle" onclick="toggleStickerPanel()" title="Stickers"><i class="bi bi-gem"></i></span>
                <?php endif; ?>
                <input type="text" name="content" id="dmContent" class="form-control rounded-pill border bg-light px-4" placeholder="Type a message..." autocomplete="off" aria-label="Message">
                <button name="send_dm" class="btn btn-primary rounded-pill px-4 send-btn" title="Send"><i class="bi bi-send-fill"></i></button>
            </form>
        </div>
    </div>
    <?php else: ?>
    <div class="flex-grow-1 d-flex align-items-center justify-content-center text-muted">
        <div class="text-center">
            <i class="bi bi-chat-dots display-3 mb-3 d-block opacity-25"></i>
            <p>Choose a conversation or start a new one.</p>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
const cw=document.getElementById('chatWindow');
if(cw) cw.scrollTop=cw.scrollHeight;

let lastMsgId = <?= $with_user ? (int)$db->querySingle("SELECT MAX(id) FROM messages WHERE (sender_id=$uid AND receiver_id=$wid) OR (sender_id=$wid AND receiver_id=$uid)") : 0 ?>;
const withUser = '<?= $with_user ? addslashes($with_user['username']) : '' ?>';

function fetchMessages() {
    if (!withUser) return;
    fetch(`/api/get_messages.php?with=${withUser}&after_id=${lastMsgId}`)
        .then(r => r.json())
        .then(data => {
            if (data.status === 'success' && data.messages.length > 0) {
                data.messages.forEach(msg => {
                    appendMessage(msg);
                    lastMsgId = Math.max(lastMsgId, msg.id);
                });
                cw.scrollTop = cw.scrollHeight;
            }
        });
}

function previewImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('previewImg').src = e.target.result;
            document.getElementById('imagePreview').style.display = 'block';
        }
        reader.readAsDataURL(input.files[0]);
    }
}

function clearImage() {
    document.getElementById('dmImage').value = '';
    document.getElementById('imagePreview').style.display = 'none';
    document.getElementById('previewImg').src = '';
}

function openLightbox(url) {
    document.getElementById('lightboxImg').src = url;
    new bootstrap.Modal(document.getElementById('dmLightbox')).show();
}

function appendMessage(msg) {
    if (msg.deleted_for == <?= $uid ?>) return;
    const isMine = (msg.sender_id == <?= $uid ?>);
    const isSticker = msg.content && msg.content.match(/^\[STICKER:(.+)\]$/);
    
    let contentHtml = '';
    if (isSticker) {
        let stickerUrl = isSticker[1];
        if (!stickerUrl.match(/^https?:\/\/|^\/\/|^\//)) {
            stickerUrl = '/' + stickerUrl.replace(/^\//, '');
        }
        contentHtml = `<img src="${stickerUrl}" alt="sticker">`;
    } else {
        contentHtml = `<div style="font-size:.9rem;">${escapeHtml(msg.content || '')}</div>`;
    }

    let imageHtml = '';
    if (msg.image_url) {
        // Javascript asumsi gambar selalu nembak ke primary domain
        let file_name = msg.image_url.split('/').pop();
        let imgUrl = 'https://silorizz.web.id/dm/result/v1/' + file_name;
        const fallback = '/assets/404-not-found.png';

        imageHtml = `
            <img src="${imgUrl}" class="dm-photo" onclick="openLightbox('${imgUrl}')" alt="" onerror="this.src='${fallback}'; this.onerror=null;">
            <div class="dm-photo-actions">
                <button onclick="location.reload()" title="Like"><i class="bi ${msg.is_liked ? 'bi-heart-fill liked' : 'bi-heart'}"></i></button>
                <a href="${imgUrl}" download class="text-inherit opacity-75"><i class="bi bi-download"></i></a>
                <button onclick="location.reload()" title="Delete"><i class="bi bi-trash"></i></button>
            </div>
        `;
    }

    const html = `
        <div class="d-flex ${isMine ? 'justify-content-end' : 'justify-content-start'} mb-1">
            <div class="chat-bubble ${isMine ? 'chat-me' : 'chat-other'} ${isSticker ? 'sticker-bubble' : ''}">
                ${!isMine ? `<div style="font-size:.68rem;font-weight:700;opacity:.7;">@${escapeHtml(msg.sender_name || '')}</div>` : ''}
                ${contentHtml}
                ${imageHtml}
                <div style="font-size:.65rem;opacity:.6;text-align:right;">${formatTime(msg.created_at)}</div>
            </div>
        </div>
    `;
    cw.insertAdjacentHTML('beforeend', html);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatTime(dateStr) {
    const d = new Date(dateStr);
    return d.getHours().toString().padStart(2, '0') + ':' + d.getMinutes().toString().padStart(2, '0');
}

if (withUser) {
    setInterval(fetchMessages, 3000);
}

function toggleStickerPanel() {
    const panel = document.getElementById('stickerPanel');
    if (panel) {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }
}

function selectSticker(path) {
    document.getElementById('selectedSticker').value = path;
    document.getElementById('dmContent').value = '[Sticker]';
    document.getElementById('dmContent').placeholder = 'Sticker selected!';
    toggleStickerPanel();
}

function selectStickerFromList(path) {
    alert('Pilih percakapan terlebih dahulu untuk mengirim stiker!');
}

function toggleEmojiPanel() {
    const panel = document.getElementById('emojiPanel');
    if (!panel) return;
    const isHidden = window.getComputedStyle(panel).display === 'none';
    panel.style.display = isHidden ? 'block' : 'none';
    
    if (isHidden) {
        document.getElementById('emojiSearch').value = '';
        renderEmoji();
        setTimeout(() => document.getElementById('emojiSearch').focus(), 50);
    }
}

function insertEmoji(emoji) {
    const input = document.getElementById('dmContent');
    if (!input) return;
    const s = input.selectionStart, e = input.selectionEnd;
    input.value = input.value.slice(0, s) + emoji + input.value.slice(e);
    input.selectionStart = input.selectionEnd = s + emoji.length;
    input.focus();
}

const EMOJI_DATA = {
    '😀':['grinning','senyum','senang'],'😃':['smiley','happy'],'😄':['smile','gembira'],'😁':['beaming','girang'],'😅':['sweat smile','nervous','lega'],'😂':['joy','ngakak','lucu'],'🤣':['rofl','ngakak','ketawa'],'😊':['blush','malu'],'😇':['halo','innocent'],'🙂':['slightly smiling','senyum tipis'],'😉':['wink','kedip'],'😌':['relieved','lega','damai'],'😍':['heart eyes','cinta','suka banget'],'🥰':['smiling hearts','sayang','cinta'],'😘':['kissing heart','ciuman','kecup'],'😋':['yum','enak','lezat'],'😛':['tongue','melet'],'😜':['winking tongue','melet kedip'],'🤪':['zany','gila','kocak'],'😝':['squinting tongue','melet merem'],'🤗':['hugging','peluk','hug'],'🤭':['hand over mouth','ups','malu'],'🤫':['shushing','sst','diam'],'🤔':['thinking','mikir','hmm'],'🤐':['zipper mouth','diam','bisu'],'🤨':['raised eyebrow','curiga','skeptis'],'😐':['neutral','datar','biasa'],'😑':['expressionless','bete','datar'],'😶':['no mouth','bisu','diam'],'😏':['smirking','sinis','pede'],'😒':['unamused','bosen','ga suka'],'🙄':['eye roll','males','nyebelin'],'😬':['grimacing','grogi','awkward'],'🤥':['lying','bohong','pinocchio'],'😔':['pensive','sedih','melow'],'😷':['mask','sakit','covid'],'🤒':['sick','demam','sakit'],'🤕':['hurt','luka','cedera'],'🤢':['nauseated','mual','eneg'],'🤮':['vomiting','muntah','jijik'],'🤧':['sneezing','bersin','pilek'],'🥵':['hot face','panas','gerah'],'🥶':['cold face','dingin','beku'],'🥴':['woozy','pusing','mabuk'],'😵':['dizzy face','pingsan','pusing'],'🤯':['exploding head','kaget','syok'],'🤠':['cowboy','koboi'],'🥳':['partying','pesta','ulang tahun'],'🥸':['disguised','nyamar'],'😎':['cool','keren','sunglasses'],'🤓':['nerd','kutu buku'],'🧐':['monocle','teliti','kritis'],'😕':['confused','bingung'],'😟':['worried','khawatir','cemas'],'🙁':['frowning','kecewa'],'☹️':['sad','sedih'],'😮':['open mouth','kaget'],'😯':['hushed','terkejut'],'😲':['astonished','takjub','wow'],'😳':['flushed','merah malu'],'🥺':['pleading','melas','memelas'],'😦':['frowning','kecewa'],'😧':['anguished','cemas berat'],'😨':['fearful','takut'],'😰':['anxious sweat','cemas panik'],'😥':['sad relieved','sedih lega'],'😢':['crying','nangis','sedih'],'😭':['loudly crying','nangis bombay','sedih banget'],'😱':['screaming','teriak','kaget parah'],'😖':['confounded','frustrasi'],'😣':['persevering','berjuang'],'😞':['disappointed','kecewa'],'😓':['downcast sweat','capek','melelahkan'],'😩':['weary','capek banget','lelah'],'😫':['tired','kelelahan'],'🥱':['yawning','ngantuk','menguap'],'😤':['steam','kesal','dongkol'],'😡':['angry','marah','bete'],'😠':['mad','kesal','marah'],'🤬':['cursing','marah parah','umpatan'],
    '👍':['thumbs up','setuju','oke','good'],'👎':['thumbs down','tidak setuju','jelek'],'👌':['ok','oke','bagus'],'✌️':['peace','damai','dua jari'],'🤞':['fingers crossed','semoga','harap'],'🤟':['love you','iloveyou'],'🤙':['call me','shaka','santai'],'💪':['muscle','kuat','otot'],'🙌':['raising hands','yeay','hore'],'👏':['clapping','tepuk tangan','applause'],'👋':['wave','hai','dadah'],'🤝':['handshake','jabat tangan','deal'],'🙏':['folded hands','tolong','terima kasih','pray'],
    '❤️':['red heart','cinta','love'],'🧡':['orange heart','sayang'],'💛':['yellow heart','teman'],'💚':['green heart','sehat'],'💙':['blue heart','cool'],'💜':['purple heart','purple'],'🖤':['black heart','gelap'],'💔':['broken heart','patah hati'],'❣️':['heart exclamation','seru cinta'],'💕':['two hearts','cinta ganda'],'💞':['revolving hearts','sayang'],'💓':['beating heart','deg deg'],'💗':['growing heart','berkembang'],'💖':['sparkling heart','berkilau'],'💘':['heart arrow','cupid'],'💝':['gift heart','hadiah'],'❤️‍🔥':['heart fire','cinta membara'],
    '⭐':['star','bintang'],'🌟':['glowing star','bintang bersinar'],'✨':['sparkles','kilat','kinclong'],'💫':['dizzy star','bintang berputar'],'🔥':['fire','api','panas','hot'],'💯':['100','perfect','sempurna'],'🎉':['party','pesta','selamat'],'🎊':['confetti','meriah','pesta'],'💡':['lightbulb','ide','gagasan'],'🎯':['target','tepat sasaran'],'💼':['briefcase','kerja','bisnis'],'👀':['eyes','liat','ngintip'],'👄':['lips','bibir'],'👅':['tongue','lidah'],'💋':['kiss','ciuman'],'💥':['boom','dahsyat','ledakan'],'🌈':['rainbow','pelangi'],'☀️':['sun','matahari','cerah'],'🌙':['moon','bulan','malam'],'⚡':['lightning','petir','cepat'],'🌊':['wave','ombak','air'],'🍕':['pizza'],'🍔':['burger'],'🍜':['noodle','mie'],'🍣':['sushi'],'☕':['coffee','kopi'],'🎮':['game','gaming','joystick'],'📱':['phone','hp','smartphone'],'💻':['laptop','komputer'],'🚀':['rocket','roket','cepat']
};

const EMOJI_CATS = [
    {icon:'😀', label:'Wajah', keys:['😀','😃','😄','😁','😅','😂','🤣','😊','😇','🙂','😉','😌','😍','🥰','😘','😋','😛','😜','🤪','😝','🤗','🤭','🤫','🤔','🤐','🤨','😐','😑','😶','😏','😒','🙄','😬','🤥','😔','😷','🤒','🤕','🤢','🤮','🤧','🥵','🥶','🥴','😵','🤯','🤠','🥳','🥸','😎','🤓','🧐','😕','😟','🙁','☹️','😮','😯','😲','😳','🥺','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬']},
    {icon:'👍', label:'Tangan', keys:['👍','👎','👌','✌️','🤞','🤟','🤙','💪','🙌','👏','👋','🤝','🙏']},
    {icon:'❤️', label:'Hati', keys:['❤️','🧡','💛','💚','💙','💜','🖤','💔','❣️','💕','💞','💓','💗','💖','💘','💝','❤️‍🔥']},
    {icon:'✨', label:'Objek', keys:['⭐','🌟','✨','💫','🔥','💯','🎉','🎊','💡','🎯','💼','👀','👄','👅','💋','💥','🌈','☀️','🌙','⚡','🌊','🍕','🍔','🍜','🍣','☕','🎮','📱','💻','🚀']}
];

let activeCat = 0;

function initEmojiPicker() {
    const catsEl = document.getElementById('emojiCats');
    if (!catsEl) return;
    catsEl.innerHTML = EMOJI_CATS.map((c, i) =>
        `<button class="emoji-cat-btn${i===0?' active':''}" onclick="setEmojiCat(${i})" title="${c.label}">${c.icon}</button>`
    ).join('');
    renderEmoji();
}

function setEmojiCat(i) {
    activeCat = i;
    document.querySelectorAll('.emoji-cat-btn').forEach((b, idx) => b.classList.toggle('active', idx === i));
    document.getElementById('emojiSearch').value = '';
    renderEmoji();
}

function renderEmoji() {
    const grid = document.getElementById('emojiGrid');
    if (!grid) return;
    const q = document.getElementById('emojiSearch').value.trim().toLowerCase();
    let list;
    if (q) {
        list = Object.keys(EMOJI_DATA).filter(e => {
            const tags = EMOJI_DATA[e];
            return e.includes(q) || tags.some(t => t.includes(q));
        });
    } else {
        list = EMOJI_CATS[activeCat].keys;
    }
    grid.innerHTML = list.map(e =>
        `<span class="emoji-item" onclick="insertEmoji('${e}')" title="${(EMOJI_DATA[e]||[]).join(', ')}">${e}</span>`
    ).join('');
}

document.addEventListener('DOMContentLoaded', initEmojiPicker);

document.addEventListener('click', function(e) {
    const emojiPanel = document.getElementById('emojiPanel');
    const emojiBtn = document.getElementById('emojiBtnToggle');
    if (emojiPanel && emojiBtn && !emojiPanel.contains(e.target) && !emojiBtn.contains(e.target)) {
        emojiPanel.style.display = 'none';
    }
});

document.getElementById('dmContent')?.addEventListener('input', function() {
    document.getElementById('selectedSticker').value = '';
    this.placeholder = 'Type a message...';
});
</script>

<div class="modal fade" id="dmLightbox" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-body p-0 text-center">
                <img id="lightboxImg" src="" style="max-width:100%; max-height:90vh; border-radius:10px; object-fit: contain; background: rgba(0,0,0,0.5);">
                <button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-3" data-bs-dismiss="modal"></button>
            </div>
        </div>
    </div>
</div>

<?php require '../includes/footer.php'; ?>
