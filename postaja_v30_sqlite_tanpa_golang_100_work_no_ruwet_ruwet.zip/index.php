<?php
$root_path = ''; $api_path = 'api/'; $home_url = '/'; // [FIX] Ganti index.php jadi / biar ga kena 301 Redirect htaccess
$current_page = 'home'; $page_title = 'Home';
require 'includes/config.php';
require 'includes/functions.php';
require 'includes/auth_handler.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $uid = (int)$_SESSION['user_id'];
    
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        error_log("CSRF Failure for User ID: " . $uid);
        // [FIX] Jangan pakai die(), karena bikin blank screen. Jadikan error message agar UI tetap jalan.
        $error_msg = 'Sesi telah berakhir atau form tidak valid. Silakan muat ulang halaman.'; 
    } else {
        // [FIX] Deteksi form mobile modal yang mungkin gak bawa name="create_post"
        if (isset($_POST['create_post']) || isset($_POST['content'])) {
            $content = $_POST['content'] ?? '';
            
            try {
                $moderation = checkContentModeration($db, $uid, $content);
                if (!$moderation['allowed']) {
                    $error_msg = $moderation['message'];
                } elseif (isset($moderation['censored']) && $moderation['censored']) {
                    $warning_msg = $moderation['message'];
                    $censored = censorMessage($content);
                    $content = $censored['text'];
                }
            } catch (Exception $e) {
                error_log("Moderation System Error: " . $e->getMessage());
            }
            
            $imagePath = '';
            if (!empty($_FILES['post_image']['name'])) {
                try {
                    $allowGif = isPremiumUser($db, $uid);
                    $uploadResult = handleImageUpload($_FILES['post_image'], $allowGif);
                    if ($uploadResult['success']) {
                        $imagePath = $uploadResult['path'];
                    } else {
                        error_log("Post Image Upload Error: " . $uploadResult['error']);
                        $error_msg = $uploadResult['error']; // Tampilkan error jika gambar kebesaran/format salah
                    }
                } catch (Exception $e) {
                    error_log("Image Upload Exception: " . $e->getMessage());
                }
            }
            
            $musicUrl = $_POST['music_url'] ?? '';
            $musicTitle = $_POST['music_title'] ?? '';
            
            if (!empty($musicUrl)) {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $musicUrl);
                curl_setopt($ch, CURLOPT_NOBODY, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
                curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                
                if ($httpCode >= 400) {
                    $musicUrl = '';
                    $musicTitle = '';
                }
            }
            
            if (!isset($error_msg) && (trim($content) !== '' || !empty($imagePath) || !empty($musicUrl))) {
                error_log("Attempting DB Insert for Post by UID: $uid");
                try {
                    $stmt = $db->prepare('INSERT INTO posts (user_id, content, image_url, music_url, music_title) VALUES (:u,:c,:i,:m,:t)');
                    $stmt->bindValue(':u', $uid, SQLITE3_INTEGER);
                    $stmt->bindValue(':c', $content);
                    $stmt->bindValue(':i', $imagePath);
                    $stmt->bindValue(':m', $musicUrl);
                    $stmt->bindValue(':t', $musicTitle);
                    
                    $exec_res = $stmt->execute();
                    if (!$exec_res) {
                        throw new Exception("Execute returned false: " . $db->lastErrorMsg());
                    }
                    
                    $new_post_id = $db->lastInsertRowID();
                    error_log("Post Created Successfully! ID: $new_post_id");
                    
                    // Notifications
                    $f_stmt = $db->prepare('SELECT follower_id FROM follows WHERE following_id = :u');
                    $f_stmt->bindValue(':u', $uid);
                    $followers = $f_stmt->execute();
                    while ($f = $followers->fetchArray(SQLITE3_ASSOC)) {
                        sendNotification($db, $f['follower_id'], $uid, 'post', "@{$_SESSION['username']} baru saja mengunggah post baru.", "../post/?id=$new_post_id");
                    }
                    
                    // Mentions notification
                    if (preg_match_all('/@(\w+)/', $content, $matches)) {
                        $unique_mentions = array_unique($matches[1]);
                        foreach ($unique_mentions as $m_user) {
                            if ($m_user === $_SESSION['username']) continue;
                            $m_stmt = $db->prepare('SELECT id FROM users WHERE username = :u');
                            $m_stmt->bindValue(':u', $m_user);
                            $m_res = $m_stmt->execute()->fetchArray(SQLITE3_ASSOC);
                            if ($m_res) {
                                sendNotification($db, (int)$m_res['id'], $uid, 'mention', "@{$_SESSION['username']} menyebut Anda dalam sebuah postingan.", "../post/?id=$new_post_id");
                            }
                        }
                    }
                    
                    // [FIX] Mengubah tujuan lokasi
                    header('Location: /'); exit; 
                } catch (Exception $e) {
                    error_log("FATAL Post Create Error: " . $e->getMessage());
                    $error_msg = "Gagal mengirim postingan: " . $e->getMessage();
                }
            }
        }
        
        if (isset($_POST['create_story'])) {
            $allowGif = isPremiumUser($db, (int)$_SESSION['user_id']);
            $uploadResult = handleImageUpload($_FILES['story_image'], $allowGif);
            if ($uploadResult['success']) {
                $stmt = $db->prepare('INSERT INTO stories (user_id, image_url) VALUES (:u,:i)');
                $stmt->bindValue(':u', (int)$_SESSION['user_id']);
                $stmt->bindValue(':i', $uploadResult['path']);
                $stmt->execute();
                header('Location: /'); exit; // [FIX] Lokasi tujuan
            } else {
                $error_msg = $uploadResult['error'];
            }
        }
    }
}

$sts = null;
if (isset($_SESSION['user_id'])) {
    $uid = (int)$_SESSION['user_id'];
    $stmt = $db->prepare('SELECT stories.*, users.username FROM stories JOIN users ON stories.user_id=users.id JOIN follows ON stories.user_id=follows.following_id WHERE follows.follower_id=:u AND stories.created_at>=datetime("now","-1 day") GROUP BY stories.user_id ORDER BY stories.created_at DESC');
    $stmt->bindValue(':u', $uid, SQLITE3_INTEGER);
    $sts = $stmt->execute();
}

require 'includes/header.php';
?>

<?php if (isset($_SESSION['user_id'])): ?>
<div class="compose-area d-none d-sm-block">
    <div class="d-flex gap-3">
        <div class="modern-avatar"><?= getAvatarHtml($_SESSION['username'], $_SESSION['avatar_url'] ?? '', 48) ?></div>
        <div class="flex-grow-1">
            <form method="POST" action="/" enctype="multipart/form-data">
                <?= csrfField() ?>
                <textarea name="content" class="compose-input" placeholder="What's on your mind? Use #hashtag or @mention" id="composeTextarea"></textarea>
                <div class="mb-2">
                    <label class="small text-muted" style="cursor:pointer;" onclick="document.getElementById('composeImageInput').click()"><i class="bi bi-image"></i> Add Image</label>
                    <input type="file" name="post_image" class="form-control form-control-sm border-0 bg-light" accept="image/jpeg,image/png,image/gif,image/webp" style="display:none;" id="composeImageInput" onchange="document.getElementById('composeImageName').textContent = this.files[0]?.name || '';">
                    <small class="text-muted" id="composeImageName"></small>
                </div>
                <div class="mb-2">
                    <label class="small text-muted" style="cursor:pointer;"><i class="bi bi-music-note-beamed"></i> Add Music</label>
                    <input type="text" name="music_url" class="form-control form-control-sm border-0 bg-light" placeholder="Music URL (mp3 link)" id="musicUrlInput">
                    <input type="text" name="music_title" class="form-control form-control-sm border-0 bg-light mt-1" placeholder="Music Title" id="musicTitleInput">
                </div>
                <div class="d-flex justify-content-between align-items-center border-top pt-2">
                    <span class="text-muted small"><i class="bi bi-hash"></i> Use hashtags</span>
                    <button name="create_post" class="btn btn-primary rounded-pill px-4 fw-bold shadow-sm">Post</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="story-container">
    <div class="story-circle" onclick="<?= isset($_SESSION['user_id']) ? "new bootstrap.Modal(document.getElementById('addStory')).show()" : "showAuthModal()" ?>">
        <div class="story-ring d-flex align-items-center justify-content-center bg-light"><i class="bi bi-plus-lg text-dark"></i></div>
        <span class="small">Story</span>
    </div>
    <?php if ($sts) while ($s = $sts->fetchArray(SQLITE3_ASSOC)):
        $rawStory = $s['image_url'] ?? '';
        $storyUrl = $rawStory;
        if (!preg_match('~^https?://|^//|^/~', $storyUrl)) {
            $storyUrl = $root_path . ltrim($storyUrl, '/');
        }
    ?>
    <div class="story-circle" onclick="openStory('<?= htmlspecialchars($storyUrl) ?>','<?= htmlspecialchars($s['username']) ?>')">
        <div class="story-ring"><img src="<?= htmlspecialchars($storyUrl) ?>" loading="lazy"></div>
        <span class="small text-truncate d-block">@<?= htmlspecialchars($s['username']) ?></span>
    </div>
    <?php endwhile; ?>
</div>

<div id="feed-container">
<?php
$spam_filter_enabled = false;
if (isset($_SESSION['user_id'])) {
    $spam_filter_enabled = (int)$db->querySingle("SELECT spam_filter FROM users WHERE id = " . (int)$_SESSION['user_id']) === 1;
}

$refresh = isset($_GET['refresh']);
$order_by = 'posts.created_at DESC';
$ps = $db->query("SELECT posts.*, users.username, users.role, users.avatar_url, users.is_premium FROM posts JOIN users ON posts.user_id=users.id ORDER BY $order_by LIMIT 10");
$postIndex = 0;
while ($p = $ps->fetchArray(SQLITE3_ASSOC)) {
    echo renderPostHtml($p, $db);
    $postIndex++;
    if ($postIndex % 3 === 0) {
        $adKey = 'ad_' . uniqid();
        echo '<div class="post-card mb-0 border-bottom p-2 p-sm-3">
    <div class="d-flex gap-2 gap-sm-3">
        <div class="flex-shrink-0">
            <div class="ad-icon" style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#007BFF 0%,#004DA3 100%);display:flex;align-items:center;justify-content:center;">
                <i class="bi bi-megaphone text-white"></i>
            </div>
        </div>
        <div class="flex-grow-1">
            <div class="d-flex align-items-center gap-1 flex-wrap">
                <span class="fw-bold" style="color:#007BFF;font-size:0.85rem;">Sponsored</span>
                <span class="badge" style="background:#007BFF;color:#fff;font-size:0.6rem;padding:2px 6px;">Advertisement</span>
            </div>
            <div class="ad-content mt-2" id="' . $adKey . '">
                <img src="uploads/ads/ad1.png" style="max-width:100%;height:auto;border-radius:8px;display:block;" alt="Advertisement">
            </div>
        </div>
    </div>
</div>';
    }
}
?>
</div>

<div id="loading-trigger" class="text-center py-5"><div class="spinner-border spinner-border-sm text-dark"></div></div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const csrfToken = "<?= getCsrfToken() ?>";
    document.querySelectorAll('form').forEach(f => {
        // 1. Suntik CSRF Token ke semua form yang ketinggalan (misal di footer.php)
        if (!f.querySelector('input[name="csrf_token"]')) {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'csrf_token';
            input.value = csrfToken;
            f.appendChild(input);
        }
        // 2. Bypass 301 Redirect htaccess dengan mengubah action index.php jadi /
        const action = f.getAttribute('action');
        if (action && (action.includes('index.php') || action === '')) {
            f.setAttribute('action', '/');
        }
    });
});
</script>

<?php require 'includes/footer.php'; ?>
