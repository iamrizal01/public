<?php
require 'includes/config.php';
require 'includes/functions.php';

echo "ROOT: " . ROOT . "\n";
echo "DB Path: " . ROOT . "/data.db\n";
echo "Is DB writable? " . (is_writable(ROOT . '/data.db') ? "Yes" : "No") . "\n";
echo "Is uploads writable? " . (is_writable(UPLOAD_DIR) ? "Yes" : "No") . "\n";

try {
    $db = new SQLite3(ROOT . '/data.db');
    $db->exec("CREATE TABLE IF NOT EXISTS test_table (id INTEGER PRIMARY KEY, val TEXT)");
    $db->exec("INSERT INTO test_table (val) VALUES ('test')");
    echo "[PASS] Database write successful.\n";
    $db->exec("DROP TABLE test_table");
} catch (Exception $e) {
    echo "[FAIL] Database write failed: " . $e->getMessage() . "\n";
}

$test_file = UPLOAD_DIR . 'test.txt';
if (file_put_contents($test_file, 'test')) {
    echo "[PASS] Upload directory write successful.\n";
    unlink($test_file);
} else {
    echo "[FAIL] Upload directory write failed.\n";
}
