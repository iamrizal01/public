<?php
require __DIR__ . '/../../includes/core.php';

$page_title = 'Public Chat';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>PostAja - Public Chat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0d6efd;
            --primary-dark: #0a58ca;
            --dark: #1a1a2e;
            --dark-light: #16213e;
            --gray: #6c757d;
            --gray-light: #f8f9fa;
            --white: #ffffff;
            --border: #e9ecef;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --shadow-hover: 0 8px 30px rgba(0, 0, 0, 0.12);
            --border-radius: 16px;
            --border-radius-sm: 12px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8ec 100%);
            min-height: 100vh;
        }

        .chat-header {
            background: var(--white);
            padding: 20px 24px;
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .chat-header h4 {
            font-weight: 700;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .chat-header h4 i {
            background: linear-gradient(135deg, var(--primary) 0%, #0a58ca 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .chat-header .online-count {
            font-size: 0.85rem;
            color: var(--gray);
            background: var(--gray-light);
            padding: 6px 14px;
            border-radius: 20px;
        }

        .chat-container {
            max-width: 800px;
            margin: 24px auto;
            padding: 0 16px;
        }

        .chat-messages {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            height: 65vh;
            overflow-y: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .message {
            display: flex;
            gap: 12px;
            animation: messageIn 0.3s ease;
        }

        @keyframes messageIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .message.mine {
            flex-direction: row-reverse;
        }

        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            overflow: hidden;
            flex-shrink: 0;
        }

        .message-content {
            max-width: 70%;
        }

        .message-bubble {
            background: var(--gray-light);
            padding: 12px 16px;
            border-radius: var(--border-radius-sm);
            border-top-left-radius: 4px;
        }

        .message.mine .message-bubble {
            background: linear-gradient(135deg, var(--primary) 0%, #0a58ca 100%);
            color: var(--white);
            border-top-left-radius: var(--border-radius-sm);
            border-top-right-radius: 4px;
        }

        .message-user {
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--dark);
            margin-bottom: 4px;
        }

        .message.mine .message-user {
            color: rgba(255,255,255,0.8);
        }

        .message-text {
            font-size: 0.95rem;
            line-height: 1.5;
        }

        .message-time {
            font-size: 0.7rem;
            color: var(--gray);
            margin-top: 6px;
        }

        .message.mine .message-time {
            color: rgba(255,255,255,0.6);
            text-align: right;
        }

        .chat-input-container {
            background: var(--white);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 16px;
            margin-top: 16px;
        }

        .chat-input-wrapper {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .chat-input {
            flex: 1;
            border: 2px solid var(--border);
            border-radius: var(--border-radius-sm);
            padding: 14px 18px;
            font-size: 0.95rem;
            transition: var(--transition);
            font-family: inherit;
        }

        .chat-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.1);
        }

        .chat-send-btn {
            background: linear-gradient(135deg, var(--primary) 0%, #0a58ca 100%);
            color: var(--white);
            border: none;
            padding: 14px 28px;
            border-radius: var(--border-radius-sm);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .chat-send-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(13, 110, 253, 0.3);
        }

        .empty-chat {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: var(--gray);
        }

        .empty-chat i {
            font-size: 4rem;
            opacity: 0.3;
            margin-bottom: 16px;
        }

        .login-prompt {
            background: linear-gradient(135deg, var(--dark) 0%, var(--dark-light) 100%);
            color: var(--white);
            padding: 24px;
            border-radius: var(--border-radius);
            text-align: center;
            margin-bottom: 16px;
        }

        .login-prompt a {
            color: var(--primary);
            font-weight: 600;
        }

        @media (max-width: 768px) {
            .chat-messages {
                height: 55vh;
            }
            
            .message-content {
                max-width: 85%;
            }
            
            .chat-input-wrapper {
                flex-direction: column;
            }
            
            .chat-send-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="chat-header">
        <div class="d-flex justify-content-between align-items-center">
            <h4><i class="bi bi-chat-square-quote-fill"></i> Public Chat</h4>
            <span class="online-count"><i class="bi bi-circle-fill text-success me-2" style="font-size: 0.5rem;"></i>Public Room</span>
        </div>
    </div>

    <div class="chat-container">
        <?php if (!isset($_SESSION['user_id'])): ?>
        <div class="login-prompt">
            <i class="bi bi-info-circle-fill me-2"></i>
            Silakan <a href="../../index.php">login</a> untuk berpartisipasi dalam obrolan publik.
        </div>
        <?php endif; ?>

        <div class="chat-messages" id="chatWindow">
            <?php
            $q = $db->query('SELECT public_chat.*, users.username, users.avatar_url FROM public_chat JOIN users ON public_chat.user_id = users.id ORDER BY public_chat.created_at DESC LIMIT 100');
            $messages = [];
            while ($m = $q->fetchArray(SQLITE3_ASSOC)) {
                $messages[] = $m;
            }
            $messages = array_reverse($messages);
            
            if (empty($messages)): ?>
            <div class="empty-chat">
                <i class="bi bi-chat-dots"></i>
                <p>Belum ada pesan. Mulai percakapan!</p>
            </div>
            <?php else: ?>
                <?php foreach ($messages as $m): ?>
                    <?php 
                    $me = isset($_SESSION['user_id']) && $_SESSION['user_id'] == $m['user_id'];
                    $avatarSrc = $m['avatar_url'] ?? '';
                    if (!empty($avatarSrc) && !preg_match('~^https?://|^//|^/~', $avatarSrc)) {
                        $avatarSrc = '../../' . ltrim($avatarSrc, '/');
                    }
                    ?>
                    <div class="message <?= $me ? 'mine' : '' ?>">
                        <div class="message-avatar">
                            <?php if (!empty($m['avatar_url'])): ?>
                            <img src="<?= htmlspecialchars($avatarSrc) ?>" style="width:40px;height:40px;object-fit:cover;border-radius:12px;">
                            <?php else: ?>
                            <div style="width:40px;height:40px;background:linear-gradient(135deg,#0d6efd,#0056b3);border-radius:12px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">
                                <?= strtoupper(substr($m['username'], 0, 1)) ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="message-content">
                            <div class="message-user">@<?= htmlspecialchars($m['username']) ?></div>
                            <div class="message-bubble">
                                <div class="message-text"><?= htmlspecialchars($m['message']) ?></div>
                            </div>
                            <div class="message-time"><?= date('d M, H:i', strtotime($m['created_at'])) ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <?php if (isset($_SESSION['user_id'])): ?>
        <form method="POST" class="chat-input-container" onsubmit="return checkAuth(event)">
            <div class="chat-input-wrapper">
                <input type="text" name="chat_message" class="chat-input" placeholder="Tulis pesan publik..." required>
                <button name="send_chat" class="chat-send-btn">
                    <i class="bi bi-send-fill"></i> Kirim
                </button>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <script>
        const chatWindow = document.getElementById('chatWindow');
        if (chatWindow) {
            chatWindow.scrollTop = chatWindow.scrollHeight;
        }
        
        function checkAuth(event) {
            <?php if (!isset($_SESSION['user_id'])): ?>
            event.preventDefault();
            alert('Silakan login terlebih dahulu!');
            return false;
            <?php endif; ?>
            return true;
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
