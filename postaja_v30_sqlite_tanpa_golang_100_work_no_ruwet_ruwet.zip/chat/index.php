<?php
$root_path = '../'; $api_path = '../api/'; $home_url = '../index.php';
$current_page = 'chat'; $page_title = 'Public Chat';
require '../includes/config.php';
require '../includes/functions.php';
require '../includes/auth_handler.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id']) && isset($_POST['send_chat'])) {
    $censored = censorMessage($_POST['chat_message']);
    $stmt = $db->prepare('INSERT INTO public_chat (user_id, message) VALUES (:u,:m)');
    $stmt->bindValue(':u', (int)$_SESSION['user_id']);
    $stmt->bindValue(':m', $censored['text']);
    $stmt->execute();
    header('Location: index.php' . ($censored['violation'] ? '?warned=1' : '')); exit;
}

require '../includes/header.php';
?>

<div class="chat-container" id="chatWindow">
<?php
$chats = $db->query('SELECT public_chat.*, users.username, users.avatar_url FROM public_chat JOIN users ON public_chat.user_id=users.id ORDER BY public_chat.id ASC LIMIT 100');
while ($ch = $chats->fetchArray(SQLITE3_ASSOC)):
    $is_mine = (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $ch['user_id']);
?>
<div class="d-flex <?= $is_mine ? 'justify-content-end' : 'justify-content-start' ?> mb-2 align-items-end gap-2">
    <?php if (!$is_mine): ?><?= getAvatarHtml($ch['username'], $ch['avatar_url'] ?? '', 28) ?><?php endif; ?>
    <div class="chat-bubble <?= $is_mine ? 'chat-me' : 'chat-other' ?>">
        <?php if (!$is_mine): ?>
        <div style="font-size:.68rem;font-weight:800;opacity:.7;">
            <a href="../profile/?u=<?= urlencode($ch['username']) ?>" style="color:inherit;text-decoration:none;">@<?= htmlspecialchars($ch['username']) ?></a>
        </div>
        <?php endif; ?>
        <div style="font-size:.9rem;"><?= nl2br(htmlspecialchars($ch['message'])) ?></div>
        <div style="font-size:.65rem;opacity:.5;text-align:right;"><?= date('H:i', strtotime($ch['created_at'])) ?></div>
    </div>
</div>
<?php endwhile; ?>
</div>

<div class="p-3 border-top bg-white">
    <form method="POST" onsubmit="return checkAuth(event)">
        <div class="input-group">
            <input type="text" name="chat_message" class="form-control border-0 bg-light px-4" placeholder="Type a public message..." required autocomplete="off">
            <button name="send_chat" class="btn btn-dark px-4"><i class="bi bi-send-fill"></i></button>
        </div>
    </form>
</div>
<script>const cw=document.getElementById('chatWindow');if(cw)cw.scrollTop=cw.scrollHeight;</script>

<?php require '../includes/footer.php'; ?>
