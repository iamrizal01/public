<?php
require __DIR__ . '/../../includes/core.php';
// Simple placeholder for private chat UI
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>PostAja - Private Chat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/style.css">
</head>
<body>
<div class="container py-4">
    <h4>Private Chat (placeholder)</h4>
    <p class="text-muted">Fitur private chat belum diimplementasikan secara penuh. Anda dapat memakai public chat atau integrasikan websocket/DB untuk private messages.</p>
</div>
<script>window.IS_LOGGED_IN = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/script.js"></script>
</body>
</html>
