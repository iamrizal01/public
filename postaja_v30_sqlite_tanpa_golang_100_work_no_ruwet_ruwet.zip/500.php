<?php
http_response_code(500);
$attempted_url = isset($_SERVER['REQUEST_URI']) ? htmlspecialchars($_SERVER['REQUEST_URI'], ENT_QUOTES, 'UTF-8') : 'halaman ini';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>500 Internal Server Error - PostAja</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #ffffff;
            --text-main: #1a1a1a;
            --text-muted: #666666;
            --accent-blue: #0066ff;
            --border-color: #eeeeee;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { 
            background-color: var(--bg-color); 
            color: var(--text-main); 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            min-height: 100vh; 
            padding: 20px;
        }

        .container {
            text-align: center;
            max-width: 550px;
        }

        h1 {
            font-size: 8rem;
            font-weight: 800;
            line-height: 1;
            color: var(--accent-blue);
            margin-bottom: 1rem;
            letter-spacing: -5px;
        }

        h2 {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        p {
            color: var(--text-muted);
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }

        .attempted-url {
            background: #fff0f0;
            color: #dc3545;
            padding: 8px 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 0.9rem;
            word-break: break-all;
            display: inline-block;
            margin-bottom: 1.5rem;
            border: 1px solid #ffc8c8;
        }

        .btn {
            display: inline-block;
            padding: 0.8rem 2rem;
            background: var(--accent-blue);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
            transition: 0.2s;
        }

        .btn:hover {
            background: #0052cc;
            transform: translateY(-2px);
        }

        .footer {
            margin-top: 3rem;
            font-size: 0.8rem;
            color: #ccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>500</h1>
        <h2>Aduh! Server Gagal Merespon.</h2>
        
        <p>Maaf, server kami mengalami kendala teknis saat mencoba memuat rute berikut:</p>
        <div class="attempted-url"><?php echo $attempted_url; ?></div>
        
        <p>Mungkin Redis sedang istirahat atau ada sistem yang sibuk. Tim kami sudah diberitahu dan sedang berusaha memperbaikinya secepat mungkin.</p>
        
        <a href="/" class="btn">Kembali ke Beranda</a>
        
        <div class="footer">
            ID Kesalahan: <?php echo bin2hex(random_bytes(4)); ?> | PostAja System
        </div>
    </div>
</body>
</html>
