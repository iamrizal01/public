<?php
$root_path = '/'; 
$api_path = '/api/'; 
$home_url = '/index.php';
$current_page = 'profile'; 
$page_title = 'Profile';

require '../includes/config.php';
require '../includes/functions.php';
require '../includes/auth_handler.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        die('Invalid CSRF token');
    }
    if (isset($_POST['update_avatar'])) {
        if (!empty($_FILES['avatar_file']['name'])) {
            $allowGif = isPremiumUser($db, (int)$_SESSION['user_id']);
            $uploadResult = handleImageUpload($_FILES['avatar_file'], $allowGif);
            if ($uploadResult['success']) {
                $stmt = $db->prepare('UPDATE users SET avatar_url=:a WHERE id=:id');
                $stmt->bindValue(':a', $uploadResult['path']); 
                $stmt->bindValue(':id', (int)$_SESSION['user_id'], SQLITE3_INTEGER);
                $stmt->execute(); 
                $_SESSION['avatar_url'] = $uploadResult['path'];
                $success_msg = 'Avatar updated.';
            } else {
                $error_msg = $uploadResult['error'];
            }
        } else {
            $url = trim($_POST['avatar_url'] ?? '');
            if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
                $stmt = $db->prepare('UPDATE users SET avatar_url=:a WHERE id=:id');
                $stmt->bindValue(':a', $url); 
                $stmt->bindValue(':id', (int)$_SESSION['user_id'], SQLITE3_INTEGER);
                $stmt->execute(); 
                $_SESSION['avatar_url'] = $url;
                $success_msg = 'Avatar updated.';
            }
        }
        header('Location: /profile/' . urlencode($_SESSION['username'])); 
        exit;
    }
    if (isset($_POST['update_bio'])) {
        $bio = substr(trim($_POST['bio']), 0, 300);
        $stmt = $db->prepare('UPDATE users SET bio=:b WHERE id=:id');
        $stmt->bindValue(':b', $bio); 
        $stmt->bindValue(':id', (int)$_SESSION['user_id'], SQLITE3_INTEGER);
        $stmt->execute(); 
        $success_msg = 'Bio updated.';
        header('Location: /profile/' . urlencode($_SESSION['username'])); 
        exit;
    }
}

$view_profile = null;
if (isset($_GET['u'])) {
    $target_user = trim($_GET['u'], '/'); 
    $stmt = $db->prepare('SELECT * FROM users WHERE username=:u');
    $stmt->bindValue(':u', $target_user);
    $view_profile = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
}

if (!$view_profile) { 
    header('Location: /index.php'); 
    exit; 
}

$is_silo = in_array($view_profile['username'], ['silo','rizal']);
$is_me   = isset($_SESSION['user_id']) && $_SESSION['user_id'] == $view_profile['id'];
$is_superadmin = $view_profile['role'] === 'superadmin';
$show_username = true; 
$is_premium = isset($view_profile['is_premium']) && $view_profile['is_premium'] == 1;

$is_following = false;
if (isset($_SESSION['user_id']) && !$is_me) {
    $is_following = (bool)$db->querySingle("SELECT COUNT(*) FROM follows WHERE follower_id=".(int)$_SESSION['user_id']." AND following_id=".(int)$view_profile['id']);
}
$f_ers = (int)$db->querySingle("SELECT COUNT(*) FROM follows WHERE following_id=".(int)$view_profile['id']);
$f_ing = (int)$db->querySingle("SELECT COUNT(*) FROM follows WHERE follower_id=".(int)$view_profile['id']);
$post_count = (int)$db->querySingle("SELECT COUNT(*) FROM posts WHERE user_id=".(int)$view_profile['id']);

require '../includes/header.php';
?>

<div class="profile-header">
    <div class="profile-banner">
        <?php if ($is_me): ?>
        <button class="btn btn-dark rounded-circle position-absolute settings-gear-btn" data-bs-toggle="modal" data-bs-target="#settingsModal">
            <i class="bi bi-gear-fill"></i>
        </button>
        <style>
        .settings-gear-btn { top: 15px; right: 15px; width: 40px; height: 40px; z-index: 100; }
        @media (max-width: 576px) { .settings-gear-btn { top: 10px; right: 10px; width: 36px; height: 36px; } .settings-gear-btn i { font-size: 0.9rem; } }
        @media (min-width: 1200px) { .settings-gear-btn { top: 20px; right: 20px; width: 44px; height: 44px; } }
        </style>
        <?php endif; ?>
    </div>
    <div class="profile-avatar-wrapper">
        <div class="profile-avatar-main">
            <?php
            $rawAvatar = $view_profile['avatar_url'] ?? '';
            $avatarSrc = $rawAvatar;
            if (!empty($avatarSrc) && !preg_match('~^https?://|^//|^/~', $avatarSrc)) {
                $avatarSrc = '/' . ltrim($avatarSrc, '/');
            }
            ?>
            <?php if (!empty($view_profile['avatar_url'])): ?>
                <img src="<?= htmlspecialchars($avatarSrc) ?>" style="width:110px;height:110px;border-radius:50%;object-fit:cover;border:4px solid #fff;">
            <?php else: ?>
                <?= strtoupper(substr($view_profile['username'], 0, 1)) ?>
            <?php endif; ?>
        </div>
        <div class="profile-action-buttons">
            <?php if (!$is_me && isset($_SESSION['user_id'])): ?>
                <button onclick="toggleFollow(<?= $view_profile['id'] ?>)" id="follow-btn" class="btn-follow <?= $is_following ? 'following' : 'unfollow' ?>">
                    <i class="bi bi-<?= $is_following ? 'check' : 'person-plus' ?>"></i>
                    <?= $is_following ? 'Following' : 'Follow' ?></button>
                <a href="/dm/?with=<?= urlencode($view_profile['username']) ?>" class="btn-action-primary"><i class="bi bi-envelope"></i> DM</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="profile-details">
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <h4 class="fw-bold mb-0">@<?= htmlspecialchars($view_profile['username']) ?></h4>
            <?php if (!$view_profile['is_active']): ?>
                <span class="badge bg-danger border-0 px-2 py-1" style="font-size:.72rem;">Suspended</span>
            <?php endif; ?>
        </div>
        <p class="text-muted mb-2 small"><?= htmlspecialchars($view_profile['role']) ?> • Joined <?= date('M Y', strtotime($view_profile['created_at'])) ?></p>

        <p class="mb-3"><?= nl2br(htmlspecialchars($view_profile['bio'] ?: 'No bio yet.')) ?></p>

        <?php if ($is_me): ?>
        <div class="d-flex gap-2 mb-3">
            <button class="btn btn-outline-dark btn-sm rounded-pill" data-bs-toggle="collapse" data-bs-target="#editProfilePanel">
                <i class="bi bi-pencil"></i> Edit Profile</button>
        </div>
        <div class="collapse mb-3" id="editProfilePanel">
            <div class="card border rounded-4 p-3">
                <form method="POST" class="mb-2">
                    <?= csrfField() ?>
                    <label class="form-label fw-bold small">Bio</label>
                    <textarea name="bio" class="form-control form-control-sm mb-2" rows="3" maxlength="300"><?= htmlspecialchars($view_profile['bio'] ?? '') ?></textarea>
                    <button name="update_bio" class="btn btn-primary btn-sm rounded-pill">Save Bio</button>
                </form>
                <hr>
                <form method="POST" enctype="multipart/form-data">
                    <?= csrfField() ?>
                    <label class="form-label fw-bold small">Upload Avatar (max 10MB)</label>
                    <div class="mb-2">
                        <input type="file" name="avatar_file" class="form-control form-control-sm" accept="image/jpeg,image/png,image/gif,image/webp">
                    </div>
                    <label class="form-label fw-bold small">Or Avatar URL</label>
                    <div class="input-group input-group-sm">
                        <input type="url" name="avatar_url" class="form-control" placeholder="https://..." value="<?= htmlspecialchars($view_profile['avatar_url'] ?? '') ?>">
                        <button name="update_avatar" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <div class="d-flex gap-4">
            <div><b><?= $post_count ?></b> <span class="text-muted">Posts</span></div>
            <div><b><?= $f_ing ?></b> <span class="text-muted">Following</span></div>
            <div><b><?= $f_ers ?></b> <span class="text-muted">Followers</span></div>
        </div>
    </div>
    <div class="profile-tabs">
        <div class="profile-tab-item active" onclick="switchTab('posts',this)">Posts</div>
        <div class="profile-tab-item" onclick="switchTab('badges',this)">Badges</div>
    </div>
</div>

<div class="modal fade" id="settingsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4" style="min-height:450px;">
            <div class="modal-header border-0">
                <h5 class="modal-title fw-bold">Settings</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <div class="d-flex border-bottom">
                    <button class="flex-fill btn border-0 py-3 fw-bold settings-tab active" data-tab="account" onclick="switchSettingsTab(this, 'account')">Account</button>
                    <button class="flex-fill btn border-0 py-3 fw-bold settings-tab" data-tab="privacy" onclick="switchSettingsTab(this, 'privacy')">Privacy</button>
                    <button class="flex-fill btn border-0 py-3 fw-bold settings-tab" data-tab="moderation" onclick="switchSettingsTab(this, 'moderation')">Moderation</button>
                </div>
                
                <div id="settings-account" class="settings-content p-3">
                    <form method="POST" action="/api/settings.php" id="accountForm">
                        <?= csrfField() ?>
                        <input type="hidden" name="action" value="account">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($view_profile['email'] ?? '') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Date of Birth</label>
                            <select name="date_of_birth" class="form-select" required>
                                <?php 
                                $current_dob = $view_profile['date_of_birth'] ?? '';
                                $years = range(1950, 2010);
                                foreach($years as $y): 
                                ?>
                                <option value="<?= $y ?>" <?= $current_dob == $y ? 'selected' : '' ?>><?= $y ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">New Password</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Leave blank to keep current">
                        </div>
                        <button type="submit" class="btn btn-primary w-100 rounded-pill fw-bold">Save Changes</button>
                    </form>
                </div>
                
                <div id="settings-privacy" class="settings-content p-3" style="display:none;">
                    <div class="d-flex justify-content-between align-items-center p-3 bg-light rounded-4 mb-3">
                        <div>
                            <div class="fw-bold">Multi-layered Security</div>
                            <div class="small text-muted">Require login every 1 hour</div>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="mlsToggle" <?= ($view_profile['multi_layer_security'] ?? 0) ? 'checked' : '' ?> onchange="toggleMLS(this)">
                        </div>
                    </div>
                </div>
                
                <div id="settings-moderation" class="settings-content p-3" style="display:none;">
                    <div class="d-flex justify-content-between align-items-center p-3 bg-light rounded-4 mb-3">
                        <div>
                            <div class="fw-bold">Spam Filter</div>
                            <div class="small text-muted">Hide repeated spam content</div>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="spamToggle" <?= ($view_profile['spam_filter'] ?? 0) ? 'checked' : '' ?> onchange="toggleSpam(this)">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function switchSettingsTab(btn, tab) {
    document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.settings-content').forEach(c => c.style.display = 'none');
    document.getElementById('settings-' + tab).style.display = 'block';
}
function toggleMLS(checkbox) {
    fetch('/api/settings.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=mls&value=' + (checkbox.checked ? 1 : 0)
    });
}
function toggleSpam(checkbox) {
    fetch('/api/settings.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=spam&value=' + (checkbox.checked ? 1 : 0)
    });
}
</script>

<div id="tab-posts">
<?php
$ps = $db->prepare('SELECT posts.*, users.username, users.role, users.avatar_url, users.is_premium FROM posts JOIN users ON posts.user_id=users.id WHERE users.username=:u ORDER BY posts.created_at DESC');
$ps->bindValue(':u', $view_profile['username']);
$res = $ps->execute();
$any = false;
while ($p = $res->fetchArray(SQLITE3_ASSOC)) { echo renderPostHtml($p, $db); $any = true; }
if (!$any) echo '<div class="p-4 text-center text-muted">No posts yet.</div>';
?>
</div>

<div id="tab-badges" style="display:none;">
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:15px;padding:20px;">
    <?php if ($view_profile['role'] === 'superadmin'): ?>
    <div class="text-center badge-item" onclick="showBadgeInfo('superadmin','Super Admin','Official administrator of PostAja.')" style="cursor:pointer;"><img src="https://cdn-icons-png.flaticon.com/512/6270/6270515.png" style="width:60px;height:60px;margin-bottom:5px;"><div style="font-size:.8rem;font-weight:600;">Super Admin</div></div>
    <?php endif; ?>
    <?php if ($is_premium): ?>
    <div class="text-center badge-item" onclick="showBadgeInfo('premium','Premium','Supporter of PostAja.')" style="cursor:pointer;"><img src="https://cdn-icons-png.flaticon.com/512/2583/2583344.png" style="width:60px;height:60px;margin-bottom:5px;"><div style="font-size:.8rem;font-weight:600;">Premium</div></div>
    <?php endif; ?>
    <div class="text-center badge-item" onclick="showBadgeInfo('early','Early User','Joined during early launch.')" style="cursor:pointer;"><img src="https://cdn-icons-png.flaticon.com/512/2111/2111463.png" style="width:60px;height:60px;margin-bottom:5px;"><div style="font-size:.8rem;font-weight:600;">Early User</div></div>
</div>
</div>

<div class="modal fade" id="badgeInfoModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-5 p-4 text-center">
            <img id="badgeInfoImg" src="" style="width:80px;height:80px;margin:0 auto 15px;">
            <h5 class="fw-bold" id="badgeInfoTitle"></h5>
            <p class="text-muted" id="badgeInfoDesc"></p>
            <button type="button" class="btn btn-primary rounded-pill px-4" data-bs-dismiss="modal">Close</button>
        </div>
    </div>
</div>

<script>
function showBadgeInfo(badge, title, desc) {
    document.getElementById('badgeInfoTitle').innerText = title;
    document.getElementById('badgeInfoDesc').innerText = desc;
    const badgeImages = {
        'superadmin': 'https://cdn-icons-png.flaticon.com/512/6270/6270515.png',
        'premium': 'https://cdn-icons-png.flaticon.com/512/2583/2583344.png',
        'early': 'https://cdn-icons-png.flaticon.com/512/2111/2111463.png'
    };
    document.getElementById('badgeInfoImg').src = badgeImages[badge] || '';
    new bootstrap.Modal(document.getElementById('badgeInfoModal')).show();
}
</script>

<?php require '../includes/footer.php'; ?>
