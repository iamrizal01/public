<?php
$root_path = '../'; $api_path = '../api/'; $home_url = '../index.php';
$current_page = 'bookmarks'; $page_title = 'Bookmarks';
require '../includes/config.php';
require '../includes/functions.php';
require '../includes/auth_handler.php';

if (!isset($_SESSION['user_id'])) { header('Location: ../index.php'); exit; }
$uid = (int)$_SESSION['user_id'];

require '../includes/header.php';
?>

<div class="p-3 border-bottom">
    <p class="text-muted small mb-0">Posts you bookmark are private and only visible to you.</p>
</div>

<?php
$res = $db->query("
    SELECT posts.*, users.username, users.role, users.avatar_url
    FROM bookmarks
    JOIN posts ON bookmarks.post_id = posts.id
    JOIN users ON posts.user_id = users.id
    WHERE bookmarks.user_id = $uid
    ORDER BY bookmarks.created_at DESC
");
$any = false;
while ($p = $res->fetchArray(SQLITE3_ASSOC)) { echo renderPostHtml($p, $db); $any = true; }
if (!$any): ?>
<div class="p-5 text-center text-muted">
    <i class="bi bi-bookmark display-3 mb-3 d-block opacity-25"></i>
    <p>No bookmarked posts yet.</p>
    <a href="../index.php" class="btn btn-primary rounded-pill px-4">Explore Feed</a>
</div>
<?php endif; ?>

<?php require '../includes/footer.php'; ?>
