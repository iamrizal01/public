<?php
$root_path = '../'; $api_path = '../api/'; $home_url = '../index.php';
$current_page = 'home'; $page_title = 'Post';
require '../includes/config.php';
require '../includes/functions.php';
require '../includes/auth_handler.php';

$post_id = (int)($_GET['id'] ?? 0);
if (!$post_id) { header('Location: ../index.php'); exit; }

$stmt = $db->prepare('SELECT posts.*, users.username, users.role, users.avatar_url FROM posts JOIN users ON posts.user_id=users.id WHERE posts.id=:id');
$stmt->bindValue(':id', $post_id, SQLITE3_INTEGER);
$post = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
if (!$post) { header('Location: ../index.php'); exit; }

$page_title = 'Post by @' . $post['username'];

require '../includes/header.php';
?>

<div class="p-2 border-bottom">
    <a href="javascript:history.back()" class="btn btn-sm btn-light rounded-pill"><i class="bi bi-arrow-left"></i> Back</a>
</div>

<?= renderPostHtml($post, $db) ?>

<?php require '../includes/footer.php'; ?>
