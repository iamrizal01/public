<?php
/**
 * PostAja Security & Bug Test Bot v2.1
 */

require_once 'includes/config.php';
require_once 'includes/functions.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

$results = [];

function log_test($name, $status, $message) {
    global $results;
    $results[] = [
        'name' => $name,
        'status' => $status ? 'PASS' : 'FAIL',
        'message' => $message
    ];
}

echo "=== POSTAJA BUG TEST BOT v2.1 ===\n";

// 1. Check SuperAdmin existence & credentials
$stmt = $db->prepare("SELECT role, password FROM users WHERE username = :u");
$stmt->bindValue(':u', 'rizal');
$res = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
if ($res && $res['role'] === 'superadmin') {
    log_test("SuperAdmin Account", true, "User 'rizal' is superadmin.");
} else {
    log_test("SuperAdmin Account", false, "User 'rizal' is NOT superadmin or missing.");
}

// 2. Check for PHP Leaks in critical files
$files_to_check = ['index.php', 'includes/functions.php', 'includes/config.php', 'includes/auth_handler.php'];
foreach ($files_to_check as $f) {
    $content = file_get_contents($f);
    // Look for raw 'db->' or 'stmt->' outside PHP tags (simplified check)
    if (preg_match('/\?>[ \t\r\n]*db->/', $content) || preg_match('/\?>[ \t\r\n]*stmt->/', $content)) {
        log_test("PHP Leak Check: $f", false, "Possible PHP code leak detected outside tags.");
    } else {
        log_test("PHP Leak Check: $f", true, "No obvious leaks.");
    }
}

// 3. Check for Translate in functions.php
$func_content = file_get_contents('includes/functions.php');
if (strpos($func_content, 'onclick="translatePost(') !== false) {
    log_test("Translate Feature", true, "Translate function call found in functions.php.");
} else {
    log_test("Translate Feature", false, "Translate function call MISSING in functions.php.");
}

// 4. Check for OTP Bypass logic in auth_handler.php
$auth_content = file_get_contents('includes/auth_handler.php');
if (strpos($auth_content, 'Bypass OTP for superadmins') !== false) {
    log_test("OTP Bypass Logic", true, "Superadmin OTP bypass found.");
} else {
    log_test("OTP Bypass Logic", false, "Superadmin OTP bypass MISSING.");
}

// 5. Database Integrity
$tables = ['users', 'posts', 'reports', 'messages'];
foreach ($tables as $table) {
    $check = $db->querySingle("SELECT name FROM sqlite_master WHERE type='table' AND name='$table'");
    log_test("Table Existence: $table", (bool)$check, $check ? "Exists." : "MISSING.");
}

// 6. Column checks for Post & DM enhancements
$cols_to_check = [
    'posts' => ['music_url', 'music_title'],
    'messages' => ['image_url', 'is_liked', 'deleted_for']
];
foreach ($cols_to_check as $table => $cols) {
    $res = $db->query("PRAGMA table_info($table)");
    $existing_cols = [];
    while($row = $res->fetchArray(SQLITE3_ASSOC)) {
        $existing_cols[] = $row['name'];
    }
    foreach ($cols as $col) {
        $has_col = in_array($col, $existing_cols);
        log_test("Column Check: $table.$col", $has_col, $has_col ? "Found." : "MISSING.");
    }
}

// 7. Directory checks
$dirs = ['uploads/', 'uploads/dm/'];
foreach ($dirs as $dir) {
    $path = ROOT . '/' . $dir;
    log_test("Directory Check: $dir", is_dir($path), is_dir($path) ? "Exists." : "MISSING.");
}

echo "\n--- SUMMARY ---\n";
foreach ($results as $r) {
    $status = $r['status'] === 'PASS' ? "\033[32mPASS\033[0m" : "\033[31mFAIL\033[0m";
    echo "[$status] {$r['name']}: {$r['message']}\n";
}
