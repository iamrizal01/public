<?php
require '../includes/config.php';

if (!isset($_SESSION['user_id'])) { echo json_encode(null); exit; }

$uid = (int)$_SESSION['user_id'];
$stmt = $db->prepare('
    SELECT m.*, u.username AS sender_username 
    FROM messages m 
    JOIN users u ON m.sender_id = u.id 
    WHERE m.receiver_id = :u AND m.is_shown = 0 
    ORDER BY m.created_at DESC 
    LIMIT 1
');
$stmt->bindValue(':u', $uid, SQLITE3_INTEGER);
$dm = $stmt->execute()->fetchArray(SQLITE3_ASSOC);

if ($dm) {
    $db->exec("UPDATE messages SET is_shown=1 WHERE id=" . (int)$dm['id']);
    echo json_encode([
        'id' => $dm['id'],
        'message' => '@' . $dm['sender_username'] . ' mengirim pesan: ' . substr($dm['content'], 0, 50) . (strlen($dm['content']) > 50 ? '...' : ''),
        'link' => '../dm/?with=' . urlencode($dm['sender_username'])
    ]);
} else {
    echo json_encode(null);
}
