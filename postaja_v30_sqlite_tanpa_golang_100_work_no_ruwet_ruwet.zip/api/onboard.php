<?php
require '../includes/config.php';
require '../includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$uid = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $favorite = strtolower(trim($_POST['favorite'] ?? ''));
    $hobby    = trim($_POST['hobby'] ?? '');

    $stmt = $db->prepare('UPDATE users SET favorite = :fav, hobby = :hob, onboarded = 1 WHERE id = :id');
    if ($stmt) {
        $stmt->bindValue(':fav', $favorite);
        $stmt->bindValue(':hob', $hobby);
        $stmt->bindValue(':id', $uid, SQLITE3_INTEGER);
        $stmt->execute();
    }

    // Optional: follow rekomendasi yang dipilih user
    if (!empty($_POST['follow_ids']) && is_array($_POST['follow_ids'])) {
        foreach ($_POST['follow_ids'] as $fid) {
            $following_id = (int)$fid;
            if ($following_id && $following_id !== $uid) {
                $exists = $db->querySingle("SELECT id FROM follows WHERE follower_id=$uid AND following_id=$following_id");
                if (!$exists) {
                    $fs = $db->prepare('INSERT INTO follows (follower_id, following_id) VALUES (:fer,:fing)');
                    if ($fs) {
                        $fs->bindValue(':fer', $uid, SQLITE3_INTEGER);
                        $fs->bindValue(':fing', $following_id, SQLITE3_INTEGER);
                        $fs->execute();
                    }
                }
            }
        }
    }

    header('Location: ../index.php');
    exit;
}

header('Location: ../index.php');
exit;

