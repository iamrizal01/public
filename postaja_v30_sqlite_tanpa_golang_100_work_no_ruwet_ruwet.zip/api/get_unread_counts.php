<?php
require '../includes/config.php';
require '../includes/functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'login_required']);
    exit;
}

$uid = (int)$_SESSION['user_id'];
$notif_count = getUnreadNotifCount($db, $uid);
$dm_count = getUnreadDmCount($db, $uid);

echo json_encode([
    'status' => 'success',
    'notif_count' => $notif_count,
    'dm_count' => $dm_count
]);
