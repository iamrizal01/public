<?php
require '../includes/config.php';
require '../includes/functions.php';

function formatCount($num) {
    if ($num >= 1000000000000) return round($num / 1000000000000, 1) . 'T';
    if ($num >= 1000000000) return round($num / 1000000000, 1) . 'B';
    if ($num >= 1000000) return round($num / 1000000, 1) . 'M';
    if ($num >= 1000) return round($num / 1000, 1) . 'K';
    return (string)$num;
}

if (!isset($_SESSION['user_id'])) { echo json_encode(['status'=>'error','message'=>'login_required']); exit; }

$p_id = (int)($_GET['like_post'] ?? 0);
$u_id = (int)$_SESSION['user_id'];
if (!$p_id) { echo json_encode(['status'=>'error']); exit; }

$exists = $db->querySingle("SELECT id FROM likes WHERE post_id=$p_id AND user_id=$u_id");
if ($exists) {
    $db->exec("DELETE FROM likes WHERE post_id=$p_id AND user_id=$u_id");
    $status = 'unliked';
} else {
    $stmt = $db->prepare('INSERT INTO likes (post_id, user_id) VALUES (:p,:u)');
    $stmt->bindValue(':p', $p_id, SQLITE3_INTEGER);
    $stmt->bindValue(':u', $u_id, SQLITE3_INTEGER);
    $stmt->execute();
    $status = 'liked';
    // Notify post owner
    $owner_id = (int)$db->querySingle("SELECT user_id FROM posts WHERE id=$p_id");
    sendNotification($db, $owner_id, $u_id, 'like', "@{$_SESSION['username']} liked your post.", "../post/?id=$p_id");
}

$count = (int)$db->querySingle("SELECT COUNT(*) FROM likes WHERE post_id=$p_id");
// Mengirim data count asli dan yang sudah diformat (1K, 1M)
echo json_encode(['status'=>$status, 'count'=>$count, 'formatted_count'=>formatCount($count)]);
