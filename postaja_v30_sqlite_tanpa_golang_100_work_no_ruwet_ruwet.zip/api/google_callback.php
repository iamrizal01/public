<?php
require_once __DIR__ . '/../includes/config.php';

header('Content-Type: application/json');

$code = $_GET['code'] ?? '';
$error = $_GET['error'] ?? '';

if ($error) {
    header('Location: ../index.php?google_error=' . urlencode($error));
    exit;
}

if (empty($code)) {
    header('Location: ../index.php?google_error=No authorization code received');
    exit;
}

$tokenUrl = 'https://oauth2.googleapis.com/token';
$tokenData = [
    'code' => $code,
    'client_id' => GOOGLE_CLIENT_ID,
    'client_secret' => GOOGLE_CLIENT_SECRET,
    'redirect_uri' => GOOGLE_REDIRECT_URI,
    'grant_type' => 'authorization_code'
];

$ch = curl_init($tokenUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($tokenData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Accept: application/json']);
$tokenResponse = curl_exec($ch);
curl_close($ch);

$tokenInfo = json_decode($tokenResponse, true);

if (!isset($tokenInfo['access_token'])) {
    header('Location: ../index.php?google_error=Failed to obtain access token');
    exit;
}

$accessToken = $tokenInfo['access_token'];

$userInfoUrl = 'https://www.googleapis.com/oauth2/v2/userinfo';
$ch = curl_init($userInfoUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $accessToken]);
$userResponse = curl_exec($ch);
curl_close($ch);

$googleUser = json_decode($userResponse, true);

if (!isset($googleUser['id'])) {
    header('Location: ../index.php?google_error=Failed to get user info');
    exit;
}

$googleId = $googleUser['id'];
$email = $googleUser['email'];
$name = $googleUser['name'];
$picture = $googleUser['picture'];

$stmt = $db->prepare('SELECT * FROM users WHERE google_id = :gid');
$stmt->bindValue(':gid', $googleId);
$user = $stmt->execute()->fetchArray(SQLITE3_ASSOC);

if ($user) {
    if ($user['is_permanent_ban']) {
        header('Location: ../index.php?google_error=Account permanently banned');
        exit;
    }
    if (!$user['is_active']) {
        header('Location: ../index.php?google_error=Account suspended');
        exit;
    }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['avatar_url'] = $user['avatar_url'] ?? '';
    $_SESSION['login_time'] = time();
    $_SESSION['mls_enabled'] = (int)($user['multi_layer_security'] ?? 0);

    $onboardedFlag = isset($user['onboarded']) ? (int)$user['onboarded'] : 0;
    if ($onboardedFlag === 0) {
        $_SESSION['show_onboarding'] = true;
    }

    if (empty($user['date_of_birth'])) {
        $_SESSION['needs_dob'] = true;
    }

    header('Location: ../index.php?google_login=success');
    exit;
}

$username = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', str_replace(' ', '_', $name)));
$username = substr($username, 0, 10);
$baseUsername = $username;
$counter = 1;

while (true) {
    $stmt = $db->prepare('SELECT id FROM users WHERE username = :u');
    $stmt->bindValue(':u', $username);
    $exists = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    if (!$exists) break;
    $username = $baseUsername . $counter;
    $counter++;
}

$stmt = $db->prepare('SELECT id FROM users WHERE email = :e');
$stmt->bindValue(':e', $email);
$emailExists = $stmt->execute()->fetchArray(SQLITE3_ASSOC);

if ($emailExists) {
    $stmt = $db->prepare('UPDATE users SET google_id = :gid WHERE id = :id');
    $stmt->bindValue(':gid', $googleId);
    $stmt->bindValue(':id', $emailExists['id']);
    $stmt->execute();

    $_SESSION['user_id'] = $emailExists['id'];
    $_SESSION['username'] = $db->querySingle('SELECT username FROM users WHERE id = ' . $emailExists['id']);
    $_SESSION['role'] = 'user';
    $_SESSION['avatar_url'] = '';
    $_SESSION['login_time'] = time();
    $_SESSION['mls_enabled'] = 0;
    $_SESSION['show_onboarding'] = true;
    $_SESSION['needs_dob'] = true;

    header('Location: ../index.php?google_login=success');
    exit;
}

$password = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT);

$stmt = $db->prepare('INSERT INTO users (username, email, password, google_id, avatar_url, is_verified) VALUES (:u, :e, :p, :g, :a, 1)');
$stmt->bindValue(':u', $username);
$stmt->bindValue(':e', $email);
$stmt->bindValue(':p', $password);
$stmt->bindValue(':g', $googleId);
$stmt->bindValue(':a', $picture);

try {
    $stmt->execute();
    $userId = $db->lastInsertRowID();

    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = 'user';
    $_SESSION['avatar_url'] = $picture;
    $_SESSION['login_time'] = time();
    $_SESSION['mls_enabled'] = 0;
    $_SESSION['show_onboarding'] = true;
    $_SESSION['needs_dob'] = true;

    header('Location: ../index.php?google_login=success');
    exit;
} catch (Exception $e) {
    header('Location: ../index.php?google_error=Registration failed');
    exit;
}
