<?php
session_start();
require __DIR__ . '/../includes/config.php';
require __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

$uid = (int)$_SESSION['user_id'];
$action = $_POST['action'] ?? '';

if ($action === 'account') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'message' => 'Invalid CSRF token']);
        exit;
    }
    
    $email = trim($_POST['email'] ?? '');
    $dob = (int)($_POST['date_of_birth'] ?? 0);
    $new_password = $_POST['new_password'] ?? '';
    
    if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $stmt = $db->prepare('UPDATE users SET email = :e WHERE id = :id');
        $stmt->bindValue(':e', $email);
        $stmt->bindValue(':id', $uid, SQLITE3_INTEGER);
        $stmt->execute();
    }
    
    if ($dob >= 1950 && $dob <= 2010) {
        $stmt = $db->prepare('UPDATE users SET date_of_birth = :d WHERE id = :id');
        $stmt->bindValue(':d', $dob);
        $stmt->bindValue(':id', $uid, SQLITE3_INTEGER);
        $stmt->execute();
    }
    
    if (!empty($new_password)) {
        $hash = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $db->prepare('UPDATE users SET password = :p WHERE id = :id');
        $stmt->bindValue(':p', $hash);
        $stmt->bindValue(':id', $uid, SQLITE3_INTEGER);
        $stmt->execute();
    }
    
    echo json_encode(['success' => true, 'message' => 'Account updated']);
    exit;
}

if ($action === 'mls') {
    $value = isset($_POST['value']) ? (int)$_POST['value'] : 0;
    $stmt = $db->prepare('UPDATE users SET multi_layer_security = :v WHERE id = :id');
    $stmt->bindValue(':v', $value);
    $stmt->bindValue(':id', $uid, SQLITE3_INTEGER);
    $stmt->execute();
    echo json_encode(['success' => true]);
    exit;
}

if ($action === 'spam') {
    $value = isset($_POST['value']) ? (int)$_POST['value'] : 0;
    $stmt = $db->prepare('UPDATE users SET spam_filter = :v WHERE id = :id');
    $stmt->bindValue(':v', $value);
    $stmt->bindValue(':id', $uid, SQLITE3_INTEGER);
    $stmt->execute();
    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid action']);
