<?php
require '../includes/config.php';

if (!isset($_SESSION['user_id'])) { echo json_encode(['status'=>'error','message'=>'login_required']); exit; }

$p_id = (int)($_GET['bookmark_post'] ?? 0);
$u_id = (int)$_SESSION['user_id'];
if (!$p_id) { echo json_encode(['status'=>'error']); exit; }

$exists = $db->querySingle("SELECT id FROM bookmarks WHERE post_id=$p_id AND user_id=$u_id");
if ($exists) {
    $db->exec("DELETE FROM bookmarks WHERE post_id=$p_id AND user_id=$u_id");
    $status = 'unbookmarked';
} else {
    $stmt = $db->prepare('INSERT INTO bookmarks (post_id, user_id) VALUES (:p,:u)');
    $stmt->bindValue(':p', $p_id, SQLITE3_INTEGER);
    $stmt->bindValue(':u', $u_id, SQLITE3_INTEGER);
    $stmt->execute();
    $status = 'bookmarked';
}
echo json_encode(['status'=>$status]);
