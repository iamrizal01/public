<?php
require '../includes/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'login_required']);
    exit;
}

$uid = (int)$_SESSION['user_id'];
$with_username = $_GET['with'] ?? '';

if (empty($with_username)) {
    echo json_encode(['status' => 'error', 'message' => 'missing_username']);
    exit;
}

$stmt = $db->prepare('SELECT id FROM users WHERE username = :u');
$stmt->bindValue(':u', $with_username);
$partner = $stmt->execute()->fetchArray(SQLITE3_ASSOC);

if (!$partner) {
    echo json_encode(['status' => 'error', 'message' => 'user_not_found']);
    exit;
}

$wid = (int)$partner['id'];
$after_id = (int)($_GET['after_id'] ?? 0);

$query = "SELECT m.*, u.username as sender_name 
          FROM messages m 
          JOIN users u ON m.sender_id = u.id 
          WHERE ((sender_id = $uid AND receiver_id = $wid) OR (sender_id = $wid AND receiver_id = $uid))
          AND m.deleted_for != $uid";

if ($after_id > 0) {
    $query .= " AND m.id > $after_id";
}

$query .= " ORDER BY m.created_at ASC";

$messages = $db->query($query);
$data = [];

while ($msg = $messages->fetchArray(SQLITE3_ASSOC)) {
    // Mark as shown if it's a new incoming message
    if ($msg['receiver_id'] == $uid && $msg['is_shown'] == 0) {
        $db->exec("UPDATE messages SET is_shown = 1, is_read = 1 WHERE id = " . (int)$msg['id']);
    }
    $data[] = $msg;
}

echo json_encode(['status' => 'success', 'messages' => $data]);
