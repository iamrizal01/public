<?php
require '../includes/config.php';
require '../includes/functions.php';

$referer = $_SERVER['HTTP_REFERER'] ?? '../index.php';

if (!isset($_SESSION['user_id'])) { header('Location: ' . $referer); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_comment'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        die('Invalid CSRF token');
    }
    $post_id   = (int)$_POST['post_id'];
    $parent_id = (!empty($_POST['parent_id']) && is_numeric($_POST['parent_id'])) ? (int)$_POST['parent_id'] : null;
    $censored  = censorMessage($_POST['comment_content'] ?? '');

    if ($post_id > 0 && trim($censored['text']) !== '') {
        try {
            $stmt = $db->prepare('INSERT INTO comments (post_id, user_id, parent_id, content) VALUES (:p,:u,:par,:c)');
            $stmt->bindValue(':p', $post_id, SQLITE3_INTEGER);
            $stmt->bindValue(':u', (int)$_SESSION['user_id'], SQLITE3_INTEGER);
            $stmt->bindValue(':par', $parent_id, $parent_id === null ? SQLITE3_NULL : SQLITE3_INTEGER);
            $stmt->bindValue(':c', $censored['text']);
            if (!$stmt->execute()) {
                throw new Exception("Comment Insert Failed: " . $db->lastErrorMsg());
            }

            // Notify post owner
            $owner_id = (int)$db->querySingle("SELECT user_id FROM posts WHERE id=$post_id");
            if ($owner_id && $owner_id !== (int)$_SESSION['user_id']) {
                sendNotification($db, $owner_id, (int)$_SESSION['user_id'], 'comment',
                    "@{$_SESSION['username']} commented on your post.",
                    "../post/?id=$post_id"
                );
            }
        } catch (Exception $e) {
            error_log("Comment Create Error: " . $e->getMessage());
        }
    }

    $flag = $censored['violation'] ? '&warned_comment=1' : '';
    // Redirect back to referer with anchor
    $sep  = strpos($referer, '?') !== false ? '&' : '?';
    header("Location: {$referer}{$sep}post_anchor={$post_id}{$flag}#post-{$post_id}");
    exit;
}

header('Location: ' . $referer);
