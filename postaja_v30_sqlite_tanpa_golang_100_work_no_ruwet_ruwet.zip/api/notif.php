<?php
require '../includes/config.php';

if (!isset($_SESSION['user_id'])) { echo json_encode(null); exit; }

$uid  = (int)$_SESSION['user_id'];
$stmt = $db->prepare('SELECT id, type, message, link FROM notifications WHERE user_id=:u AND is_shown=0 ORDER BY created_at DESC LIMIT 1');
$stmt->bindValue(':u', $uid, SQLITE3_INTEGER);
$notif = $stmt->execute()->fetchArray(SQLITE3_ASSOC);

if ($notif) {
    $db->exec("UPDATE notifications SET is_shown=1 WHERE id=" . (int)$notif['id']);
    echo json_encode($notif);
} else {
    echo json_encode(null);
}
