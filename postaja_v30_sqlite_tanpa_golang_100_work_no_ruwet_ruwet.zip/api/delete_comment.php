<?php
require '../includes/config.php';
require '../includes/functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'login_required']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['comment_id'])) {
    $comment_id = isset($_GET['comment_id']) ? (int)$_GET['comment_id'] : (int)($_POST['comment_id'] ?? 0);
    
    if ($comment_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'invalid_id']);
        exit;
    }
    
    $stmt = $db->prepare('SELECT user_id FROM comments WHERE id = :id');
    $stmt->bindValue(':id', $comment_id, SQLITE3_INTEGER);
    $result = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    
    if (!$result) {
        echo json_encode(['status' => 'error', 'message' => 'not_found']);
        exit;
    }
    
    $is_owner = (int)$result['user_id'] === (int)$_SESSION['user_id'];
    $is_admin = in_array($_SESSION['role'] ?? '', ['admin', 'superadmin']);
    
    if (!$is_owner && !$is_admin) {
        echo json_encode(['status' => 'error', 'message' => 'forbidden']);
        exit;
    }
    
    $delete_replies = $db->prepare('DELETE FROM comments WHERE parent_id = :id');
    $delete_replies->bindValue(':id', $comment_id, SQLITE3_INTEGER);
    $delete_replies->execute();
    
    $delete_comment = $db->prepare('DELETE FROM comments WHERE id = :id');
    $delete_comment->bindValue(':id', $comment_id, SQLITE3_INTEGER);
    $delete_comment->execute();
    
    echo json_encode(['status' => 'deleted']);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'invalid_request']);
