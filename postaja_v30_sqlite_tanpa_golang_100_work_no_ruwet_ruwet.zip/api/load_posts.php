<?php
require '../includes/config.php';
require '../includes/functions.php';

$root_path = '';
$offset    = max(0, (int)($_GET['offset'] ?? 0));

$categoryKeywords = [
    'teknologi' => ['teknologi','web','server','arduino','ram','cpu','amd','nvidia','intel','programming','coding','software','hardware','app','internet','digital','ai','android','ios','laptop','smartphone','game','gaming','cybersecurity','hacking','tech'],
    'bola' => ['bola','messi','mencetak goal','piala dunia','fc barcelona','real madrid','manchester united','ronaldo','sepakbola','football','liga','champions','premier league','la liga','seri a','UEFA','stadion','pertandingan','gol','score','juara'],
    'musik' => ['musik','lagu','album','artis','singer','song','concert','konser','spotify','streaming','music','band','musician','vocal','gitar','drum','piano','pop','rock','jazz','dangdut','k-pop','hip hop','rap','melody',' chords','lyrics'],
    'film' => ['film','movie','bioskop','cinema','netflix','sinema','aktor','actress','series','drama','horror','komedi','action','thriller','animasi','anime','documentary','trailer','box office','oscars','golden globe','hollywood','bollywood','film baru'],
    'otomotif' => ['otomotif','mobil','motor','mobil','sepedamotor','vehicle','car','motorcycle','modifikasi','racing','balap','d之手','yamaha','honda','toyota','suzuki','kawasaki','ducati','bmw','mercedes','ferrari','lamborghini','supercar','offroad',' Touring','moto gp','formula 1','f1'],
    'food' => ['food','makan','kuliner','restaurant','cafe','daging','sapi','ayam','mie','nasi','goreng','soto','bakso','pizza','burger','sushi','ramen','kopi','coffee','tea','minuman','dessert','cake','ice cream','foodie','chef','masak','resep','kuliner','enak','lezat','gurih'],
    'travel' => ['travel','liburan','tour','pariwisat a','hotel','flight','penerbangan','pesawat','destinasi','beach','pantai','gunung','island','pulau','backpack','hostel','airbnb','tourist','vacation','trip','itinerary','guide','adventure','expedition','cruise','resort','villa','honeymoon','backpacking','solo travel'],
    'fashion' => ['fashion','clothing','clothes','dress','baju','fashion','style','model','ootd','brand','boutique','designer','trend','jacket','jeans','shoes','sepatu','tas','bag','accessories','makeup','kosmetik','skincare','perfume','parfum','beauty','grooming','hairstyle','hairdo','tatoo','piercing'],
    'sports' => ['sports','olimpiade','olympic','basket','volley','tennis','badminton','pingpong','golf','boxing','tinju','wrestling','gym','fitness','workout','training','athlete','sport','turnamen','championship','medal','gold','silver','bronze','world cup','kejuaraan','lomba','kompetisi'],
    'business' => ['business','bisnis','entrepreneur','startup','uang','money','invest','investment','saham','stock','crypto','bitcoin','trading','ekonomi','economy','market','finance','bank','kartu','kredit','inflation','gdp','entrepreneurship','success','profit','revenue','company','corporate','brand','marketing','sales','advertising','SEO'],
    'health' => ['health','kesehatan','medicine','obat','doctor','dokter','rumah sakit','hospital','clinic','diagnosis','treatment','therapy','yoga','meditation','wellness','healthy','diet','nutrisi','vitamin','supplement','sleep','mental','psikologi','stress','anxiety','depression','fitness','body','weight','fat','muscle'],
    'education' => ['education','sekolah','kampus','university','college','school','belajar','kuliah','siswa','mahasiswa','guru','dosen','teacher','lecture','exam','ujian','tugas','assignment','skripsi','thesis','research','study','learning','course','online','tutorial','book','buku','library','academic','ilmu','sains','science','math','biology','physics','chemistry','sejarah','history','geography','language','bahasa','foreign language','learn','teach','pendidikan'],
    'photography' => ['photography','foto','kamera','camera','photographer','lens','dslr','mirrorless','canon','nikon','sony','fujifilm','photo','portrait','landscape','street','wildlife','macro','editing','lightroom','photoshop','instagram','snapshot','shoot','sesi','model','potrait','exposure','aperture','shutter','iso','visual','art','creative'],
    'gaming' => ['gaming','game','games','playstation','ps5','xbox','nintendo','switch','steam','pc gaming','mobile game','esports','tournament','pro gamer','fps','rpg','moba','battle royale','valorant','fortnite','minecraft','genshin','league of legends','lol','dota','csgo','call of duty','gamer','controller','keyboard mouse','streaming','twitch','speedrun','completion','achievement','rank','ranked',' competitivo','competitive','guild','clan','team','patch','update','dlc','expansion','story','campaign','singleplayer','multiplayer','co-op','online','offline','arcade','retro','pixel art','indie game','aaa','aagamer','fps','rts','strategy','simulator','sandbox','open world','shooter','puzzle','platformer','horror game','survival','roguelike','metroidvania']
];

function getCategoryKeywords(string $favorite): array {
    global $categoryKeywords;
    $favLower = strtolower(trim($favorite));
    if (isset($categoryKeywords[$favLower])) {
        return $categoryKeywords[$favLower];
    }
    foreach ($categoryKeywords as $cat => $keywords) {
        if (stripos($favLower, $cat) !== false) {
            return $keywords;
        }
    }
    return [];
}

// Simplify to global feed logic to match initial load in index.php
$order_by = 'posts.created_at DESC';

$sql = "SELECT posts.*, users.username, users.role, users.avatar_url, users.is_premium 
        FROM posts 
        JOIN users ON posts.user_id=users.id 
        ORDER BY $order_by 
        LIMIT :l OFFSET :o";

$stmt = $db->prepare($sql);
$stmt->bindValue(':l', POSTS_PER_PAGE, SQLITE3_INTEGER);
$stmt->bindValue(':o', $offset, SQLITE3_INTEGER);

$res = $stmt->execute();
$html = '';
while ($p = $res->fetchArray(SQLITE3_ASSOC)) { $html .= renderPostHtml($p, $db); }
echo json_encode(['html' => $html]);
