<?php
require '../includes/config.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');
echo json_encode(['maintenance' => shouldShowMaintenance($db)]);
