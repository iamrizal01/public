<?php
session_start();
require_once '../includes/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$dob = $_POST['dob'] ?? '';
if (empty($dob)) {
    echo json_encode(['status' => 'error', 'message' => 'Date of birth required']);
    exit;
}

$stmt = $db->prepare('UPDATE users SET date_of_birth = :d WHERE id = :u');
$stmt->bindValue(':d', $dob);
$stmt->bindValue(':u', $_SESSION['user_id'], SQLITE3_INTEGER);

if ($stmt->execute()) {
    echo json_encode(['status' => 'ok']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to update']);
}
