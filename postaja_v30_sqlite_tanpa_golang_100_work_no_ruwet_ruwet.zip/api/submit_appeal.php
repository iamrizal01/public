<?php
require '../includes/config.php';
require '../includes/functions.php';

$referer = $_SERVER['HTTP_REFERER'] ?? '../index.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . $referer);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        die('Invalid CSRF token');
    }
    
    $reason = trim($_POST['appeal_reason'] ?? '');
    
    if (empty($reason)) {
        header('Location: ' . $referer . '?error=empty_appeal');
        exit;
    }
    
    $user_id = (int)$_SESSION['user_id'];
    
    $user = $db->querySingle("SELECT is_active FROM users WHERE id = $user_id");
    if ($user) {
        $existing = $db->querySingle("SELECT id FROM appeals WHERE user_id = $user_id AND status = 'pending'");
        if ($existing) {
            header('Location: ' . $referer . '?error=appeal_exists');
            exit;
        }
        
        submitAppeal($db, $user_id, $reason);
        
        if (stripos($reason, 'tolong') !== false) {
            header('Location: ' . $referer . '?success=appeal_auto_approved');
        } else {
            header('Location: ' . $referer . '?success=appeal_submitted');
        }
        exit;
    }
    
    header('Location: ' . $referer);
    exit;
}

header('Location: ' . $referer);
