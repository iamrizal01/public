<?php
require '../includes/config.php';
require '../includes/functions.php';

if (!isset($_SESSION['user_id'])) { echo json_encode(['status'=>'error','message'=>'login_required']); exit; }

$following_id = (int)($_GET['follow_user'] ?? 0);
$follower_id  = (int)$_SESSION['user_id'];
if (!$following_id || $following_id === $follower_id) { echo json_encode(['status'=>'error']); exit; }

$exists = $db->querySingle("SELECT id FROM follows WHERE follower_id=$follower_id AND following_id=$following_id");
if ($exists) {
    $db->exec("DELETE FROM follows WHERE follower_id=$follower_id AND following_id=$following_id");
    $status = 'unfollowed';
} else {
    $stmt = $db->prepare('INSERT INTO follows (follower_id, following_id) VALUES (:fer,:fing)');
    $stmt->bindValue(':fer', $follower_id, SQLITE3_INTEGER);
    $stmt->bindValue(':fing', $following_id, SQLITE3_INTEGER);
    $stmt->execute();
    sendNotification($db, $following_id, $follower_id, 'follow', "@{$_SESSION['username']} mulai mengikuti Anda!", "../profile/?u={$_SESSION['username']}");
    $status = 'followed';
}

echo json_encode(['status'=>$status]);
