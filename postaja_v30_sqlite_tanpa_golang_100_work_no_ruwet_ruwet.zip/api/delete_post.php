<?php
require '../includes/config.php';

if (!isset($_SESSION['user_id'])) { echo json_encode(['status'=>'error']); exit; }

$post_id = (int)($_GET['post_id'] ?? 0);
if (!$post_id) { echo json_encode(['status'=>'error']); exit; }

$post_user_id = $db->querySingle("SELECT user_id FROM posts WHERE id=$post_id");
$role = $_SESSION['role'] ?? 'user';

$can_delete = ($post_user_id !== false && $post_user_id == $_SESSION['user_id']) ||
              in_array($role, ['admin','superadmin']);

if (!$can_delete) { echo json_encode(['status'=>'forbidden']); exit; }

$db->exec("DELETE FROM posts WHERE id=$post_id");
$db->exec("DELETE FROM comments WHERE post_id=$post_id");
$db->exec("DELETE FROM likes WHERE post_id=$post_id");
$db->exec("DELETE FROM bookmarks WHERE post_id=$post_id");
$db->exec("DELETE FROM reposts WHERE post_id=$post_id");

echo json_encode(['status'=>'deleted']);
