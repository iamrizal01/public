<?php
require '../includes/config.php';
require '../includes/functions.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'login_required']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        echo json_encode(['status' => 'error', 'message' => 'invalid_csrf']);
        exit;
    }

    $post_id = (int)($_POST['post_id'] ?? 0);
    $reason = trim($_POST['reason'] ?? '');
    $user_id = (int)$_SESSION['user_id'];

    if ($post_id <= 0 || empty($reason)) {
        echo json_encode(['status' => 'error', 'message' => 'missing_fields']);
        exit;
    }

    $stmt = $db->prepare('INSERT INTO reports (post_id, user_id, reason) VALUES (:p, :u, :r)');
    $stmt->bindValue(':p', $post_id, SQLITE3_INTEGER);
    $stmt->bindValue(':u', $user_id, SQLITE3_INTEGER);
    $stmt->bindValue(':r', $reason);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Post reported successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to submit report.']);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'invalid_request']);
