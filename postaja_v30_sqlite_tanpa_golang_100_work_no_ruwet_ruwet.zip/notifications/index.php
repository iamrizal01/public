<?php
$root_path   = '../';
$api_path    = '../api/';
$home_url    = '../index.php';
$current_page = 'notifications';
$page_title  = 'Notifications';

require '../includes/config.php';
require '../includes/functions.php';
require '../includes/auth_handler.php';

// Guard: harus login
if (empty($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$uid = (int)$_SESSION['user_id'];

// ── Mark all as read ──────────────────────────────────────────────────────────
$db->exec("UPDATE notifications SET is_read = 1 WHERE user_id = $uid");

if (isset($_GET['mark_all'])) {
    $stmt = $db->prepare('UPDATE notifications SET is_read = 1 WHERE user_id = :uid');
    if ($stmt) {
        $stmt->bindValue(':uid', $uid, SQLITE3_INTEGER);
        $stmt->execute();
    }
    header('Location: index.php');
    exit;
}

// ── Fetch notifications (PREPARED — aman dari SQL injection) ──────────────────
$stmt = $db->prepare("
    SELECT n.*, u.username AS from_username, u.avatar_url AS from_avatar
    FROM notifications n
    LEFT JOIN users u ON n.from_user_id = u.id
    WHERE n.user_id = :uid
    ORDER BY n.created_at DESC
    LIMIT 50
");

if (!$stmt) {
    // Jika prepare gagal, set notifs = null agar bisa ditangani di bawah
    $notifs = null;
} else {
    $stmt->bindValue(':uid', $uid, SQLITE3_INTEGER);
    $notifs = $stmt->execute(); // SQLite3Result
}

// ── Helper: icon & warna per tipe (PHP 7 friendly) ──────────────────────────
function notifIcon($type) {
    switch ($type) {
        case 'like':
            return ['bi-heart-fill', '#e74c3c'];
        case 'follow':
            return ['bi-person-plus-fill', '#2ecc71'];
        case 'comment':
            return ['bi-chat-fill', '#3498db'];
        case 'repost':
            return ['bi-repeat', '#27ae60'];
        case 'dm':
            return ['bi-envelope-fill', '#f39c12'];
        default:
            return ['bi-bell-fill', '#95a5a6'];
    }
}

require '../includes/header.php';
?>

<!-- ── Styles ──────────────────────────────────────────────────────────────── -->
<style>
  .notif-header        { display:flex; align-items:center; justify-content:space-between;
                         padding: 1rem 1.25rem; border-bottom: 1px solid #e9ecef;
                         position: sticky; top: 0; background: #fff; z-index: 10; }
  .notif-header h5     { font-weight: 700; margin: 0; font-size: 1rem; }

  .notif-item          { display: flex; gap: .85rem; align-items: flex-start;
                         padding: .9rem 1.25rem;
                         border-bottom: 1px solid #f0f0f0;
                         transition: background .15s; position: relative; }
  .notif-item:hover    { background: #f8f9fa; }
  .notif-item.unread   { background: #f0f7ff; }
  .notif-item.unread:hover { background: #e5f0fc; }

  .unread-dot          { position: absolute; left: .45rem; top: 50%;
                         transform: translateY(-50%);
                         width: 7px; height: 7px; border-radius: 50%;
                         background: #0d6efd; flex-shrink: 0; }

  .notif-avatar        { flex-shrink: 0; position: relative; }
  .notif-icon-badge    { position: absolute; bottom: -3px; right: -3px;
                         width: 18px; height: 18px; border-radius: 50%;
                         display: flex; align-items:center; justify-content:center;
                         border: 2px solid #fff; font-size: .55rem; }

  .notif-body          { flex: 1; min-width: 0; }
  .notif-msg           { font-size: .875rem; color: #212529; margin-bottom: .2rem;
                         word-break: break-word; }
  .notif-meta          { font-size: .75rem; color: #6c757d; }
  .notif-link          { font-size: .78rem; color: #0d6efd; text-decoration: none;
                         margin-top: .2rem; display: inline-block; }
  .notif-link:hover    { text-decoration: underline; }

  .notif-empty         { padding: 4rem 1rem; text-align: center; color: #adb5bd; }
  .notif-empty i       { font-size: 3rem; margin-bottom: 1rem; display: block; }

  .btn-mark-read       { font-size: .8rem; padding: .3rem .8rem;
                         border-radius: 20px; white-space: nowrap; }

  @media (max-width: 576px) {
    .notif-header       { padding: .75rem 1rem; }
    .notif-item         { padding: .75rem 1rem; }
  }
</style>

<!-- ── Markup ─────────────────────────────────────────────────────────────── -->
  <div class="notif-header">
    <h5>🔔 Notifikasi</h5>
    <a href="?mark_all=1" class="btn btn-outline-secondary btn-sm btn-mark-read">
      Tandai semua dibaca
    </a>
  </div>

  <?php if (!$notifs): ?>
    <!-- DB error -->
    <div class="notif-empty">
      <i class="bi bi-exclamation-circle text-danger"></i>
      <p class="text-danger">Gagal memuat notifikasi. Silakan coba lagi.</p>
    </div>

  <?php else: ?>
    <?php
    $any = false;
    while ($n = $notifs->fetchArray(SQLITE3_ASSOC)):
        $any  = true;
        $type = $n['type'] ?? 'info';
        [$iconClass, $iconColor] = notifIcon($type);
        $isUnread = !(bool)$n['is_read'];
    ?>

    <div class="notif-item <?= $isUnread ? 'unread' : '' ?>">

      <?php if ($isUnread): ?>
        <div class="unread-dot"></div>
      <?php endif; ?>

      <!-- Avatar -->
      <div class="notif-avatar">
        <?php if (!empty($n['from_username'])): ?>
          <a href="../profile/?u=<?= urlencode($n['from_username']) ?>">
            <?= getAvatarHtml($n['from_username'], $n['from_avatar'] ?? '', 40) ?>
          </a>
        <?php else: ?>
          <div style="width:40px;height:40px;border-radius:50%;
                      background:#e9ecef;display:flex;align-items:center;
                      justify-content:center;color:<?= $iconColor ?>;">
            <i class="bi <?= $iconClass ?>" style="font-size:.95rem;"></i>
          </div>
        <?php endif; ?>

        <!-- Badge ikon kecil di pojok avatar -->
        <span class="notif-icon-badge" style="background:<?= $iconColor ?>;">
          <i class="bi <?= $iconClass ?> text-white"></i>
        </span>
      </div>

      <!-- Body -->
      <div class="notif-body">
        <div class="notif-msg"><?= htmlspecialchars($n['message'] ?? '') ?></div>
        <div class="notif-meta">
          <?php
            $ts = strtotime($n['created_at'] ?? '');
            echo $ts ? date('d M Y, H:i', $ts) : '—';
          ?>
        </div>
        <?php if (!empty($n['link'])): ?>
          <a href="<?= htmlspecialchars($n['link']) ?>" class="notif-link">Lihat →</a>
        <?php endif; ?>
      </div>

    </div>
    <?php endwhile; ?>

    <?php if (!$any): ?>
      <div class="notif-empty">
        <i class="bi bi-bell opacity-25"></i>
        <p>Belum ada notifikasi.</p>
      </div>
    <?php endif; ?>

  <?php endif; ?>

<?php require '../includes/footer.php'; ?>