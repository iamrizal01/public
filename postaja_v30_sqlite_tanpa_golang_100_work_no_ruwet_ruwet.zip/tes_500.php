<?php
require 'includes/config.php';

// Panggil fungsi fiktif biar PHP meledak (Fatal Error)
fungsi_ini_nggak_pernah_ada(); 
?>
