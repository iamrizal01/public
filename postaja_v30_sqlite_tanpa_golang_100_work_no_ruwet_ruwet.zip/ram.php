#!/usr/bin/env php
<?php
/**
 * RAM Burst Test & DDR5 Speed Checker (CL30)
 * Direct CLI execution - No HTML required
 * Test actual host performance
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Color output untuk CLI
class Colors {
    const GREEN = "\033[92m";
    const RED = "\033[91m";
    const YELLOW = "\033[93m";
    const BLUE = "\033[94m";
    const CYAN = "\033[36m";
    const RESET = "\033[0m";
    const BOLD = "\033[1m";
}

function printHeader($text) {
    echo Colors::BOLD . Colors::CYAN . "\n=== " . $text . " ===\n" . Colors::RESET;
}

function printSuccess($text) {
    echo Colors::GREEN . "✓ " . $text . Colors::RESET . "\n";
}

function printError($text) {
    echo Colors::RED . "✗ " . $text . Colors::RESET . "\n";
}

function printWarning($text) {
    echo Colors::YELLOW . "⚠ " . $text . Colors::RESET . "\n";
}

function printInfo($text) {
    echo Colors::BLUE . "ℹ " . $text . Colors::RESET . "\n";
}

// ============= SYSTEM INFO =============
printHeader("SYSTEM INFORMATION");

echo "PHP Version: " . Colors::BOLD . phpversion() . Colors::RESET . "\n";
echo "OS: " . php_uname() . "\n";
echo "Memory Limit: " . Colors::BOLD . ini_get('memory_limit') . Colors::RESET . "\n";

// Get CPU info
$cpu_info = @file_get_contents('/proc/cpuinfo');
if ($cpu_info) {
    preg_match('/model name\s*:\s*(.+?)$/m', $cpu_info, $matches);
    if (isset($matches[1])) {
        echo "CPU: " . Colors::BOLD . trim($matches[1]) . Colors::RESET . "\n";
    }
}

// ============= MEMORY TEST =============
printHeader("RAM BURST TEST");

$test_sizes = [1024 * 1024, 5 * 1024 * 1024, 10 * 1024 * 1024, 50 * 1024 * 1024]; // 1MB to 50MB
$burst_results = [];

foreach ($test_sizes as $size) {
    $start_time = microtime(true);
    $start_memory = memory_get_usage(true);
    
    // Burst write test
    $data = str_repeat('X', $size);
    
    $write_time = (microtime(true) - $start_time) * 1000;
    $memory_used = memory_get_usage(true) - $start_memory;
    
    $burst_speed = ($size / 1024 / 1024) / ($write_time / 1000); // MB/s
    
    $size_mb = $size / 1024 / 1024;
    echo sprintf(
        "Write %3.0fMB: %7.2f MB/s | Time: %7.3fms | Memory: %8.2f MB\n",
        $size_mb,
        $burst_speed,
        $write_time,
        $memory_used / 1024 / 1024
    );
    
    $burst_results[] = [
        'size' => $size_mb,
        'speed' => $burst_speed,
        'time' => $write_time
    ];
    
    unset($data);
}

// ============= SEQUENTIAL ACCESS TEST =============
printHeader("SEQUENTIAL ACCESS TEST");

$test_count = 10000000;
$array = array_fill(0, 10000, 0);

// Read test
$start_time = microtime(true);
for ($i = 0; $i < $test_count; $i++) {
    $val = $array[$i % count($array)];
}
$read_time = microtime(true) - $start_time;
$read_ops_per_sec = $test_count / $read_time;

echo "Read Operations: " . Colors::BOLD . number_format($read_ops_per_sec) . Colors::RESET . " ops/sec\n";
echo "Total Time: " . sprintf("%.4f seconds\n", $read_time);

// ============= DDR5 CL30 LATENCY CHECK =============
printHeader("DDR5 CL30 LATENCY ANALYSIS");

// Measure actual latency dengan precise timing
$iterations = 1000000;
$latency_samples = [];

for ($i = 0; $i < 100; $i++) {
    $arr = array_fill(0, 1000, rand());
    
    $start = microtime(true);
    for ($j = 0; $j < $iterations; $j++) {
        $idx = ($j * 13) % 1000; // Random-ish access pattern
        $val = $arr[$idx];
    }
    $end = microtime(true);
    
    $time_ns = ($end - $start) * 1e9;
    $latency_ns = $time_ns / $iterations;
    $latency_samples[] = $latency_ns;
    
    unset($arr);
}

sort($latency_samples);
$avg_latency = array_sum($latency_samples) / count($latency_samples);
$min_latency = min($latency_samples);
$max_latency = max($latency_samples);
$median_latency = $latency_samples[count($latency_samples) / 2];

// DDR5-6000 CL30 reference: ~10ns per cycle, CL30 = 30 cycles = 300ns (theoretical)
$reference_cl30 = 300;

echo "Average Latency: " . Colors::BOLD . sprintf("%.2f ns", $avg_latency) . Colors::RESET . "\n";
echo "Min Latency: " . sprintf("%.2f ns\n", $min_latency);
echo "Max Latency: " . sprintf("%.2f ns\n", $max_latency);
echo "Median Latency: " . sprintf("%.2f ns\n", $median_latency);
echo "Reference CL30 (DDR5-6000): " . sprintf("%.0f ns\n", $reference_cl30);

$latency_ratio = $avg_latency / $reference_cl30;
if ($latency_ratio < 1.5) {
    printSuccess("Latency EXCELLENT - Close to CL30 specifications");
} elseif ($latency_ratio < 2.5) {
    printSuccess("Latency GOOD - Acceptable for CL30");
} elseif ($latency_ratio < 4.0) {
    printWarning("Latency MODERATE - Higher than expected for CL30");
} else {
    printError("Latency HIGH - Well above CL30 specifications (likely virtualized or throttled)");
}

echo "Latency Ratio: " . sprintf("%.2fx reference\n", $latency_ratio);

// ============= BANDWIDTH SIMULATION =============
printHeader("BANDWIDTH SIMULATION");

$chunk_size = 64; // Simulate 64-byte cache line
$total_size = 100 * 1024 * 1024; // 100MB test
$iterations = $total_size / $chunk_size;

$start_time = microtime(true);
$buffer = str_repeat('0', $chunk_size);
for ($i = 0; $i < $iterations; $i++) {
    $buffer = hash('sha256', $buffer, true);
}
$elapsed = microtime(true) - $start_time;

$bandwidth = ($total_size / 1024 / 1024) / $elapsed;
echo "Simulated Bandwidth: " . Colors::BOLD . sprintf("%.2f MB/s", $bandwidth) . Colors::RESET . "\n";

// DDR5 reference bandwidth
$ddr5_ref = 38400; // DDR5-6000 = 48GB/s, but PHP overhead
if ($bandwidth > 1000) {
    printSuccess("Bandwidth EXCELLENT for PHP");
} elseif ($bandwidth > 500) {
    printSuccess("Bandwidth GOOD");
} else {
    printWarning("Bandwidth LIMITED - Check system load");
}

// ============= CACHE EFFICIENCY =============
printHeader("CACHE EFFICIENCY TEST");

$sizes = [1024, 10 * 1024, 100 * 1024, 1024 * 1024, 10 * 1024 * 1024];
$size_names = ['1KB', '10KB', '100KB', '1MB', '10MB'];

foreach ($sizes as $idx => $size) {
    $arr = array_fill(0, $size / 8, 0);
    $iterations = 10000000;
    
    $start = microtime(true);
    for ($i = 0; $i < $iterations; $i++) {
        $arr[$i % count($arr)]++;
    }
    $time = microtime(true) - $start;
    
    $ops_per_sec = $iterations / $time;
    printf("%-7s: %12s ops/sec\n", $size_names[$idx], number_format($ops_per_sec));
    
    unset($arr);
}

// ============= FINAL REPORT =============
printHeader("PERFORMANCE SUMMARY");

$avg_burst = array_sum(array_column($burst_results, 'speed')) / count($burst_results);

echo "Average Burst Speed: " . Colors::BOLD . sprintf("%.2f MB/s", $avg_burst) . Colors::RESET . "\n";
echo "Average Latency: " . Colors::BOLD . sprintf("%.2f ns", $avg_latency) . Colors::RESET . "\n";
echo "Bandwidth: " . Colors::BOLD . sprintf("%.2f MB/s", $bandwidth) . Colors::RESET . "\n";

// Verdict
echo "\n" . Colors::BOLD . Colors::BLUE . "=== VERDICT ===" . Colors::RESET . "\n";

if ($latency_ratio < 2.5 && $bandwidth > 500) {
    printSuccess("HOST RAM PERFORMANCE: OPTIMAL for CL30");
} elseif ($latency_ratio < 4.0 && $bandwidth > 300) {
    printSuccess("HOST RAM PERFORMANCE: ACCEPTABLE");
} else {
    printError("HOST RAM PERFORMANCE: DEGRADED (Check latency high warning above)");
}

// System recommendations
echo "\n" . Colors::BOLD . "Recommendations:" . Colors::RESET . "\n";
if ($latency_ratio > 3.0) {
    printWarning("High latency detected - Consider:");
    echo "  • Check for system load/virtualization overhead\n";
    echo "  • Verify DDR5 BIOS settings (enable XMP/DOCP)\n";
    echo "  • Confirm CAS Latency in BIOS is set to CL30\n";
} else {
    printSuccess("Latency within acceptable range");
}

if ($bandwidth < 500) {
    printWarning("Low bandwidth detected");
    echo "  • Check system memory is not oversubscribed\n";
} else {
    printSuccess("Bandwidth is good");
}

echo "\n";
?>