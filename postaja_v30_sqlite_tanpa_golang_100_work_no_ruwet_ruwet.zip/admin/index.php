<?php
$root_path = '../'; $api_path = '../api/'; $home_url = '../index.php';
$current_page = 'admin'; $page_title = 'Admin Panel';
require '../includes/config.php';
require '../includes/functions.php';
require '../includes/auth_handler.php';

if (!isAdmin()) { header('Location: ../index.php'); exit; }

$msg = '';

// Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        $msg = 'Invalid CSRF token. Please refresh the page.';
    } elseif (isset($_POST['toggle_user'])) {
        $target_id = (int)$_POST['target_id'];
        if ($target_id !== (int)$_SESSION['user_id']) {
            $cur = (int)$db->querySingle("SELECT is_active FROM users WHERE id=$target_id");
            $db->exec("UPDATE users SET is_active=".($cur?0:1)." WHERE id=$target_id");
            $msg = $cur ? 'User suspended.' : 'User activated.';
        }
    }
    if (isset($_POST['change_role'])) {
        $target_id = (int)$_POST['target_id'];
        $new_role = in_array($_POST['new_role'], ['user','admin']) ? $_POST['new_role'] : 'user';
        $target = $db->querySingle("SELECT username, role FROM users WHERE id=$target_id", true);
        
        if ($target && !in_array($target['username'], ['silo','rizal']) && $target['role'] !== 'superadmin') {
            // Only superadmin can promote/demote admins
            if (isSuperAdmin() || ($target['role'] !== 'admin' && $new_role !== 'admin')) {
                $db->exec("UPDATE users SET role='$new_role' WHERE id=$target_id");
                $msg = 'Role updated.';
            } else {
                $msg = 'Only super admin can manage admin roles.';
            }
        } else {
            $msg = 'Cannot change super admin role.';
        }
    }
    if (isset($_POST['delete_post_admin'])) {
        $post_id = (int)$_POST['post_id'];
        $db->exec("DELETE FROM posts WHERE id=$post_id");
        $db->exec("DELETE FROM comments WHERE post_id=$post_id");
        $db->exec("DELETE FROM likes WHERE post_id=$post_id");
        $db->exec("DELETE FROM bookmarks WHERE post_id=$post_id");
        $db->exec("DELETE FROM reposts WHERE post_id=$post_id");
        $msg = 'Post dihapus.';
    }
    if (isset($_POST['delete_user'])) {
        $target_id = (int)$_POST['target_id'];
        $target = $db->querySingle("SELECT username, role FROM users WHERE id=$target_id", true);
        if ($target && !in_array($target['username'], ['silo','rizal']) && $target['role'] !== 'superadmin' && $target_id !== (int)$_SESSION['user_id']) {
            // Only superadmin can delete admins
            if (isSuperAdmin() || $target['role'] !== 'admin') {
                $db->exec("DELETE FROM users WHERE id=$target_id");
                $db->exec("DELETE FROM posts WHERE user_id=$target_id");
                $db->exec("DELETE FROM comments WHERE user_id=$target_id");
                $db->exec("DELETE FROM likes WHERE user_id=$target_id");
                $db->exec("DELETE FROM follows WHERE follower_id=$target_id OR following_id=$target_id");
                $db->exec("DELETE FROM messages WHERE sender_id=$target_id OR receiver_id=$target_id");
                $msg = 'User dihapus.';
            } else {
                $msg = 'Only super admin can delete admin accounts.';
            }
        }
    }
    if (isset($_POST['toggle_premium']) && isSuperAdmin()) {
        $target_id = (int)$_POST['target_id'];
        $cur = (int)$db->querySingle("SELECT is_premium FROM users WHERE id=$target_id");
        $db->exec("UPDATE users SET is_premium=".($cur?0:1)." WHERE id=$target_id");
        $msg = $cur ? 'Premium removed.' : 'Premium added.';
    }
    if (isset($_POST['toggle_maintenance']) && isSuperAdmin()) {
        $current = isMaintenanceMode($db);
        setMaintenanceMode($db, !$current);
        $msg = $current ? 'Maintenance mode disabled.' : 'Maintenance mode enabled.';
    }
    if (isset($_POST['process_appeal'])) {
        $appeal_id = (int)$_POST['appeal_id'];
        $action = $_POST['action'] ?? 'approve';
        $admin_note = $_POST['admin_note'] ?? '';
        processAppeal($db, $appeal_id, $action, $admin_note);
        $msg = $action === 'approve' ? 'Appeal approved - User restored.' : 'Appeal rejected - User permanently banned.';
    }
    if (isset($_POST['permanent_ban'])) {
        $target_id = (int)$_POST['target_id'];
        $db->exec("UPDATE users SET is_active = 0, is_permanent_ban = 1, ban_reason = 'Permanently banned by admin' WHERE id=$target_id");
        $msg = 'User permanently banned.';
    }
    if (isset($_POST['lift_ban'])) {
        $target_id = (int)$_POST['target_id'];
        $db->exec("UPDATE users SET is_active = 1, is_permanent_ban = 0, violation_count = 0 WHERE id=$target_id");
        $msg = 'Ban lifted - User restored.';
    }
}

// Stats
$stats = [
    'users'    => (int)$db->querySingle("SELECT COUNT(*) FROM users"),
    'posts'    => (int)$db->querySingle("SELECT COUNT(*) FROM posts"),
    'comments' => (int)$db->querySingle("SELECT COUNT(*) FROM comments"),
    'likes'    => (int)$db->querySingle("SELECT COUNT(*) FROM likes"),
    'messages' => (int)$db->querySingle("SELECT COUNT(*) FROM messages"),
    'reposts'  => (int)$db->querySingle("SELECT COUNT(*) FROM reposts"),
    'suspended' => (int)$db->querySingle("SELECT COUNT(*) FROM users WHERE is_active = 0"),
    'appeals'  => (int)$db->querySingle("SELECT COUNT(*) FROM appeals WHERE status = 'pending'"),
];

$tab = $_GET['tab'] ?? 'overview';
require '../includes/header.php';
?>

<!-- Modern Admin Styles - White/Black/Blue Theme -->
<style>
:root {
    --primary: #0066ff;
    --primary-dark: #0052cc;
    --primary-light: #e6f0ff;
    --primary-glow: rgba(0, 102, 255, 0.15);
    --dark: #0a0a0a;
    --dark-secondary: #1a1a1a;
    --dark-tertiary: #2d2d2d;
    --gray: #666666;
    --gray-light: #f0f0f0;
    --success: #00cc66;
    --danger: #ff3333;
    --warning: #ffaa00;
    --white: #ffffff;
    --border: #e0e0e0;
    --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.08);
    --shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.12);
    --radius: 10px;
    --radius-sm: 6px;
    --transition: all 0.2s ease;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

.admin-body {
    background: linear-gradient(180deg, #f5f7fa 0%, #ffffff 100%);
    min-height: 100vh;
    padding: 0;
}

.admin-wrapper {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 24px;
}

.admin-header {
    background: var(--white);
    border-bottom: 1px solid var(--border);
    padding: 20px 0;
    position: sticky;
    top: 60px;
    z-index: 100;
    box-shadow: var(--shadow-sm);
}

.admin-header .header-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    flex-wrap: wrap;
}

.admin-title {
    font-size: 1.4rem;
    font-weight: 700;
    color: var(--dark);
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
    letter-spacing: -0.5px;
}

.admin-title i {
    color: var(--primary);
    font-size: 1.6rem;
}

.admin-nav {
    display: flex;
    gap: 4px;
    background: var(--gray-light);
    padding: 4px;
    border-radius: 10px;
    overflow-x: auto;
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.admin-nav::-webkit-scrollbar {
    display: none;
}

.admin-tab {
    padding: 10px 18px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
    font-size: 0.85rem;
    color: var(--gray);
    transition: var(--transition);
    display: flex;
    align-items: center;
    gap: 6px;
    white-space: nowrap;
    flex-shrink: 0;
}

.admin-tab:hover {
    color: var(--primary);
    background: var(--primary-glow);
}

.admin-tab.active {
    background: var(--primary);
    color: var(--white);
    box-shadow: 0 2px 8px rgba(0, 102, 255, 0.3);
}

.admin-tab .badge {
    background: var(--danger);
    color: var(--white);
    font-size: 0.65rem;
    padding: 2px 6px;
    border-radius: 10px;
    font-weight: 600;
}

.admin-content {
    padding: 28px 0;
}

.admin-stat-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 16px;
    margin-bottom: 28px;
}

.admin-stat-card {
    background: var(--white);
    border-radius: var(--radius);
    padding: 20px 16px;
    box-shadow: var(--shadow-sm);
    text-align: center;
    transition: var(--transition);
    border: 1px solid var(--border);
    position: relative;
    overflow: hidden;
}

.admin-stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: var(--primary);
    opacity: 0;
    transition: var(--transition);
}

.admin-stat-card:hover {
    transform: translateY(-3px);
    box-shadow: var(--shadow-lg);
    border-color: var(--primary);
}

.admin-stat-card:hover::before {
    opacity: 1;
}

.admin-stat-card .stat-icon {
    width: 44px;
    height: 44px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 10px;
    font-size: 1.2rem;
}

.admin-stat-card .stat-icon.users { background: var(--primary-light); color: var(--primary); }
.admin-stat-card .stat-icon.posts { background: #e0f0ff; color: #0080ff; }
.admin-stat-card .stat-icon.comments { background: #e0ffe6; color: #00aa55; }
.admin-stat-card .stat-icon.likes { background: #ffe0e0; color: #dd2222; }
.admin-stat-card .stat-icon.messages { background: #f0f0f0; color: #555555; }
.admin-stat-card .stat-icon.reposts { background: #e0e8ff; color: #4466dd; }
.admin-stat-card .stat-icon.suspended { background: #ffe8e8; color: #cc2222; }
.admin-stat-card .stat-icon.appeals { background: #fff0d0; color: #cc8800; }

.admin-stat-card .stat-number {
    font-size: 1.6rem;
    font-weight: 700;
    color: var(--dark);
    line-height: 1.1;
}

.admin-stat-card .stat-label {
    font-size: 0.7rem;
    color: var(--gray);
    margin-top: 4px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-weight: 500;
}

.admin-card {
    background: var(--white);
    border-radius: var(--radius);
    padding: 20px;
    margin-bottom: 16px;
    box-shadow: var(--shadow-sm);
    transition: var(--transition);
    border: 1px solid var(--border);
}

.admin-card:hover {
    box-shadow: var(--shadow);
    border-color: #d0d0d0;
}

.admin-user-card {
    display: grid;
    grid-template-columns: auto 1fr auto;
    gap: 16px;
    padding: 16px;
    background: var(--white);
    border-radius: var(--radius);
    margin-bottom: 12px;
    box-shadow: var(--shadow-sm);
    transition: var(--transition);
    border: 1px solid var(--border);
    align-items: center;
}

.admin-user-card:hover {
    box-shadow: var(--shadow);
    border-color: var(--primary);
}

.admin-user-card .user-avatar {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    overflow: hidden;
    flex-shrink: 0;
    border: 2px solid var(--gray-light);
}

.admin-user-card .user-info {
    min-width: 0;
}

.admin-user-card .user-name {
    font-weight: 600;
    color: var(--dark);
    font-size: 0.95rem;
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.admin-user-card .user-meta {
    font-size: 0.75rem;
    color: var(--gray);
    margin-top: 3px;
}

.admin-user-card .user-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    align-items: center;
    justify-content: flex-end;
}

.admin-user-card .action-row {
    display: flex;
    gap: 6px;
    align-items: center;
    flex-wrap: wrap;
}

.admin-user-card .action-row form {
    display: inline-flex;
    gap: 4px;
    align-items: center;
    margin: 0;
}

.admin-action-btn {
    width: 34px;
    height: 34px;
    border-radius: var(--radius-sm);
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
    font-size: 0.9rem;
    flex-shrink: 0;
}

.admin-action-btn:hover {
    transform: scale(1.08);
}

.admin-action-btn.btn-danger { background: #ffe0e0; color: var(--danger); }
.admin-action-btn.btn-danger:hover { background: var(--danger); color: white; }

.admin-action-btn.btn-warning { background: #fff0d0; color: #cc8800; }
.admin-action-btn.btn-warning:hover { background: #cc8800; color: white; }

.admin-action-btn.btn-success { background: #e0ffea; color: var(--success); }
.admin-action-btn.btn-success:hover { background: var(--success); color: white; }

.admin-action-btn.btn-primary { background: var(--primary-light); color: var(--primary); }
.admin-action-btn.btn-primary:hover { background: var(--primary); color: white; }

.admin-action-btn.btn-outline { background: transparent; border: 1.5px solid var(--border); color: var(--gray); }
.admin-action-btn.btn-outline:hover { border-color: var(--primary); color: var(--primary); }

.admin-action-btn.btn-dark { background: var(--dark); color: white; }
.admin-action-btn.btn-dark:hover { background: var(--dark-secondary); }

.admin-post-card {
    background: var(--white);
    border-radius: var(--radius);
    padding: 16px;
    margin-bottom: 12px;
    box-shadow: var(--shadow-sm);
    transition: var(--transition);
    border: 1px solid var(--border);
}

.admin-post-card:hover {
    box-shadow: var(--shadow);
    border-color: var(--primary);
}

.admin-post-card .post-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
}

.admin-post-card .post-avatar {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    overflow: hidden;
    flex-shrink: 0;
    border: 2px solid var(--gray-light);
}

.admin-post-card .post-info {
    flex: 1;
    min-width: 0;
}

.admin-post-card .post-user {
    font-weight: 600;
    color: var(--dark);
    font-size: 0.9rem;
}

.admin-post-card .post-time {
    font-size: 0.7rem;
    color: var(--gray);
}

.admin-post-card .post-actions {
    margin-left: auto;
    display: flex;
    gap: 6px;
}

.admin-post-card .post-content {
    font-size: 0.875rem;
    color: #333;
    line-height: 1.55;
    margin-bottom: 12px;
    word-break: break-word;
}

.admin-post-card .post-image img {
    max-width: 180px;
    border-radius: var(--radius-sm);
    margin-bottom: 12px;
}

.admin-post-card .post-stats {
    display: flex;
    gap: 16px;
    font-size: 0.75rem;
    color: var(--gray);
}

.admin-post-card .post-stats span {
    display: flex;
    align-items: center;
    gap: 4px;
}

.admin-badge {
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 0.65rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.3px;
}

.admin-badge.premium { background: linear-gradient(135deg, var(--primary) 0%, #0052cc 100%); color: #fff; }
.admin-badge.admin { background: var(--dark); color: #fff; }
.admin-badge.superadmin { background: var(--dark); color: #fff; }
.admin-badge.suspended { background: var(--danger); color: #fff; }
.admin-badge.permanent { background: #660066; color: #fff; }

.admin-section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    flex-wrap: wrap;
    gap: 12px;
}

.admin-section-title {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--dark);
    display: flex;
    align-items: center;
    gap: 10px;
    letter-spacing: -0.3px;
}

.admin-section-title i {
    color: var(--primary);
    font-size: 1.2rem;
}

.admin-alert {
    background: var(--white);
    border-radius: var(--radius);
    padding: 14px 18px;
    box-shadow: var(--shadow-sm);
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 0.875rem;
    margin-bottom: 20px;
    border-left: 4px solid var(--primary);
}

.admin-alert.success { border-left-color: var(--success); }
.admin-alert.error { border-left-color: var(--danger); }

.admin-alert i {
    font-size: 1.1rem;
}

.admin-alert.success i { color: var(--success); }
.admin-alert.error i { color: var(--danger); }

.admin-special-card {
    background: linear-gradient(135deg, var(--dark) 0%, var(--dark-secondary) 100%);
    border-radius: var(--radius);
    padding: 20px;
    color: var(--white);
    margin-top: 20px;
}

.admin-special-card.blue {
    background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
}

.admin-special-card.danger {
    background: linear-gradient(135deg, var(--danger) 0%, #cc2222 100%);
}

.admin-special-card h6 {
    font-weight: 600;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.95rem;
}

.admin-special-card p {
    font-size: 0.8rem;
    opacity: 0.85;
    margin-bottom: 14px;
    line-height: 1.5;
}

.admin-special-card .sa-btn {
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.25);
    color: var(--white);
    padding: 6px 14px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: 500;
    font-size: 0.8rem;
    transition: var(--transition);
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.admin-special-card .sa-btn:hover {
    background: rgba(255,255,255,0.25);
    color: var(--white);
}

.admin-toggle-btn {
    background: var(--white);
    color: var(--dark);
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    font-weight: 500;
    font-size: 0.8rem;
    cursor: pointer;
    transition: var(--transition);
    display: inline-flex;
    align-items: center;
    gap: 6px;
}

.admin-toggle-btn:hover {
    transform: scale(1.02);
}

.admin-toggle-btn.active {
    background: var(--danger);
    color: var(--white);
}

.form-select-modern {
    border: 1.5px solid var(--border);
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 0.8rem;
    transition: var(--transition);
    background: white;
}

.form-select-modern:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px var(--primary-glow);
    outline: none;
}

.admin-appeal-reason {
    background: var(--gray-light);
    padding: 10px 12px;
    border-radius: 6px;
    margin: 8px 0;
    font-size: 0.8rem;
}

.admin-appeal-reason strong {
    color: var(--dark);
}

.admin-appeal-reason small {
    color: var(--gray);
    display: block;
    margin-top: 4px;
}

.admin-input {
    border: 1.5px solid var(--border);
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 0.8rem;
    transition: var(--transition);
}

.admin-input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px var(--primary-glow);
    outline: none;
}

/* Mobile Navigation Drawer */
.mobile-nav-toggle {
    display: none;
    background: var(--primary);
    color: white;
    border: none;
    width: 40px;
    height: 40px;
    border-radius: 8px;
    font-size: 1.2rem;
    cursor: pointer;
}

/* Responsive Design */
@media (max-width: 1200px) {
    .admin-wrapper {
        padding: 0 20px;
    }
    
    .admin-stat-grid {
        grid-template-columns: repeat(4, 1fr);
    }
}

@media (max-width: 992px) {
    .admin-wrapper {
        padding: 0 16px;
    }
    
    .admin-stat-grid {
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
    }
    
    .admin-user-card {
        grid-template-columns: auto 1fr auto;
        gap: 12px;
    }
    
    .admin-user-card .user-avatar {
        width: 44px;
        height: 44px;
    }
    
    .admin-user-card .user-actions {
        gap: 6px;
    }
    
    .admin-stat-card {
        padding: 16px 12px;
    }
    
    .admin-stat-card .stat-icon {
        width: 40px;
        height: 40px;
    }
    
    .admin-stat-card .stat-number {
        font-size: 1.4rem;
    }
}

@media (max-width: 768px) {
    .admin-header {
        top: 50px;
        padding: 14px 0;
    }
    
    .admin-header .header-content {
        flex-direction: column;
        align-items: stretch;
        gap: 14px;
    }
    
    .admin-title {
        font-size: 1.2rem;
        justify-content: center;
    }
    
    .admin-nav {
        justify-content: flex-start;
        padding-bottom: 6px;
    }
    
    .admin-tab {
        padding: 8px 14px;
        font-size: 0.8rem;
    }
    
    .admin-content {
        padding: 20px 0;
    }
    
    .admin-stat-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        margin-bottom: 20px;
    }
    
    .admin-stat-card {
        padding: 14px 10px;
    }
    
    .admin-stat-card .stat-icon {
        width: 36px;
        height: 36px;
        font-size: 1rem;
    }
    
    .admin-stat-card .stat-number {
        font-size: 1.3rem;
    }
    
    .admin-stat-card .stat-label {
        font-size: 0.6rem;
    }
    
    .admin-card,
    .admin-user-card,
    .admin-post-card {
        padding: 12px;
    }
    
    .admin-user-card {
        grid-template-columns: auto 1fr;
        grid-template-rows: auto auto;
        gap: 10px;
    }
    
    .admin-user-card .user-avatar {
        width: 44px;
        height: 44px;
        grid-row: 1;
    }
    
    .admin-user-card .user-info {
        grid-column: 2;
        grid-row: 1;
    }
    
    .admin-user-card .user-name {
        font-size: 0.85rem;
    }
    
    .admin-user-card .user-meta {
        font-size: 0.7rem;
    }
    
    .admin-user-card .user-actions {
        grid-column: 1 / -1;
        grid-row: 2;
        justify-content: flex-start;
        padding-top: 8px;
        border-top: 1px solid var(--border);
    }
    
    .admin-user-card .action-row {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
        align-items: center;
    }
    
    .admin-user-card .action-row form {
        display: inline-flex;
        gap: 4px;
        align-items: center;
        margin: 0;
    }
    
    .admin-post-card .post-header {
        flex-wrap: wrap;
    }
    
    .admin-post-card .post-avatar {
        width: 38px;
        height: 38px;
    }
    
    .admin-post-card .post-actions {
        width: 100%;
        margin-top: 10px;
        margin-left: 50px !important;
    }
    
    .admin-post-card .post-content {
        font-size: 0.85rem;
    }
    
    .admin-post-card .post-image img {
        max-width: 100%;
    }
    
    .admin-section-title {
        font-size: 1rem;
    }
    
    .admin-special-card {
        padding: 16px;
    }
    
    .admin-special-card h6 {
        font-size: 0.9rem;
    }
    
    .admin-special-card p {
        font-size: 0.75rem;
    }
    
    .admin-alert {
        padding: 12px 14px;
        font-size: 0.8rem;
    }
}

@media (max-width: 576px) {
    .admin-wrapper {
        padding: 0 12px;
    }
    
    .admin-stat-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 8px;
    }
    
    .admin-stat-card {
        padding: 12px 8px;
    }
    
    .admin-stat-card .stat-icon {
        width: 32px;
        height: 32px;
        font-size: 0.9rem;
    }
    
    .admin-stat-card .stat-number {
        font-size: 1.2rem;
    }
    
    .admin-stat-card .stat-label {
        font-size: 0.55rem;
    }
    
    .admin-tab {
        padding: 8px 12px;
        font-size: 0.75rem;
    }
    
    .admin-tab i {
        font-size: 0.9rem;
    }
    
    .admin-action-btn {
        width: 30px;
        height: 30px;
        font-size: 0.8rem;
    }
    
    .form-select-modern {
        font-size: 0.7rem;
        padding: 4px 6px;
        min-width: 80px;
    }
    
    .admin-input {
        font-size: 0.75rem;
        padding: 5px 8px;
    }
    
    .admin-badge {
        font-size: 0.55rem;
        padding: 2px 6px;
    }
    
    .admin-user-card .action-row form select.form-select-modern {
        max-width: 85px;
    }
}

@media (max-width: 400px) {
    .admin-stat-grid {
        grid-template-columns: 1fr 1fr;
    }
    
    .admin-user-card {
        gap: 8px;
        padding: 10px;
    }
    
    .admin-user-card .user-avatar {
        width: 40px;
        height: 40px;
    }
    
    .admin-user-card .user-actions {
        gap: 4px;
    }
    
    .admin-user-card .action-row {
        gap: 4px;
    }
    
    .admin-action-btn {
        width: 28px;
        height: 28px;
    }
    
    .form-select-modern {
        padding: 4px 5px;
        min-width: 70px;
    }
}

/* Extra large screens */
@media (min-width: 1600px) {
    .admin-wrapper {
        max-width: 1500px;
    }
    
    .admin-stat-grid {
        grid-template-columns: repeat(8, 1fr);
    }
}
</style>

<div class="admin-body">
    <div class="admin-wrapper">
        <!-- Header -->
        <div class="admin-header">
            <div class="header-content">
                <h1 class="admin-title">
                    <i class="bi bi-shield-check"></i>
                    Admin Panel
                </h1>
                <nav class="admin-nav">
                    <?php $tabs = [
                        'overview' => '<i class="bi bi-grid-1x2"></i> Overview',
                        'users' => '<i class="bi bi-people"></i> Users',
                        'posts' => '<i class="bi bi-file-post"></i> Posts',
                        'appeals' => '<i class="bi bi-chat-left-text"></i> Appeals' . ($stats['appeals'] > 0 ? ' <span class="badge">' . $stats['appeals'] . '</span>' : ''),
                        'banned' => '<i class="bi bi-person-x"></i> Banned',
                    ];
                    foreach ($tabs as $t => $label): ?>
                    <a href="?tab=<?= $t ?>" class="admin-tab <?= $tab === $t ? 'active' : '' ?>">
                        <?= $label ?>
                    </a>
                    <?php endforeach; ?>
                </nav>
            </div>
        </div>

        <!-- Content -->
        <div class="admin-content">
            <?php if ($msg): ?>
            <div class="admin-alert <?= strpos($msg, 'Invalid') !== false ? 'error' : 'success' ?>">
                <i class="bi <?= strpos($msg, 'Invalid') !== false ? 'bi-exclamation-circle-fill' : 'bi-check-circle-fill' ?>"></i>
                <?= htmlspecialchars($msg) ?>
            </div>
            <?php endif; ?>

            <?php if ($tab === 'overview'): ?>
            <!-- Statistics -->
            <div class="admin-stat-grid">
                <?php 
                $statConfig = [
                    'users' => ['icon' => 'bi-people-fill', 'class' => 'users', 'label' => 'Users'],
                    'posts' => ['icon' => 'bi-file-post-fill', 'class' => 'posts', 'label' => 'Posts'],
                    'comments' => ['icon' => 'bi-chat-dots-fill', 'class' => 'comments', 'label' => 'Comments'],
                    'likes' => ['icon' => 'bi-heart-fill', 'class' => 'likes', 'label' => 'Likes'],
                    'messages' => ['icon' => 'bi-envelope-fill', 'class' => 'messages', 'label' => 'Messages'],
                    'reposts' => ['icon' => 'bi-repeat', 'class' => 'reposts', 'label' => 'Reposts'],
                    'suspended' => ['icon' => 'bi-person-slash', 'class' => 'suspended', 'label' => 'Suspended'],
                    'appeals' => ['icon' => 'bi-chat-left-text-fill', 'class' => 'appeals', 'label' => 'Appeals'],
                ];
                foreach ($stats as $key => $val): ?>
                <?php if (isset($statConfig[$key])): ?>
                <div class="admin-stat-card">
                    <div class="stat-icon <?= $statConfig[$key]['class'] ?>">
                        <i class="bi <?= $statConfig[$key]['icon'] ?>"></i>
                    </div>
                    <div class="stat-number"><?= number_format($val) ?></div>
                    <div class="stat-label"><?= $statConfig[$key]['label'] ?></div>
                </div>
                <?php endif; ?>
                <?php endforeach; ?>
            </div>

            <!-- Super Admins -->
            <div class="admin-special-card">
                <h6><i class="bi bi-shield-fill-check"></i> Super Administrators</h6>
                <div>
                    <?php foreach (['silo', 'rizal'] as $sa):
                        $saUser = $db->querySingle("SELECT username FROM users WHERE username='$sa'", false);
                        if ($saUser): ?>
                        <a href="../profile/?u=<?= $sa ?>" class="sa-btn">
                            <i class="bi bi-at"></i>@<?= $sa ?>
                        </a>
                    <?php endif; endforeach; ?>
                </div>
            </div>

            <!-- Maintenance Mode -->
            <?php if (isSuperAdmin()): ?>
            <div class="admin-special-card <?= isMaintenanceMode($db) ? 'danger' : '' ?>">
                <h6><i class="bi bi-tools"></i> Maintenance Mode</h6>
                <p>When enabled, regular and premium users will see the maintenance popup bar. Admin and Super Admin retain full access.</p>
                <form method="POST" style="display: inline;">
                    <?= csrfField() ?>
                    <button name="toggle_maintenance" class="admin-toggle-btn <?= isMaintenanceMode($db) ? 'active' : '' ?>">
                        <i class="bi bi-<?= isMaintenanceMode($db) ? 'x-circle-fill' : 'toggle-on' ?>"></i>
                        <?= isMaintenanceMode($db) ? 'Disable' : 'Enable' ?>
                    </button>
                </form>
                <?php if (isMaintenanceMode($db)): ?>
                <span style="margin-left: 12px; opacity: 0.85; font-size: 0.8rem;"><i class="bi bi-info-circle"></i> Active</span>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php elseif ($tab === 'users'): ?>
            <div class="admin-section-header">
                <h5 class="admin-section-title"><i class="bi bi-people-fill"></i> All Users</h5>
            </div>
            <?php
            $users = $db->query("SELECT *, (SELECT COUNT(*) FROM posts WHERE user_id=users.id) as pc FROM users ORDER BY created_at DESC");
            while ($u = $users->fetchArray(SQLITE3_ASSOC)):
                $is_sa = in_array($u['username'], ['silo', 'rizal']);
            ?>
            <div class="admin-user-card">
                <div class="user-avatar">
                    <?= getAvatarHtml($u['username'], $u['avatar_url'] ?? '', 48) ?>
                </div>
                <div class="user-info">
                    <div class="user-name">
                        @<?= htmlspecialchars($u['username']) ?>
                        <?php if ($u['role'] === 'superadmin'): ?>
                        <span class="admin-badge superadmin">Super</span>
                        <?php elseif ($u['role'] === 'admin'): ?>
                        <span class="admin-badge admin">Admin</span>
                        <?php elseif ($u['is_premium']): ?>
                        <span class="admin-badge premium"><i class="bi bi-gem"></i></span>
                        <?php endif; ?>
                        <?php if (!$u['is_active']): ?>
                        <span class="admin-badge suspended">Off</span>
                        <?php endif; ?>
                    </div>
                    <div class="user-meta">
                        <?= $u['pc'] ?> posts · <?= htmlspecialchars($u['role']) ?> · <?= date('d M Y', strtotime($u['created_at'])) ?>
                    </div>
                </div>
                <?php if (!$is_sa && $u['id'] != $_SESSION['user_id']): ?>
                <div class="user-actions">
                    <?php if (isSuperAdmin()): ?>
                    <div class="action-row">
                        <form method="POST">
                            <?= csrfField() ?>
                            <input type="hidden" name="target_id" value="<?= $u['id'] ?>">
                            <select name="new_role" class="form-select-modern">
                                <option value="user" <?= $u['role'] === 'user' ? 'selected' : '' ?>>User</option>
                                <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                            </select>
                            <button name="change_role" class="admin-action-btn btn-primary" title="Set Role"><i class="bi bi-check-lg"></i></button>
                        </form>
                    </div>
                    <div class="action-row">
                        <form method="POST">
                            <?= csrfField() ?>
                            <input type="hidden" name="target_id" value="<?= $u['id'] ?>">
                            <button name="toggle_premium" class="admin-action-btn <?= $u['is_premium'] ? 'btn-warning' : 'btn-outline' ?>" title="<?= $u['is_premium'] ? 'Remove Premium' : 'Add Premium' ?>">
                                <i class="bi bi-gem"></i>
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                    <div class="action-row">
                        <form method="POST">
                            <?= csrfField() ?>
                            <input type="hidden" name="target_id" value="<?= $u['id'] ?>">
                            <button name="toggle_user" class="admin-action-btn <?= $u['is_active'] ? 'btn-warning' : 'btn-success' ?>" title="<?= $u['is_active'] ? 'Suspend' : 'Activate' ?>">
                                <i class="bi bi-<?= $u['is_active'] ? 'slash-circle' : 'check-circle-fill' ?>"></i>
                            </button>
                        </form>
                    </div>
                    <div class="action-row">
                        <form method="POST" onsubmit="return confirm('Delete @<?= addslashes($u['username']) ?>?')">
                            <?= csrfField() ?>
                            <input type="hidden" name="target_id" value="<?= $u['id'] ?>">
                            <button name="delete_user" class="admin-action-btn btn-danger" title="Delete">
                                <i class="bi bi-trash3-fill"></i>
                            </button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php endwhile; ?>

            <?php elseif ($tab === 'posts'): ?>
            <div class="admin-section-header">
                <h5 class="admin-section-title"><i class="bi bi-file-post-fill"></i> All Posts</h5>
            </div>
            <?php
            $posts = $db->query("SELECT posts.*, users.username, users.avatar_url FROM posts JOIN users ON posts.user_id=users.id ORDER BY posts.created_at DESC LIMIT 50");
            while ($p = $posts->fetchArray(SQLITE3_ASSOC)):
                $lc = (int)$db->querySingle("SELECT COUNT(*) FROM likes WHERE post_id=" . (int)$p['id']);
                $cc = (int)$db->querySingle("SELECT COUNT(*) FROM comments WHERE post_id=" . (int)$p['id']);
            ?>
            <div class="admin-post-card">
                <div class="post-header">
                    <div class="post-avatar">
                        <?= getAvatarHtml($p['username'], $p['avatar_url'] ?? '', 40) ?>
                    </div>
                    <div class="post-info">
                        <div class="post-user">@<?= htmlspecialchars($p['username']) ?></div>
                        <div class="post-time"><?= date('d M Y, H:i', strtotime($p['created_at'])) ?></div>
                    </div>
                    <div class="post-actions">
                        <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this post?')">
                            <?= csrfField() ?>
                            <input type="hidden" name="post_id" value="<?= $p['id'] ?>">
                            <button name="delete_post_admin" class="admin-action-btn btn-danger" title="Delete Post">
                                <i class="bi bi-trash3-fill"></i>
                            </button>
                        </form>
                    </div>
                </div>
                <div class="post-content">
                    <?= htmlspecialchars(substr($p['content'], 0, 200)) ?><?= strlen($p['content']) > 200 ? '...' : '' ?>
                </div>
                <?php if (!empty($p['image_url'])): ?>
                <div class="post-image">
                    <img src="<?= htmlspecialchars($p['image_url']) ?>" alt="Post image">
                </div>
                <?php endif; ?>
                <div class="post-stats">
                    <span><i class="bi bi-heart-fill" style="color: var(--danger);"></i> <?= $lc ?></span>
                    <span><i class="bi bi-chat-fill" style="color: var(--primary);"></i> <?= $cc ?></span>
                </div>
            </div>
            <?php endwhile; ?>

            <?php elseif ($tab === 'appeals'): ?>
            <div class="admin-section-header">
                <h5 class="admin-section-title"><i class="bi bi-chat-left-text-fill"></i> Appeal Requests</h5>
            </div>
            <?php
            $appeals = $db->query("SELECT appeals.*, users.username, users.violation_count, users.ban_reason FROM appeals JOIN users ON appeals.user_id = users.id WHERE appeals.status = 'pending' ORDER BY appeals.created_at DESC");
            $hasAppeals = false;
            while ($a = $appeals->fetchArray(SQLITE3_ASSOC)):
                $hasAppeals = true;
            ?>
            <div class="admin-user-card">
                <div class="user-avatar">
                    <?= getAvatarHtml($a['username'], $a['avatar_url'] ?? '', 48) ?>
                </div>
                <div class="user-info">
                    <div class="user-name">
                        @<?= htmlspecialchars($a['username']) ?>
                        <span class="admin-badge suspended"><?= $a['violation_count'] ?> Viol.</span>
                    </div>
                    <div class="admin-appeal-reason">
                        <strong>Ban Reason:</strong> <?= htmlspecialchars($a['ban_reason'] ?: 'Multiple violations') ?><br>
                        <strong>Appeal:</strong> <?= htmlspecialchars($a['reason']) ?>
                        <small>Submitted: <?= date('d M Y, H:i', strtotime($a['created_at'])) ?></small>
                    </div>
                </div>
                <div class="user-actions">
                    <div class="action-row">
                        <form method="POST" style="display: inline;">
                            <?= csrfField() ?>
                            <input type="hidden" name="appeal_id" value="<?= $a['id'] ?>">
                            <input type="hidden" name="action" value="approve">
                            <button name="process_appeal" class="admin-action-btn btn-success" title="Approve">
                                <i class="bi bi-check-circle-fill"></i>
                            </button>
                        </form>
                        <form method="POST" style="display: inline-flex; gap: 4px; align-items: center;">
                            <?= csrfField() ?>
                            <input type="hidden" name="appeal_id" value="<?= $a['id'] ?>">
                            <input type="hidden" name="action" value="permanent">
                            <input type="text" name="admin_note" placeholder="Reason" class="admin-input" style="width: 120px;">
                            <button name="process_appeal" class="admin-action-btn btn-danger" title="Reject">
                                <i class="bi bi-x-circle-fill"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
            <?php if (!$hasAppeals): ?>
            <div class="admin-alert success">
                <i class="bi bi-check-circle-fill"></i> No pending appeals.
            </div>
            <?php endif; ?>

            <?php elseif ($tab === 'banned'): ?>
            <div class="admin-section-header">
                <h5 class="admin-section-title"><i class="bi bi-person-x-fill"></i> Banned Users</h5>
            </div>
            <?php
            $banned = $db->query("SELECT * FROM users WHERE is_active = 0 ORDER BY banned_at DESC");
            $hasBanned = false;
            while ($b = $banned->fetchArray(SQLITE3_ASSOC)):
                $is_sa = in_array($b['username'], ['silo', 'rizal']);
                if ($is_sa) continue;
                $hasBanned = true;
            ?>
            <div class="admin-user-card">
                <div class="user-avatar">
                    <?= getAvatarHtml($b['username'], $b['avatar_url'] ?? '', 48) ?>
                </div>
                <div class="user-info">
                    <div class="user-name">
                        @<?= htmlspecialchars($b['username']) ?>
                        <?php if ($b['is_permanent_ban']): ?>
                        <span class="admin-badge permanent">Permanent</span>
                        <?php else: ?>
                        <span class="admin-badge suspended">Suspended</span>
                        <?php endif; ?>
                    </div>
                    <div class="user-meta">
                        <strong>Reason:</strong> <?= htmlspecialchars($b['ban_reason'] ?: 'Policy violation') ?><br>
                        <strong>Violations:</strong> <?= (int)$b['violation_count'] ?> · <strong>Banned:</strong> <?= $b['banned_at'] ? date('d M Y, H:i', strtotime($b['banned_at'])) : 'N/A' ?>
                    </div>
                </div>
                <div class="user-actions">
                    <div class="action-row">
                        <form method="POST" style="display: inline;">
                            <?= csrfField() ?>
                            <input type="hidden" name="target_id" value="<?= $b['id'] ?>">
                            <button name="lift_ban" class="admin-action-btn btn-success" title="Restore" onclick="return confirm('Restore this account?')">
                                <i class="bi bi-arrow-counterclockwise"></i>
                            </button>
                        </form>
                        <?php if (!$b['is_permanent_ban']): ?>
                        <form method="POST" style="display: inline;">
                            <?= csrfField() ?>
                            <input type="hidden" name="target_id" value="<?= $b['id'] ?>">
                            <button name="permanent_ban" class="admin-action-btn btn-dark" title="Permanent Ban" onclick="return confirm('Permanently ban this user?')">
                                <i class="bi bi-slash-circle-fill"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
            <?php if (!$hasBanned): ?>
            <div class="admin-alert success">
                <i class="bi bi-check-circle-fill"></i> No banned users.
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require '../includes/footer.php'; ?>
