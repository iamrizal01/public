<?php
header('Location: /download.html', true, 301);
exit;
?>
