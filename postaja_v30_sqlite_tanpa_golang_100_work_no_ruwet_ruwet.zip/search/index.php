<?php
$root_path = '../'; $api_path = '../api/'; $home_url = '../index.php';
$current_page = 'search'; $page_title = 'Search';
require '../includes/config.php';
require '../includes/functions.php';
require '../includes/auth_handler.php';

$q          = trim($_GET['q'] ?? '');
$type       = $_GET['type'] ?? 'posts';
$results    = null;
$isRamadhan = (stripos($q, 'ramadhan') !== false || stripos($q, 'ramadan') !== false);

if ($q !== '') {
    $like = '%' . $q . '%';
    if ($type === 'users') {
        $stmt = $db->prepare('SELECT * FROM users WHERE username LIKE :q LIMIT 20');
    } else {
        $stmt = $db->prepare('SELECT posts.*, users.username, users.role, users.avatar_url, users.is_premium FROM posts JOIN users ON posts.user_id=users.id WHERE posts.content LIKE :q ORDER BY posts.created_at DESC LIMIT 30');
    }
    $stmt->bindValue(':q', $like);
    $results = $stmt->execute();
}

require '../includes/header.php';
?>

<div class="p-3 border-bottom">
    <form method="GET">
        <div class="input-group mb-2">
            <input type="text" name="q" class="form-control bg-light border px-4" placeholder="Search..." value="<?= htmlspecialchars($q) ?>">
            <button class="btn btn-primary px-4">Search</button>
        </div>
        <div class="d-flex gap-3 px-1">
            <div class="form-check"><input class="form-check-input" type="radio" name="type" value="posts" <?= $type==='posts'?'checked':'' ?>> Posts</div>
            <div class="form-check"><input class="form-check-input" type="radio" name="type" value="users" <?= $type==='users'?'checked':'' ?>> Users</div>
        </div>
    </form>
</div>

<?php if ($q !== '' && $results): ?>
    <?php if ($type === 'users'): ?>
        <?php $any = false; while ($u = $results->fetchArray(SQLITE3_ASSOC)): $any = true; ?>
        <div class="p-3 border-bottom d-flex align-items-center gap-3">
            <a href="../profile/?u=<?= urlencode($u['username']) ?>">
                <?= getAvatarHtml($u['username'], $u['avatar_url'] ?? '', 48) ?>
            </a>
            <div class="flex-grow-1">
                <a href="../profile/?u=<?= urlencode($u['username']) ?>" class="fw-bold text-dark text-decoration-none d-block">@<?= htmlspecialchars($u['username']) ?></a>
                <span class="text-muted small"><?= htmlspecialchars($u['bio'] ?: 'No bio yet.') ?></span>
            </div>
            <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] != $u['id']):
                $is_f = (bool)$db->querySingle("SELECT COUNT(*) FROM follows WHERE follower_id=".(int)$_SESSION['user_id']." AND following_id=".(int)$u['id']); ?>
            <button onclick="toggleFollow(<?= $u['id'] ?>)" id="follow-btn-<?= $u['id'] ?>" class="btn-follow <?= $is_f?'following':'unfollow' ?>"><?= $is_f?'Following':'Follow' ?></button>
            <?php endif; ?>
        </div>
        <?php endwhile;
        if (!$any) echo '<div class="p-4 text-center text-muted">No users found.</div>'; ?>
    <?php else: ?>
        <div id="feed-container">
        <?php $any = false; while ($p = $results->fetchArray(SQLITE3_ASSOC)) { echo renderPostHtml($p, $db); $any = true; }
        if (!$any) echo '<div class="p-4 text-center text-muted">No results for "' . htmlspecialchars($q) . '"</div>'; ?>
        </div>
    <?php endif; ?>
<?php elseif ($q !== ''): ?>
<div class="p-4 text-center text-muted">No results.</div>
<?php else: ?>
<div class="p-5 text-center text-muted"><i class="bi bi-search display-3 mb-3 d-block opacity-25"></i><p>Search for posts or users...</p></div>
<?php endif; ?>

<?php require '../includes/footer.php'; ?>

<?php if ($isRamadhan): ?>
<div class="modal fade" id="ramadhanModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-5 overflow-hidden" style="background:linear-gradient(145deg,#021b27,#044a3a);color:#fff;">
            <div class="position-relative p-4 pb-3">
                <div class="position-absolute top-0 end-0 mt-3 me-3">
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="mb-2">
                    <span class="badge bg-light text-dark rounded-pill px-3 py-1 small">Ramadhan Special</span>
                </div>
                <h4 class="fw-bold mb-1">Marhaban Ya Ramadhan</h4>
                <p class="mb-0 small text-white-50">"Ramadhan bukan tentang menahan lapar dan haus, tapi tentang menahan hati dari segala yang tidak baik." - someone </p>
            </div>
            <div class="px-4 pb-4 d-flex justify-content-between align-items-center" style="border-top:1px solid rgba(255,255,255,.08);">
                <div class="small text-white-50">
                    Tetap jaga niat, fokus ibadah, dan sebarkan kebaikan di PostAja
                </div>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var m = document.getElementById('ramadhanModal');
    if (m && typeof bootstrap !== 'undefined') {
        new bootstrap.Modal(m).show();
    }
});
</script>
<?php endif; ?>
