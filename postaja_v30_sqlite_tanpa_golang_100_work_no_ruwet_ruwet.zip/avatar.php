<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

const POSTS_PER_PAGE = 10;
$whatsapp_channel_url = 'https://whatsapp.com/channel/0029VbBCZ5I6RGJQjyecoT0R';

$from_email = 'noreply@silosigma.biz.id';
$subject_prefix = '[PostAja] ';
$base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";


$db = new SQLite3('data.db');
$db->exec('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, email TEXT UNIQUE, password TEXT, role TEXT DEFAULT "user", is_verified INTEGER DEFAULT 1, bio TEXT DEFAULT "", avatar_url TEXT DEFAULT "", notifications_enabled INTEGER DEFAULT 1, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$db->exec('CREATE TABLE IF NOT EXISTS posts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, content TEXT, image_url TEXT, music_url TEXT DEFAULT "", music_title TEXT DEFAULT "", created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$db->exec('CREATE TABLE IF NOT EXISTS comments (id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER, user_id INTEGER, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$db->exec('CREATE TABLE IF NOT EXISTS stories (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, image_url TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');
$db->exec('CREATE TABLE IF NOT EXISTS likes (id INTEGER PRIMARY KEY AUTOINCREMENT, post_id INTEGER, user_id INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(post_id, user_id))');
$db->exec('CREATE TABLE IF NOT EXISTS follows (id INTEGER PRIMARY KEY AUTOINCREMENT, follower_id INTEGER, following_id INTEGER, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(follower_id, following_id))');

$db->exec('CREATE TABLE IF NOT EXISTS public_chat (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, message TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)');

$db->exec('CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT, 
    user_id INTEGER, 
    message TEXT, 
    is_read INTEGER DEFAULT 0, 
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)');

// Pastikan kolom avatar_url ada (untuk DB lama)
$has_avatar = false;
$has_notif = false;
$cols = $db->query("PRAGMA table_info(users)");
while ($col = $cols->fetchArray(SQLITE3_ASSOC)) {
    if ($col['name'] === 'avatar_url') { $has_avatar = true; }
    if ($col['name'] === 'notifications_enabled') { $has_notif = true; }
}
if (!$has_avatar) {
    $db->exec("ALTER TABLE users ADD COLUMN avatar_url TEXT DEFAULT ''");
}
if (!$has_notif) {
    $db->exec("ALTER TABLE users ADD COLUMN notifications_enabled INTEGER DEFAULT 1");
}

// --- LOGIKA MENGAMBIL NOTIFIKASI (AJAX) ---
if (isset($_GET['check_notif']) && isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    // Ambil 1 notif terbaru yang belum dibaca
    $stmt = $db->prepare('SELECT * FROM notifications WHERE user_id = :u AND is_read = 0 ORDER BY created_at DESC LIMIT 1');
    $stmt->bindValue(':u', $uid);
    $notif = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
    
    if ($notif) {
        // Tandai sudah dibaca agar tidak muncul terus menerus
        $db->exec("UPDATE notifications SET is_read = 1 WHERE id = " . $notif['id']);
        echo json_encode($notif);
    } else {
        echo json_encode(null);
    }
    exit;
}

// Logika Like (Hanya untuk User Login)
if (isset($_GET['like_post']) && isset($_SESSION['user_id'])) {
    $p_id = (int)$_GET['like_post'];
    $u_id = $_SESSION['user_id'];
    
    $check = $db->prepare('SELECT id FROM likes WHERE post_id = :p AND user_id = :u');
    $check->bindValue(':p', $p_id);
    $check->bindValue(':u', $u_id);
    $exists = $check->execute()->fetchArray();

    if ($exists) {
        $del = $db->prepare('DELETE FROM likes WHERE post_id = :p AND user_id = :u');
        $del->bindValue(':p', $p_id);
        $del->bindValue(':u', $u_id);
        $del->execute();
        $status = 'unliked';
    } else {
        $ins = $db->prepare('INSERT INTO likes (post_id, user_id) VALUES (:p, :u)');
        $ins->bindValue(':p', $p_id);
        $ins->bindValue(':u', $u_id);
        $ins->execute();
        $status = 'liked';
    }
    
    $count = $db->querySingle("SELECT COUNT(*) FROM likes WHERE post_id = $p_id");
    echo json_encode(['status' => $status, 'count' => $count]);
    exit;
} elseif (isset($_GET['like_post'])) {
    echo json_encode(['status' => 'error', 'message' => 'login_required']);
    exit;
}

// Logika Follow/Unfollow (Hanya untuk User Login)
if (isset($_GET['follow_user']) && isset($_SESSION['user_id'])) {
    $following_id = (int)$_GET['follow_user'];
    $follower_id = $_SESSION['user_id'];
    
    if ($following_id !== $follower_id) {
        $check = $db->prepare('SELECT id FROM follows WHERE follower_id = :fer AND following_id = :fing');
        $check->bindValue(':fer', $follower_id);
        $check->bindValue(':fing', $following_id);
        $exists = $check->execute()->fetchArray();

        if ($exists) {
            $del = $db->prepare('DELETE FROM follows WHERE follower_id = :fer AND following_id = :fing');
            $del->bindValue(':fer', $follower_id);
            $del->bindValue(':fing', $following_id);
            $del->execute();
            $status = 'unfollowed';
        } else {
            $ins = $db->prepare('INSERT INTO follows (follower_id, following_id) VALUES (:fer, :fing)');
            $ins->bindValue(':fer', $follower_id);
            $ins->bindValue(':fing', $following_id);
            $ins->execute();
            $msg = "@" . $_SESSION['username'] . " mulai mengikuti Anda!";
            $notif = $db->prepare('INSERT INTO notifications (user_id, message) VALUES (:uid, :msg)');
            $notif->bindValue(':uid', $following_id);
            $notif->bindValue(':msg', $msg);
            $notif->execute();
            $status = 'followed';
        }
        echo json_encode(['status' => $status]);
    }
    exit;
} elseif (isset($_GET['follow_user'])) {
    echo json_encode(['status' => 'error', 'message' => 'login_required']);
    exit;
}

// Infinite Scroll
if (isset($_GET['load_posts'])) {
    $offset = (int)$_GET['offset'];
    $stmt = $db->prepare('SELECT posts.*, users.username, users.role, users.avatar_url FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.created_at DESC LIMIT :l OFFSET :o');
    $stmt->bindValue(':l', POSTS_PER_PAGE, SQLITE3_INTEGER);
    $stmt->bindValue(':o', $offset, SQLITE3_INTEGER);
    $res = $stmt->execute();
    $html = '';
    while ($p = $res->fetchArray(SQLITE3_ASSOC)) { $html .= renderPostHtml($p, $db); }
    echo json_encode(['html' => $html]); exit;
}

// Search
$search_results = null;
if (isset($_GET['q'])) {
    $q = '%' . $_GET['q'] . '%';
    $search_type = $_GET['type'] ?? 'posts';
    
    if ($search_type === 'users') {
        $stmt = $db->prepare('SELECT * FROM users WHERE username LIKE :q LIMIT 20');
    } else {
        $stmt = $db->prepare('SELECT posts.*, users.username, users.role, users.avatar_url FROM posts JOIN users ON posts.user_id = users.id WHERE posts.content LIKE :q ORDER BY posts.created_at DESC LIMIT 20');
    }
    $stmt->bindValue(':q', $q);
    $search_results = $stmt->execute();
}

// Fungsi Sensor Kata Kasar
function censorMessage($text) {
    $bad_words = ['anjing', 'goblok', 'ngentod', 'asu', 'kontol', 'bajingan', 'memek', 'jembut', 'bangsat', 'pepek', 'tolol', 'anj', 'bgst', 'perek', 'babi', 'bacot', 'kampret', 'geblek', 'gblk', 'tai', 'tolol', 'goblog', 'jancok', 'kntl', 'kntol', 'puki', 'sange', 'senggol', 'setan', 'brengsek', 'bego', 'bgsd', 'gblk', 'gblg'];
    $has_bad_word = false;
    foreach ($bad_words as $word) {
        if (stripos($text, $word) !== false) {
            $text = preg_replace('/' . $word . '/i', '####', $text);
            $has_bad_word = true;
        }
    }
    return ['text' => $text, 'violation' => $has_bad_word];
}

function renderPostHtml($post, $db) {
    ob_start(); 
    $roles = explode(',', $post['role']);
    $is_silo = ($post['username'] === 'silo');
    
    if ($is_silo) { $role_class = "silo-anim"; }
    else if (in_array('admin', $roles)) { $role_class = "role-admin"; }
    else { $role_class = "role-user"; }

    $stmt_like = $db->prepare('SELECT COUNT(*) as count FROM likes WHERE post_id = :p');
    $stmt_like->bindValue(':p', $post['id'], SQLITE3_INTEGER);
    $like_count = $stmt_like->execute()->fetchArray(SQLITE3_ASSOC)['count'];
    $is_liked = false;
    if(isset($_SESSION['user_id'])) {
        $stmt_check = $db->prepare('SELECT COUNT(*) as count FROM likes WHERE post_id = :p AND user_id = :u');
        $stmt_check->bindValue(':p', $post['id'], SQLITE3_INTEGER);
        $stmt_check->bindValue(':u', $_SESSION['user_id'], SQLITE3_INTEGER);
        $is_liked = $stmt_check->execute()->fetchArray(SQLITE3_ASSOC)['count'] > 0;
    }
    // Prepare avatar HTML
    $avatar_html = '';
    if (!empty($post['avatar_url'])) {
        $avatar_html = '<img src="' . htmlspecialchars($post['avatar_url']) . '" style="width:48px;height:48px;border-radius:50%;object-fit:cover;">';
    } else {
        $avatar_html = strtoupper(substr($post['username'],0,1));
    }
    ?>
    <div class="post-card mb-0 border-bottom p-3 transition-all" id="post-<?= $post['id'] ?>">
        <div class="d-flex gap-3">
            <div class="modern-avatar flex-shrink-0"><?= $avatar_html ?></div>
            <div class="flex-grow-1">
                <div class="d-flex align-items-center gap-1 flex-wrap">
                    <a href="?profile=<?= urlencode($post['username']) ?>" class="fw-bold text-decoration-none text-dark <?= $role_class ?>">@<?= htmlspecialchars($post['username']) ?></a>
                    <?php if($is_silo): ?>
                        <span class="badge bg-dark text-white border-0" style="font-size: 0.65rem; padding: 2px 6px;">admin</span>
                    <?php endif; ?>
                    <span class="text-muted small">· <?= date('d M', strtotime($post['created_at'])) ?></span>
                </div>
                <div class="post-content mt-1 mb-2 text-dark" style="white-space: pre-wrap;"><?= nl2br(htmlspecialchars($post['content'])) ?></div>
                
                <?php if ($post['image_url']): ?>
                    <div class="post-image-container mb-3 overflow-hidden rounded-4 border">
                        <img src="<?= htmlspecialchars($post['image_url']) ?>" class="img-fluid w-100 hover-zoom" loading="lazy">
                    </div>
                <?php endif; ?>
                <?php if (!empty($post['music_url'])): ?>
                    <div class="post-music-player mb-3 p-3 rounded-4" style="background:linear-gradient(135deg,#1a1a2e,#16213e);border:1px solid #333;">
                        <div class="d-flex align-items-center gap-3">
                            <button class="music-play-btn btn btn-link text-white p-0" onclick="toggleMusic(this, '<?= htmlspecialchars($post['music_url']) ?>')">
                                <i class="bi bi-play-circle-fill fs-4"></i>
                            </button>
                            <div class="flex-grow-1">
                                <div class="music-wave-container">
                                    <div class="music-wave">
                                        <span></span><span></span><span></span><span></span><span></span>
                                    </div>
                                </div>
                                <div class="music-info">
                                    <div class="text-white small fw-bold"><?= htmlspecialchars($post['music_title'] ?: 'Music') ?></div>
                                    <div class="text-secondary small"><?= htmlspecialchars($post['username']) ?></div>
                                </div>
                            </div>
                            <i class="bi bi-music-note-beamed text-white-50 fs-5"></i>
                        </div>
                        <audio class="music-audio" src="<?= htmlspecialchars($post['music_url']) ?>" preload="none"></audio>
                    </div>
                <?php endif; ?>

                <div class="d-flex justify-content-between align-items-center" style="max-width: 400px;">
                    <button onclick="likePost(<?= $post['id'] ?>)" class="btn-action like-btn <?= $is_liked ? 'active' : '' ?>" id="like-btn-<?= $post['id'] ?>">
                        <i class="bi <?= $is_liked ? 'bi-heart-fill' : 'bi-heart' ?>"></i>
                        <span class="count"><?= $like_count ?></span>
                    </button>
                    <button class="btn-action comment-trigger" onclick="focusComment(<?= $post['id'] ?>)">
                        <i class="bi bi-chat"></i>
                        <span class="count"><?php $stmt_cm = $db->prepare('SELECT COUNT(*) as count FROM comments WHERE post_id = :p'); $stmt_cm->bindValue(':p', $post['id'], SQLITE3_INTEGER); echo $stmt_cm->execute()->fetchArray(SQLITE3_ASSOC)['count']; ?></span>
                    </button>
                    <button class="btn-action share-btn">
                        <i class="bi bi-share"></i>
                    </button>
                </div>

                <div class="comment-section mt-3">
                    <?php
                    $c = $db->prepare('SELECT comments.*, users.username FROM comments JOIN users ON comments.user_id = users.id WHERE post_id = :p ORDER BY created_at ASC LIMIT 3');
                    $c->bindValue(':p', $post['id']);
                    $rc = $c->execute();
                    while ($cm = $rc->fetchArray(SQLITE3_ASSOC)): ?>
                        <div class="mb-1 small d-flex gap-2">
                            <b class="text-dark">@<?= $cm['username'] ?></b> 
                            <span class="text-secondary"><?= htmlspecialchars($cm['content']) ?></span>
                        </div>
                    <?php endwhile; ?>
                    
                    <form method="POST" class="mt-2 d-flex gap-2 align-items-center" onsubmit="return checkAuth(event)">
                        <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                        <input type="text" name="comment_content" id="comment-input-<?= $post['id'] ?>" class="form-control form-control-sm border-0 bg-light rounded-pill px-3" placeholder="Balas postingan ini..." required>
                        <button name="create_comment" class="btn btn-dark btn-sm rounded-pill px-3">Kirim</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php return ob_get_clean();
}

// Penanganan Form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['register'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        // Instruksi Tersimpan: User accounts harus dienkripsi
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $db->prepare('INSERT INTO users (username, email, password, is_verified) VALUES (:u, :e, :p, 1)');
        $stmt->bindValue(':u', $username); $stmt->bindValue(':e', $email); $stmt->bindValue(':p', $password);
        try { if ($stmt->execute()) { $success_msg = "Pendaftaran berhasil! Silakan login."; } } 
        catch (Exception $e) { $error_msg = "Username atau Email sudah terdaftar."; }
    }
    if (isset($_POST['login'])) {
        $stmt = $db->prepare('SELECT * FROM users WHERE username = :u');
        $stmt->bindValue(':u', $_POST['username']);
        $user = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
        if ($user && password_verify($_POST['password'], $user['password'])) {
            $_SESSION['user_id'] = $user['id']; $_SESSION['username'] = $user['username']; $_SESSION['avatar_url'] = $user['avatar_url'] ?? '';
            header('Location: index.php'); exit;
        } else { $error_msg = "Username atau Password salah!"; }
    }
    if (isset($_POST['logout'])) { session_destroy(); header('Location: index.php'); exit; }
    
    // Proteksi Fitur untuk yang login saja
    if (isset($_SESSION['user_id'])) {
        if (isset($_POST['create_post'])) {
            $stmt = $db->prepare('INSERT INTO posts (user_id, content, image_url, music_url, music_title) VALUES (:u, :c, :i, :m, :t)');
            $stmt->bindValue(':u', $_SESSION['user_id']); $stmt->bindValue(':c', $_POST['content']); $stmt->bindValue(':i', $_POST['image_url']); $stmt->bindValue(':m', $_POST['music_url'] ?? ''); $stmt->bindValue(':t', $_POST['music_title'] ?? '');
            $stmt->execute(); header("Location: index.php"); exit;
        }
        if (isset($_POST['create_story'])) {
            $stmt = $db->prepare('INSERT INTO stories (user_id, image_url) VALUES (:u, :i)');
            $stmt->bindValue(':u', $_SESSION['user_id']); $stmt->bindValue(':i', $_POST['story_image_url']);
            $stmt->execute(); header("Location: index.php"); exit;
        }
        if (isset($_POST['create_comment'])) {
            $stmt = $db->prepare('INSERT INTO comments (post_id, user_id, content) VALUES (:p, :u, :c)');
            $stmt->bindValue(':p', $_POST['post_id']); $stmt->bindValue(':u', $_SESSION['user_id']); $stmt->bindValue(':c', $_POST['comment_content']);
            $stmt->execute(); header("Location: index.php"); exit;
        }
        // Logic Simpan Chat Public
        if (isset($_POST['send_chat'])) {
            $censored = censorMessage($_POST['chat_message']);
            $stmt = $db->prepare('INSERT INTO public_chat (user_id, message) VALUES (:u, :m)');
            $stmt->bindValue(':u', $_SESSION['user_id']);
            $stmt->bindValue(':m', $censored['text']);
            $stmt->execute();
            
            $violation_flag = $censored['violation'] ? "?chat=1&warned=1" : "?chat=1";
            header("Location: index.php" . $violation_flag);
            exit;
        }
        // Update settings (notification toggle and avatar)
        if (isset($_POST['update_avatar']) || isset($_POST['toggle_notifications'])) {
            $profile_to_update = $_SESSION['user_id'];
            
            // Update avatar if provided
            if (isset($_POST['avatar_url']) && !empty(trim($_POST['avatar_url']))) {
                $url = trim($_POST['avatar_url']);
                if (!filter_var($url, FILTER_VALIDATE_URL)) {
                    $error_msg = 'URL avatar tidak valid.';
                } else {
                    $stmt = $db->prepare('UPDATE users SET avatar_url = :a WHERE id = :id');
                    $stmt->bindValue(':a', $url);
                    $stmt->bindValue(':id', $profile_to_update, SQLITE3_INTEGER);
                    $stmt->execute();
                    $_SESSION['avatar_url'] = $url;
                }
            }
            
            // Update notification settings
            if (isset($_POST['toggle_notifications'])) {
                $notif_enabled = isset($_POST['notifications_enabled']) ? 1 : 0;
                $stmt = $db->prepare('UPDATE users SET notifications_enabled = :n WHERE id = :id');
                $stmt->bindValue(':n', $notif_enabled, SQLITE3_INTEGER);
                $stmt->bindValue(':id', $profile_to_update, SQLITE3_INTEGER);
                $stmt->execute();
                if (!isset($error_msg)) {
                    $success_msg = 'Pengaturan berhasil diperbarui.';
                }
            }
            
            // Refresh profile data
            $stmt_refresh = $db->prepare('SELECT * FROM users WHERE id = :id');
            $stmt_refresh->bindValue(':id', $profile_to_update, SQLITE3_INTEGER);
            $view_profile = $stmt_refresh->execute()->fetchArray(SQLITE3_ASSOC);
            
            if (!isset($error_msg)) {
                header('Location: index.php?profile=' . urlencode($_SESSION['username'])); exit;
            }
        }
    }
}

$view_profile = null;
if (isset($_GET['profile'])) {
    $stmt = $db->prepare('SELECT * FROM users WHERE username = :u');
    $stmt->bindValue(':u', $_GET['profile']);
    $view_profile = $stmt->execute()->fetchArray(SQLITE3_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>PostAja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        :root { 
            --accent: #000000; 
            --accent-hover: #333333;
            --bg: #ffffff; 
            --border: #eeeeee;
            --text-main: #000000;
            --text-sub: #666666;
            --light-bg: #f8f8f8;
        }
        
        body { background: var(--bg); font-family: 'Plus Jakarta Sans', sans-serif; color: var(--text-main); overflow-x: hidden; }
        
        .main-container { max-width: 1300px; margin: 0 auto; display: flex; }
        .sidebar-left { width: 275px; height: 100vh; position: sticky; top: 0; padding: 10px 20px; border-right: 1px solid var(--border); }
        .feed-center { flex: 1; max-width: 600px; border-right: 1px solid var(--border); min-height: 100vh; margin: 0 auto; }
        .sidebar-right { flex: 1; padding: 10px 30px; position: sticky; top: 0; height: 100vh; }
        /* Container Notifikasi iOS */
.ios-notification {
    position: fixed;
    top: -120px; /* Sembunyi di atas */
    left: 50%;
    transform: translateX(-50%);
    width: 90%;
    max-width: 420px;
    background: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(15px);
    -webkit-backdrop-filter: blur(15px);
    border-radius: 25px;
    padding: 15px 20px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    z-index: 9999;
    display: flex;
    align-items: center;
    gap: 15px;
    transition: all 0.7s cubic-bezier(0.23, 1, 0.32, 1);
    border: 0.5px solid rgba(255, 255, 255, 0.5);
}

/* Munculkan notifikasi */
.ios-notification.active {
    top: 20px;
}

.ios-icon {
    width: 42px;
    height: 42px;
    background: linear-gradient(135deg, #000dff, #006eff);
    color: white;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
}

.ios-content {
    flex-grow: 1;
}

.ios-title {
    font-weight: 800;
    font-size: 0.85rem;
    display: flex;
    justify-content: space-between;
    margin-bottom: 2px;
}

.ios-body {
    font-size: 0.9rem;
    color: #222;
    line-height: 1.3;
}

.ios-time {
    font-weight: 400;
    color: #666;
    font-size: 0.75rem;
}
        .nav-link-item { display: flex; align-items: center; gap: 20px; padding: 12px 20px; font-size: 1.25rem; font-weight: 500; border-radius: 99px; transition: 0.2s; color: var(--text-main); text-decoration: none; width: fit-content; margin-bottom: 5px; }
        .nav-link-item:hover { background: var(--light-bg); }
        .brand-logo { font-size: 2rem; color: var(--accent); padding-left: 15px; margin-bottom: 10px; display: block; }

        .post-card { cursor: pointer; transition: background 0.2s; border-bottom: 1px solid var(--border); }
        .post-card:hover { background: rgba(0,0,0,0.02); }
        .modern-avatar { width: 48px; height: 48px; border-radius: 50%; background: #000; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 1.2rem; color: #fff; }

        .btn-action { background: none; border: none; color: var(--text-sub); display: flex; align-items: center; gap: 8px; transition: 0.2s; padding: 8px; border-radius: 50%; }
        .like-btn:hover { color: #000; background: rgba(0, 0, 0, 0.05); }
        .like-btn.active { color: #000; }

        .compose-area { border-bottom: 1px solid var(--border); padding: 15px; }
        .compose-input { font-size: 1.3rem; border: none; outline: none; width: 100%; resize: none; min-height: 50px; background: transparent; }

        .story-container { display: flex; gap: 12px; overflow-x: auto; padding: 15px; border-bottom: 8px solid var(--light-bg); scrollbar-width: none; }
        .story-circle { flex: 0 0 auto; width: 66px; text-align: center; cursor: pointer; }
        .story-ring { width: 60px; height: 60px; border-radius: 50%; border: 2px solid #000; padding: 2px; }
        .story-ring img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; }

        .silo-anim { font-weight: 800; text-transform: uppercase; letter-spacing: 1px; }

        .profile-banner { height: 200px; background: #000; margin-bottom: -60px; }
        .profile-avatar-wrapper { position: relative; display: flex; justify-content: space-between; align-items: flex-end; padding: 0 20px; }
        .profile-avatar-main { width: 120px; height: 120px; border-radius: 50%; border: 4px solid #fff; background: #000; display: flex; align-items: center; justify-content: center; font-size: 3rem; color: #fff; font-weight: 800; }
        .profile-details { padding: 70px 20px 20px 20px; }
        
        .btn-follow { border-radius: 99px; font-weight: 700; padding: 8px 20px; transition: 0.2s; border: 1px solid #000; }
        .btn-follow.unfollow { background: #000; color: #fff; border: none; }
        .btn-follow.following { background: #fff; color: #000; }
        .btn-follow.following:hover { background: #eee; }

        .profile-tabs { display: flex; border-bottom: 1px solid var(--border); }
        .profile-tab-item { flex: 1; text-align: center; padding: 15px 0; cursor: pointer; color: var(--text-sub); font-weight: 600; position: relative; transition: 0.2s; }
        .profile-tab-item:hover { background: rgba(0,0,0,0.05); }
        .profile-tab-item.active { color: var(--text-main); }
        .profile-tab-item.active::after { content: ""; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 60px; height: 4px; background: #000; border-radius: 99px; }

        .bottom-nav { 
            position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); 
            width: 90%; max-width: 450px; background: rgba(255, 255, 255, 0.9); 
            backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
            border: 1px solid #000; display: none; justify-content: space-around; 
            align-items: center; padding: 12px 10px; z-index: 2000; border-radius: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .bottom-nav-item { color: var(--text-sub); text-decoration: none; display: flex; flex-direction: column; align-items: center; position: relative; padding: 5px 15px; }
        .bottom-nav-item i { font-size: 1.5rem; }
        .bottom-nav-item.active { color: #000; transform: translateY(-3px); }

        .nav-center-btn { background: #000; color: #fff !important; width: 55px; height: 55px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-top: -35px; border: 5px solid var(--bg); }

        .chat-bubble { max-width: 80%; padding: 10px 15px; border-radius: 20px; margin-bottom: 10px; border: 1px solid #eee; }
        .chat-me { background: #000; color: #fff; align-self: flex-end; border-bottom-right-radius: 4px; }
        .chat-other { background: #fff; color: #000; align-self: flex-start; border-bottom-left-radius: 4px; }
        .chat-container { height: calc(100vh - 200px); overflow-y: auto; display: flex; flex-direction: column; padding: 15px; background: #fafafa; }

        .btn-primary { background-color: #000 !important; border-color: #000 !important; }
        .btn-primary:hover { background-color: #333 !important; }

        @media (max-width: 992px) {
            .sidebar-left { width: 80px; padding: 10px; }
            .nav-link-item span { display: none; }
            .sidebar-right { display: none; }
        }

        @media (max-width: 576px) {
            .sidebar-left { display: none; }
            .bottom-nav { display: flex; }
            .feed-center { border-right: none; width: 100%; }
            body { padding-bottom: 100px; }
        }
    </style>
</head>
<body>
    <div id="iosNotif" class="ios-notification">
    <div class="ios-icon">
        <i class="bi bi-rocket-takeoff-fill"></i>
    </div>
    <div class="ios-content">
        <div class="ios-title">
            <span>PostAja</span>
            <span class="ios-time">baru saja</span>
        </div>
        <div id="iosMsg" class="ios-body">Pesan notifikasi di sini...</div>
    </div>
</div>
    <div class="main-container">
        <div class="sidebar-left d-none d-sm-flex flex-column justify-content-between">
            <div>
                <a href="index.php" class="brand-logo"><i class="bi bi-rocket-takeoff-fill"></i></a>
                <a href="index.php" class="nav-link-item <?= !isset($_GET['profile']) && !isset($_GET['q']) && !isset($_GET['chat']) ? 'fw-bold' : '' ?>"><i class="bi bi-house-door-fill"></i> <span>Beranda</span></a>
                <a href="#" class="nav-link-item" data-bs-toggle="modal" data-bs-target="#searchModal"><i class="bi bi-search"></i> <span>Search</span></a>
                <a href="?chat=1" class="nav-link-item <?= isset($_GET['chat']) ? 'fw-bold' : '' ?>"><i class="bi bi-chat-quote-fill"></i> <span>Public Chat</span></a>

                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="?profile=<?= $_SESSION['username'] ?>" class="nav-link-item <?= isset($_GET['profile']) && $_GET['profile'] == $_SESSION['username'] ? 'fw-bold' : '' ?>"><i class="bi bi-person"></i> <span>Profile</span></a>
                    <button class="btn btn-primary w-100 rounded-pill py-3 fw-bold mt-3 d-none d-lg-block shadow-sm" data-bs-toggle="modal" data-bs-target="#postModal">Postingan Baru</button>
                <?php else: ?>
                    <a href="#" class="nav-link-item" data-bs-toggle="modal" data-bs-target="#authModal"><i class="bi bi-person"></i> <span>Profile</span></a>
                    <button class="btn btn-primary w-100 rounded-pill py-3 fw-bold mt-3 d-none d-lg-block shadow-sm" data-bs-toggle="modal" data-bs-target="#authModal">Gabung Sekarang</button>
                <?php endif; ?>
            </div>
            
            <?php if(isset($_SESSION['user_id'])): ?>
                <div class="mb-4 dropdown">
                    <div class="d-flex align-items-center gap-2 p-2 hover-zoom cursor-pointer" data-bs-toggle="dropdown" style="cursor:pointer">
                        <div class="modern-avatar" style="width:40px; height:40px;"><?php if(!empty($_SESSION['avatar_url'])): ?><img src="<?= htmlspecialchars($_SESSION['avatar_url']) ?>" style="width:40px;height:40px;border-radius:50%;object-fit:cover;" alt="avatar"><?php else: ?><?= strtoupper(substr($_SESSION['username'],0,1)) ?><?php endif; ?></div>
                        <div class="d-none d-lg-block"><div class="fw-bold">@<?= $_SESSION['username'] ?></div></div>
                    </div>
                    <ul class="dropdown-menu border-0 shadow rounded-4">
                        <li><form method="POST"><button name="logout" class="dropdown-item text-danger">Logout @<?= $_SESSION['username'] ?></button></form></li>
                    </ul>
                </div>
            <?php else: ?>
                <div class="mb-4">
                    <button class="btn btn-outline-dark w-100 rounded-pill" data-bs-toggle="modal" data-bs-target="#authModal">Login</button>
                </div>
            <?php endif; ?>
        </div>

        <div class="feed-center">
            <div class="p-3 border-bottom sticky-top bg-white bg-opacity-75" style="backdrop-filter: blur(10px); z-index: 100;">
                <h5 class="fw-bold mb-0">
                    <?php 
                    if(isset($_GET['profile'])) echo "Profil";
                    elseif(isset($_GET['q'])) echo "Pencarian";
                    elseif(isset($_GET['chat'])) echo "Public Chat";
                    else echo "Beranda";
                    ?>
                </h5>
            </div>

            <?php if(isset($_GET['chat'])): ?>
                <div class="chat-container" id="chatWindow">
                    <?php
                    $chats = $db->query('SELECT public_chat.*, users.username FROM public_chat JOIN users ON public_chat.user_id = users.id ORDER BY public_chat.id ASC LIMIT 100');
                    while($ch = $chats->fetchArray(SQLITE3_ASSOC)):
                        $is_mine = (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $ch['user_id']);
                    ?>
                        <div class="chat-bubble <?= $is_mine ? 'chat-me' : 'chat-other' ?>">
                            <div style="font-size: 0.7rem; opacity: 0.8; font-weight: bold;">@<?= htmlspecialchars($ch['username']) ?></div>
                            <div><?= htmlspecialchars($ch['message']) ?></div>
                        </div>
                    <?php endwhile; ?>
                </div>
                <div class="p-3 border-top bg-white">
                    <form method="POST" onsubmit="return checkAuth(event)">
                        <div class="input-group">
                            <input type="text" name="chat_message" class="form-control rounded-pill-start border-0 bg-light px-4" placeholder="Ketik pesan..." required>
                            <button name="send_chat" class="btn btn-dark rounded-pill-end px-4">Kirim</button>
                        </div>
                    </form>
                </div>

            <?php elseif (!$view_profile && !isset($_GET['q'])): ?>
                <?php if(isset($_SESSION['user_id'])): ?>
                <div class="compose-area d-none d-sm-block">
                    <div class="d-flex gap-3">
                        <div class="modern-avatar"><?php if(!empty($_SESSION['avatar_url'])): ?><img src="<?= htmlspecialchars($_SESSION['avatar_url']) ?>" style="width:48px;height:48px;border-radius:50%;object-fit:cover;" alt="avatar"><?php else: ?><?= strtoupper(substr($_SESSION['username'],0,1)) ?><?php endif; ?></div>
                        <div class="flex-grow-1">
                            <form method="POST">
                                <textarea name="content" class="compose-input" placeholder="Apa yang sedang hangat?" required></textarea>
                                <input type="text" name="image_url" class="form-control form-control-sm border-0 bg-light mb-2" placeholder="URL Gambar (Opsional)">
                                <input type="text" name="music_url" class="form-control form-control-sm border-0 bg-light mb-2" placeholder="Music URL (mp3 link)">
                                <input type="text" name="music_title" class="form-control form-control-sm border-0 bg-light mb-2" placeholder="Music Title">
                                <div class="d-flex justify-content-end border-top pt-2">
                                    <button name="create_post" class="btn btn-dark rounded-pill px-4 fw-bold shadow-sm">Post</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="story-container">
                    <div class="story-circle" onclick="<?= isset($_SESSION['user_id']) ? "new bootstrap.Modal(document.getElementById('addStory')).show()" : "showAuthModal()" ?>">
                        <div class="story-ring d-flex align-items-center justify-content-center bg-light border-dashed">
                            <i class="bi bi-plus-lg text-dark"></i>
                        </div>
                        <span class="small">Cerita</span>
                    </div>
                    <?php
                    if(isset($_SESSION['user_id'])) {
                        $stmt = $db->prepare('
                            SELECT stories.*, users.username 
                            FROM stories 
                            JOIN users ON stories.user_id = users.id 
                            JOIN follows ON stories.user_id = follows.following_id 
                            WHERE follows.follower_id = :user_id
                            AND stories.created_at >= datetime("now", "-1 day")
                            GROUP BY stories.user_id
                            ORDER BY stories.created_at DESC
                        ');
                        $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
                        $sts = $stmt->execute();
                    } else {
                        $sts = null;
                    }
                    if($sts) {
                        while($s = $sts->fetchArray(SQLITE3_ASSOC)): ?>
                            <div class="story-circle" onclick="openStory('<?= $s['image_url'] ?>', '<?= $s['username'] ?>')">
                                <div class="story-ring"><img src="<?= $s['image_url'] ?>" loading="lazy"></div>
                                <span class="small text-truncate d-block">@<?= $s['username'] ?></span>
                            </div>
                        <?php endwhile;
                    }
                    ?>
                </div>
            <?php endif; ?>

            <div id="feed-container">
                <?php
                if (!isset($_GET['chat'])) {
                    if ($search_results) {
                        while ($p = $search_results->fetchArray(SQLITE3_ASSOC)) { echo renderPostHtml($p, $db); }
                    } elseif ($view_profile) {
                        $is_silo_profile = ($view_profile['username'] === 'silo');
                        $is_following = false;
                        if(isset($_SESSION['user_id'])) {
                            $stmt_fol = $db->prepare('SELECT COUNT(*) as count FROM follows WHERE follower_id = :fer AND following_id = :fing');
                            $stmt_fol->bindValue(':fer', $_SESSION['user_id'], SQLITE3_INTEGER);
                            $stmt_fol->bindValue(':fing', $view_profile['id'], SQLITE3_INTEGER);
                            $is_following = $stmt_fol->execute()->fetchArray(SQLITE3_ASSOC)['count'] > 0;
                        }
                        $stmt_fers = $db->prepare('SELECT COUNT(*) as count FROM follows WHERE following_id = :fing');
                        $stmt_fers->bindValue(':fing', $view_profile['id'], SQLITE3_INTEGER);
                        $f_ers = $stmt_fers->execute()->fetchArray(SQLITE3_ASSOC)['count'];
                        $stmt_fing = $db->prepare('SELECT COUNT(*) as count FROM follows WHERE follower_id = :fer');
                        $stmt_fing->bindValue(':fer', $view_profile['id'], SQLITE3_INTEGER);
                        $f_ing = $stmt_fing->execute()->fetchArray(SQLITE3_ASSOC)['count'];
                        ?>
                        <div class="profile-header">
                            <div class="profile-banner"></div>
                            <div class="profile-avatar-wrapper">
                                <div class="profile-avatar-main"><?php if(!empty($view_profile['avatar_url'])): ?><img src="<?= htmlspecialchars($view_profile['avatar_url']) ?>" style="width:120px;height:120px;border-radius:50%;object-fit:cover;border:4px solid #fff;" alt="avatar"><?php else: ?><?= strtoupper(substr($view_profile['username'],0,1)) ?><?php endif; ?></div>
                                <div class="mb-3">
                                    <?php if(!isset($_SESSION['user_id']) || $_SESSION['user_id'] != $view_profile['id']): ?>
                                        <button onclick="toggleFollow(<?= $view_profile['id'] ?>)" id="follow-btn" class="btn-follow <?= $is_following ? 'following' : 'unfollow' ?>">
                                            <?= $is_following ? 'Following' : 'Follow' ?>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="profile-details">
                                <div class="d-flex align-items-center gap-2">
                                    <h4 class="fw-bold mb-0 <?= $is_silo_profile ? 'silo-anim' : '' ?>">@<?= htmlspecialchars($view_profile['username']) ?></h4>
                                    <?php if($is_silo_profile): ?>
                                        <span class="badge bg-dark text-white border-0 px-2 py-1" style="font-size: 0.75rem;">admin</span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-muted mb-3"><?= htmlspecialchars($view_profile['role']) ?></div>
                                <p class="mb-3" style="font-size: 1.05rem;"><?= nl2br(htmlspecialchars($view_profile['bio'] ?: 'Belum ada deskripsi.')) ?></p>
                                <?php if(isset($_SESSION['user_id']) && $_SESSION['user_id'] == $view_profile['id']): ?>
                                    <button type="button" class="btn btn-outline-dark btn-sm rounded-pill mb-3" data-bs-toggle="modal" data-bs-target="#settingsModal">
                                        <i class="bi bi-gear"></i> Pengaturan
                                    </button>
                                <?php endif; ?>
                                <?php if(isset($_SESSION['user_id']) && $_SESSION['user_id'] == $view_profile['id']): ?>
                                    <form method="POST" class="d-flex gap-2 mb-3 d-none">
                                        <input type="url" name="avatar_url" class="form-control form-control-sm" placeholder="URL avatar..." value="<?= htmlspecialchars($view_profile['avatar_url'] ?? '') ?>">
                                        <button name="update_avatar" class="btn btn-dark btn-sm">Simpan Avatar</button>
                                    </form>
                                <?php endif; ?>
                                <div class="d-flex gap-4">
                                    <div class="cursor-pointer"><b><?= $f_ing ?></b> <span class="text-muted">Mengikuti</span></div>
                                    <div class="cursor-pointer"><b><?= $f_ers ?></b> <span class="text-muted">Pengikut</span></div>
                                </div>
                            </div>
                            
                            <div class="profile-tabs">
                                <div class="profile-tab-item active" onclick="switchTab('posts', this)">Postingan</div>
                                <div class="profile-tab-item" onclick="switchTab('badges', this)">Badge</div>
                            </div>
                        </div>

                        <div id="tab-posts">
                            <?php
                            $ps = $db->prepare('SELECT posts.*, users.username, users.role, users.avatar_url FROM posts JOIN users ON posts.user_id = users.id WHERE users.username = :u ORDER BY posts.created_at DESC');
                            $ps->bindValue(':u', $view_profile['username']);
                            $res = $ps->execute();
                            while($p = $res->fetchArray(SQLITE3_ASSOC)) { echo renderPostHtml($p, $db); }
                            ?>
                        </div>

                        <div id="tab-badges" style="display: none;">
                            <div class="badge-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 15px; padding: 20px;">
                                <div class="badge-item text-center">
                                    <img src="https://cdn-icons-png.flaticon.com/512/2583/2583344.png" style="width: 60px; height: 60px; filter: grayscale(1); margin-bottom: 5px;" alt="Early User">
                                    <span class="badge-name" style="font-size: 0.8rem; font-weight: 600; display: block;">Early User</span>
                                </div>
                                <div class="badge-item text-center">
                                    <img src="https://cdn-icons-png.flaticon.com/512/6270/6270515.png" style="width: 60px; height: 60px; filter: grayscale(1); margin-bottom: 5px;" alt="Verified">
                                    <span class="badge-name" style="font-size: 0.8rem; font-weight: 600; display: block;">Verified</span>
                                </div>
                                <?php if($is_silo_profile): ?>
                                <div class="badge-item text-center">
                                    <img src="https://cdn-icons-png.flaticon.com/512/1803/1803671.png" style="width: 60px; height: 60px; filter: grayscale(1); margin-bottom: 5px;" alt="Developer">
                                    <span class="badge-name" style="font-size: 0.8rem; font-weight: 600; display: block;">Developer</span>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                    <?php } else {
                              $ps = $db->query('SELECT posts.*, users.username, users.role, users.avatar_url FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.created_at DESC LIMIT 10');
                              while($p = $ps->fetchArray(SQLITE3_ASSOC)) { 
                                  echo renderPostHtml($p, $db); 
                              }
                          }
                        }
                ?>
            </div>
            
            <?php if(!isset($_GET['chat'])): ?>
            <div id="loading-trigger" class="text-center py-5">
                <div class="spinner-border spinner-border-sm text-dark"></div>
            </div>
            <?php endif; ?>
        </div>

        <div class="sidebar-right d-none d-lg-block">
            <?php if(isset($error_msg)) echo "<div class='alert alert-danger border-0 rounded-4 mt-3'>$error_msg</div>"; ?>
            <?php if(isset($success_msg)) echo "<div class='alert alert-success border-0 rounded-4 mt-3'>$success_msg</div>"; ?>
            
            <div class="bg-light p-3 rounded-4 mt-3 border">
                <h5 class="fw-bold mb-3">Apa yang baru?</h5>
                <p class="small text-muted">Selamat datang di PostAja versi 2026.</p>
                <h6 class="fw-bold mb-3">Fitur-Fitur:</h6>
                <p class="small text-muted">Tampilan Putih Hitam Minimalis</p>
                <p class="small text-muted">Akses Tamu (Tanpa Login)</p>
                <p class="small text-muted">Sistem Badge Profil baru</p>
                <p class="small text-dark fw-bold">Public Chat (Global Room)</p>
            </div>
            <div class="text-muted small px-3 mt-4">
                &copy; 2026 Silo Kusuma
            </div>
        </div>
    </div>

    <div class="bottom-nav">
        <a href="index.php" class="bottom-nav-item <?= !isset($_GET['profile']) && !isset($_GET['chat']) && !isset($_GET['q']) ? 'active' : '' ?>">
            <i class="bi bi-house-door-fill"></i>
        </a>
        <a href="#" class="bottom-nav-item" data-bs-toggle="modal" data-bs-target="#searchModal">
            <i class="bi bi-search"></i>
        </a>
        <a href="#" class="bottom-nav-item nav-center-btn" onclick="<?= isset($_SESSION['user_id']) ? "new bootstrap.Modal(document.getElementById('postModal')).show()" : "showAuthModal()" ?>">
            <i class="bi bi-plus-lg"></i>
        </a>
        <a href="?chat=1" class="bottom-nav-item <?= isset($_GET['chat']) ? 'active' : '' ?>">
            <i class="bi bi-chat-quote-fill"></i>
        </a>
        <a href="<?= isset($_SESSION['username']) ? '?profile='.$_SESSION['username'] : '#' ?>" class="bottom-nav-item <?= isset($_GET['profile']) && isset($_SESSION['username']) && $_GET['profile'] == $_SESSION['username'] ? 'active' : '' ?>" onclick="<?= !isset($_SESSION['user_id']) ? "showAuthModal()" : "" ?>">
            <i class="bi bi-person-fill"></i>
        </a>
    </div>

    <div class="modal fade" id="warnModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-5 border-0 shadow-lg text-center p-4">
                <div class="mb-3"><i class="bi bi-exclamation-triangle-fill text-dark display-1"></i></div>
                <h4 class="fw-bold">Peringatan Moderasi!</h4>
                <p class="text-muted">Pesan Anda mengandung kata-kata kasar yang tidak pantas. Kata-kata tersebut telah disensor secara otomatis.</p>
                <button type="button" class="btn btn-dark rounded-pill w-100 py-2 fw-bold" data-bs-dismiss="modal">Saya Mengerti</button>
            </div>
        </div>
    </div>

    <div class="modal fade" id="authModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-5 p-4 border-0 shadow-lg">
                <div class="text-center mb-4">
                    <i class="bi bi-rocket-takeoff-fill display-4 text-dark"></i>
                    <h3 class="fw-bold mt-2">Gabung ke PostAja</h3>
                </div>
                <ul class="nav nav-pills nav-fill mb-4 bg-light p-1 rounded-pill">
                    <li class="nav-item"><button class="nav-link active rounded-pill fw-bold" data-bs-toggle="pill" data-bs-target="#lgn">Login</button></li>
                    <li class="nav-item"><button class="nav-link rounded-pill fw-bold" data-bs-toggle="pill" data-bs-target="#reg">Daftar</button></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="lgn">
                        <form method="POST">
                            <?= csrfField() ?>
                            <div class="mb-3"><input type="text" name="username" class="form-control py-3 border-1 bg-light" placeholder="Username" required></div>
                            <div class="mb-4"><input type="password" name="password" class="form-control py-3 border-1 bg-light" placeholder="Password" required></div>
                            <button name="login" class="btn btn-dark w-100 py-3 rounded-pill fw-bold">Masuk akun</button>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="reg">
                        <form method="POST">
                            <?= csrfField() ?>
                            <div class="mb-2"><input type="text" name="username" class="form-control py-3 border-1 bg-light" placeholder="Username" required></div>
                            <div class="mb-2"><input type="email" name="email" class="form-control py-3 border-1 bg-light" placeholder="Email" required></div>
                            <div class="mb-3"><input type="password" name="password" class="form-control py-3 border-1 bg-light" placeholder="Password" required></div>
                            <div class="mb-3">
                                <select name="date_of_birth" class="form-select py-3 border-1 bg-light" required>
                                    <option value="" selected disabled>Select Year of Birth (1945-1950)</option>
                                    <?php for($y = 1950; $y >= 1945; $y--): ?>
                                    <option value="<?= $y ?>"><?= $y ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <?php if (defined('HCAPTCHA_SITE_KEY') && HCAPTCHA_SITE_KEY): ?>
                            <div class="mb-3 d-flex justify-content-center">
                                <div id="hcaptcha-container" data-sitekey="<?= HCAPTCHA_SITE_KEY ?>"></div>
                                <div class="h-captcha" data-sitekey="<?= HCAPTCHA_SITE_KEY ?>" style="display:none;"></div>
                            </div>
                            <?php endif; ?>
                            <button name="register" class="btn btn-dark w-100 py-3 rounded-pill fw-bold">Buat akun</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="searchModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-5 p-3">
                <form method="GET" action="index.php">
                    <input type="text" name="q" class="form-control bg-light border-0 rounded-pill py-2 mb-3" placeholder="Cari..." required>
                    <div class="d-flex gap-3 px-2 mb-3">
                        <div class="form-check"><input class="form-check-input" type="radio" name="type" value="posts" checked> Post</div>
                        <div class="form-check"><input class="form-check-input" type="radio" name="type" value="users"> User</div>
                    </div>
                    <button class="btn btn-dark w-100 rounded-pill py-2 fw-bold">Cari Sekarang</button>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="postModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-5 p-4">
                <h5 class="fw-bold mb-3">Buat Postingan</h5>
                <form method="POST">
                    <textarea name="content" class="form-control border-1 bg-light rounded-4 mb-3" rows="5" placeholder="Apa yang sedang terjadi?" required></textarea>
                    <input type="text" name="image_url" class="form-control border-1 bg-light rounded-pill mb-3" placeholder="URL Gambar (Opsional)">
                    <button name="create_post" class="btn btn-dark w-100 py-3 rounded-pill fw-bold">Post</button>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="vStory" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content bg-dark border-0 rounded-5 overflow-hidden">
                <div class="position-absolute top-0 w-100 p-3 d-flex justify-content-between align-items-center z-3">
                    <span class="text-white fw-bold" id="stUser"></span>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <img id="stImg" src="" class="w-100" style="max-height: 80vh; object-fit: contain;">
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="addStory" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-5 p-4">
                <h5 class="fw-bold mb-3">Bagikan Cerita</h5>
                <form method="POST">
                    <input type="text" name="story_image_url" class="form-control border-1 bg-light rounded-pill py-3 px-4 mb-3" placeholder="URL Gambar..." required>
                    <button name="create_story" class="btn btn-dark w-100 py-3 rounded-pill fw-bold shadow">Kirim Cerita</button>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="dobModal" data-bs-backdrop="static" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-5 p-4 border-0 shadow-lg" style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);">
                <div class="text-center mb-4">
                    <i class="bi bi-calendar-event display-4 text-info"></i>
                    <h4 class="fw-bold mt-2 text-white">Update Date of Birth</h4>
                    <p class="text-light small mb-0">Please provide your year of birth to continue</p>
                </div>
                <form id="dobForm">
                    <div class="mb-3">
                        <select id="dobYear" class="form-select py-3 border-0 bg-dark text-light" required>
                            <option value="" selected disabled>Select Year (1945-1950)</option>
                            <?php for($y = 1950; $y >= 1945; $y--): ?>
                            <option value="<?= $y ?>"><?= $y ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-info w-100 py-3 rounded-pill fw-bold text-dark">Save</button>
                </form>
            </div>
        </div>
    </div>

    <script>
    document.getElementById('dobForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const dob = document.getElementById('dobYear').value;
        if (!dob) return;
        fetch('api/update_dob.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'dob=' + encodeURIComponent(dob)
        }).then(() => {
            localStorage.setItem('dob_updated', '1');
            bootstrap.Modal.getInstance(document.getElementById('dobModal')).hide();
        });
    });
    </script>

    <div class="modal fade" id="settingsModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-5 p-4">
                <h5 class="fw-bold mb-4"><i class="bi bi-gear"></i> Pengaturan Profil</h5>
                <form method="POST">
                    <div class="mb-4">
                        <label class="form-label fw-bold mb-2">Foto Profil</label>
                        <input type="url" name="avatar_url" class="form-control border-1 bg-light rounded-3 py-2 px-3" placeholder="Tempel link gambar (URL)..." value="<?= htmlspecialchars($_SESSION['avatar_url'] ?? '') ?>">
                        <small class="text-muted d-block mt-2">Masukkan URL gambar profil Anda dari internet. Contoh: https://example.com/foto.jpg</small>
                    </div>

                    <div class="mb-4">
                        <label class="fw-bold mb-3 d-block">Notifikasi</label>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="notifToggle" name="notifications_enabled" <?= (isset($view_profile) && $view_profile['notifications_enabled'] == 1) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="notifToggle">
                                Aktifkan notifikasi
                            </label>
                        </div>
                        <small class="text-muted d-block mt-2">Terima notifikasi ketika ada orang yang follow Anda</small>
                    </div>

                    <div class="d-flex gap-2">
                        <button name="update_avatar" type="submit" class="btn btn-dark flex-grow-1 py-2 rounded-pill fw-bold">Simpan Avatar</button>
                        <button name="toggle_notifications" type="submit" class="btn btn-outline-dark flex-grow-1 py-2 rounded-pill fw-bold">Simpan Notifikasi</button>
                    </div>
                </form>
                <button type="button" class="btn btn-sm btn-light w-100 mt-2 rounded-pill" data-bs-dismiss="modal">Batal</button>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;

<?php if(isset($_GET['warned'])): ?>
    new bootstrap.Modal(document.getElementById('warnModal')).show();
<?php endif; ?>

<?php if (isset($_SESSION['needs_dob']) && $_SESSION['needs_dob']): ?>
<?php unset($_SESSION['needs_dob']); ?>
if (!localStorage.getItem('dob_updated')) {
    new bootstrap.Modal(document.getElementById('dobModal')).show();
}
<?php endif; ?>

if(document.getElementById('chatWindow')) {
    const chatWin = document.getElementById('chatWindow');
    chatWin.scrollTop = chatWin.scrollHeight;
}

function showAuthModal() {
    new bootstrap.Modal(document.getElementById('authModal')).show();
}

function checkAuth(e) {
    if (!isLoggedIn) {
        if(e) e.preventDefault();
        showAuthModal();
        return false;
    }
    return true;
}

function switchTab(tabName, element) {
    document.querySelectorAll('.profile-tab-item').forEach(el => el.classList.remove('active'));
    element.classList.add('active');
    
    if(tabName === 'posts') {
        document.getElementById('tab-posts').style.display = 'block';
        document.getElementById('tab-badges').style.display = 'none';
        if(document.getElementById('loading-trigger')) document.getElementById('loading-trigger').style.display = 'block';
    } else {
        document.getElementById('tab-posts').style.display = 'none';
        document.getElementById('tab-badges').style.display = 'block';
        if(document.getElementById('loading-trigger')) document.getElementById('loading-trigger').style.display = 'none';
    }
}

function likePost(postId) {
    if(!checkAuth()) return;
    
    const btn = document.getElementById('like-btn-' + postId);
    const countSpan = btn.querySelector('.count');
    if(btn.disabled) return;
    btn.disabled = true;

    fetch('?like_post=' + postId)
        .then(res => res.json())
        .then(data => {
            if(data.status === 'liked') {
                btn.classList.add('active');
                btn.querySelector('i').classList.replace('bi-heart', 'bi-heart-fill');
            } else if (data.status === 'unliked') {
                btn.classList.remove('active');
                btn.querySelector('i').classList.replace('bi-heart-fill', 'bi-heart');
            } else if (data.message === 'login_required') {
                showAuthModal();
            }
            if(data.count !== undefined) countSpan.innerText = data.count;
            btn.disabled = false;
        }).catch(() => btn.disabled = false);
}

// Cek notifikasi ke server setiap 1 detik
<?php if(isset($_SESSION['user_id'])): ?>
setInterval(() => {
    fetch('?check_notif=1')
        .then(response => response.json())
        .then(data => {
            if(data && data.message) {
                triggerNotif(data.message);
            }
        });
}, 1000);
<?php endif; ?>
</script>
<?php if (defined('HCAPTCHA_SITE_KEY') && HCAPTCHA_SITE_KEY): ?>
<script src="https://js.hcaptcha.com/1/api.js?render=explicit" async defer></script>
<script>
document.addEventListener('shown.bs.tab', function(e) {
    if (e.target.getAttribute('data-bs-target') === '#reg') {
        var container = document.getElementById('hcaptcha-container');
        if (container && !container.querySelector('.hcap-widget')) {
            var sitekey = container.dataset.sitekey;
            if (typeof hcaptcha !== 'undefined' && sitekey) {
                var widgetId = hcaptcha.render(container, {
                    sitekey: sitekey,
                    theme: 'light'
                });
                container.dataset.widgetId = widgetId;
                container.classList.add('hcap-widget');
            }
        }
    }
});
</script>
<?php endif; ?>
</body>
</html>